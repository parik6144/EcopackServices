<?php $this->load->view('header'); ?>
<?php $this->load->view('left_sidebar'); ?>
<?php $this->load->view('topbar'); ?>
	<style>
		.emp-profile-container {
			background: #fff;
			border-radius: 8px;
			box-shadow: 0 2px 12px rgba(0,0,0,0.07);
			padding: 18px 10px;
			margin: 24px auto 24px auto;
			max-width: 1200px;
		}
		.emp-profile-container h2 {
			font-weight: 600;
			margin-bottom: 18px;
			letter-spacing: 0.5px;
			font-size: 1.3rem;
		}
		/* Updated nav-link styling */
		.nav-tabs .nav-item .nav-link {
			background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
			color: #fff;
			border-radius: 8px 8px 0 0;
			padding: 7px 16px;
			font-weight: 500;
			font-size: 1rem;
			margin-right: 2px;
			box-shadow: 0 1px 4px rgba(0,0,0,0.04);
			border: none;
			transition: background 0.2s, color 0.2s;
			cursor: pointer;
			opacity: 0.92;
			min-width: 80px;
		}
		.nav-tabs .nav-item .nav-link.active,
		.nav-tabs .nav-item .nav-link:hover {
			background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
			color: #fff;
			opacity: 1;
			box-shadow: 0 2px 8px rgba(25, 118, 210, 0.08);
		}

		.tab-content {
			margin-top: 10px;
		}
		.form-group {
			position: relative;
			margin-bottom: 12px;
		}
		.form-control {
			border-radius: 6px;
			border: 1px solid #e0e0e0;
			padding: 8px 8px 4px 8px; /* Adjusted padding to ensure text doesn't hide behind label */
			font-size: 1rem;
			background: #fafbfc;
			transition: border 0.2s, box-shadow 0.2s;
			height: 38px;
			min-height: 38px;
		}
		.form-control:focus {
			border-color: #1976d2;
			box-shadow: 0 0 0 1.5px #1976d220;
			background: #fff;
		}
		/* Style for invalid input */
		.form-control.is-invalid {
			border-color: #dc3545;
			padding-right: calc(1.5em + 0.75rem); /* Ensure space for feedback icon */
			background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23dc3545' viewBox='0 0 12 12'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
			background-repeat: no-repeat;
			background-position: right calc(0.375em + 0.1875rem) center;
			background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
		}
		.form-group label {
			position: absolute;
			top: 7px; /* Adjusted to initial position for label */
			left: 12px;
			font-size: 0.97rem;
			color: #888;
			background: transparent;
			pointer-events: none;
			transition: 0.2s;
			padding: 0 2px;
			z-index: 1; /* Ensure label is above input when not focused/filled */
			font-weight: 500;
			margin-bottom: 2px;
		}
		/* Floating label effect */
		.form-control:focus + label,
		.form-control:not(:placeholder-shown) + label,
		.form-control.filled + label { /* Added filled for autofill */
			top: -10px; /* Moves label up */
			left: 8px; /* Moves label slightly left */
			font-size: 0.89rem;
			color: #1976d2;
			background: #fff; /* Background to prevent text bleeding through */
			padding: 0 4px;
			z-index: 2; /* Keep label above input text */
		}

		/* Important: Hide placeholders when label is floated to prevent overlap */
		.form-control::-webkit-input-placeholder {
			color: transparent;
		}
		.form-control:-moz-placeholder { /* Firefox 18- */
			color: transparent;
		}
		.form-control::-moz-placeholder {  /* Firefox 19+ */
			color: transparent;
		}
		.form-control:-ms-input-placeholder {
			color: transparent;
		}
		.form-control.is-invalid + label { /* Ensure label stays correctly styled for invalid floating labels */
			color: #dc3545 !important; /* Keep error color */
		}


		.form-error {
			color: #d32f2f;
			font-size: 0.89rem;
			margin-top: 1px;
			margin-left: 1px;
			font-weight: 400;
		}
		.section-heading {
			font-weight: 600;
			font-size: 1.01rem;
			margin: 18px 0 8px 0;
			color: #1976d2;
		}
		.btn-success, .btn-info {
			border-radius: 6px;
			padding: 7px 18px;
			font-weight: 500;
			font-size: 1rem;
			box-shadow: 0 1px 4px rgba(0,150,136,0.07);
			border: none;
			transition: background 0.2s, box-shadow 0.2s;
		}
		.btn-success {
			background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
			color: #fff;
		}
		.btn-success:hover {
			background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
			color: #fff;
			box-shadow: 0 2px 8px rgba(0,150,136,0.10);
		}
		.btn-info {
			background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
			color: #fff;
		}
		.btn-info:hover {
			background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
			color: #fff;
			box-shadow: 0 2px 8px rgba(25, 118, 210, 0.10);
		}
		.alert {
			border-radius: 6px;
			font-size: 0.98rem;
			margin-bottom: 12px;
			box-shadow: 0 1px 4px rgba(25, 118, 210, 0.04);
		}
		.form-row {
			margin-bottom: 6px;
		}
		@media (max-width: 768px) {
			.emp-profile-container {
				padding: 6px 1px;
			}
			.nav-tabs .nav-item .nav-link { /* Adjusted for Bootstrap nav-link */
				padding: 5px 5px;
				font-size: 0.93rem;
			}
		}
		.nav-pills .nav-link {
			background-color: #e9ecef;
			color: #495057;
			margin-right: 5px;
			border-radius: 5px;
		}
		.nav-pills .nav-link.active {
			background-color: #007bff;
			color: #fff;
		}

		/* Photo Upload Styling */
		.photo-upload-container {
			border: 2px dashed #ccc;
			border-radius: 8px;
			padding: 18px;
			text-align: center;
			background: #fafafa;
			margin-bottom: 10px;
			min-height: 140px;
			position: relative;
		}
		.photo-upload-container.drag-over {
			border-color: #1976d2;
			background-color: #e6f7ff;
		}
		.photo-upload-container input[type="file"] {
			display: none;
		}
		.photo-upload-container .photo-upload-icon {
			color: #888;
			font-size: 2.5rem;
			margin-bottom: 10px;
		}
		.photo-upload-container .photo-upload-text {
			color: #888;
			font-size: 0.95rem;
		}
		.photo-preview-frame {
			width: 150px; /* Fixed size for the frame */
			height: 150px;
			border: 2px solid #eee;
			border-radius: 50%; /* Circular frame */
			overflow: hidden; /* Hide overflow outside the circle */
			margin: 10px auto;
			display: flex;
			align-items: center;
			justify-content: center;
			background-color: #eee;
			box-shadow: 0 0 5px rgba(0,0,0,0.1);
		}
		.photo-preview-frame img {
			width: 100%;
			height: 100%;
			object-fit: cover; /* Crop image to fit circle */
		}
		.photo-actions {
			margin-top: 10px;
			display: flex;
			gap: 10px;
		}
		.emp-profile-heading {
			font-size: 2rem;
			font-weight: 700;
			letter-spacing: 1px;
			color: #222;
		}

		.emp-profile-heading {
			font-size: 2rem;
			font-weight: 700;
			letter-spacing: 1px;
			color: #222;
		}
		.form-group label {
			font-weight: 500;
			margin-bottom: 2px;
		}
		.form-control {
			height: 38px;
			font-size: 1rem;
			border-radius: 6px;
		}
		.photo-upload-container {
			border: 2px dashed #ccc;
			border-radius: 8px;
			padding: 18px;
			text-align: center;
			background: #fafafa;
			margin-bottom: 10px;
			min-height: 140px;
			position: relative;
		}
		.photo-upload-container .photo-upload-icon {
			color: #888;
		}
		.photo-upload-container .photo-upload-text {
			color: #888;
			font-size: 0.95rem;
		}
		.photo-preview-frame img {
			border: 2px solid #eee;
		}
		.remove-photo-btn {
			color: #d32f2f;
			background: #fff;
			border-radius: 50%;
			border: 1px solid #eee;
			width: 28px;
			height: 28px;
			line-height: 24px;
			text-align: center;
			cursor: pointer;
		}
	</style>
	<div class="emp-profile-container">
		<div class="d-flex justify-content-between align-items-center mb-3">
			<h2 class="emp-profile-heading flex-grow-1 text-center m-0">Employee Profile</h2>
			<div class="profile-progress-container ml-3" style="min-width:220px;">
				<div id="profile-progress-text" style="font-weight:600; color:gold;"></div>
				<div class="progress" style="background:black; border-radius:8px;">
					<div id="profile-progress-bar" class="progress-bar" role="progressbar" style="width:0%; background:linear-gradient(90deg, gold, orange); color:black; font-weight:bold;">0%</div>
				</div>
			</div>
		</div>
		<div id="formAlert"></div>
		<ul class="nav nav-tabs" id="myTab" role="tablist">
			<li class="nav-item" role="presentation">
				<a class="nav-link active" id="master-tab" data-toggle="tab" href="#master" role="tab" aria-controls="master" aria-selected="true">Master</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-tab" data-toggle="tab" href="#personal" role="tab" aria-controls="personal" aria-selected="false">Personal</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="payment-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="payment" aria-selected="false">Payment</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="admin-tab" data-toggle="tab" href="#admin" role="tab" aria-controls="admin" aria-selected="false">Administration</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="statutory-tab" data-toggle="tab" href="#statutory" role="tab" aria-controls="statutory" aria-selected="false">Statutory</a>
			</li>
		</ul>
		<div class="tab-content" id="myTabContent">
			<div class="tab-pane active" id="master" role="tabpanel" aria-labelledby="master-tab">
				<form id="masterForm" enctype="multipart/form-data" novalidate>
					<div class="form-row">
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="employee_code" name="employee_code" required placeholder=" " readonly />
							<label for="employee_code">Employee Code *</label>
							<div class="form-error" id="error_employee_code"></div>
						</div>
						<div class="form-group col-md-4">
							<select class="form-control select2" id="employment_type" name="employment_type" required>
								<option value="">Select Employment Type *</option>
							</select>
							<label for="employment_type">Employment Type *</label>
							<div class="form-error" id="error_employment_type"></div>
						</div>
						<div class="form-group col-md-4">
							<select class="form-control select2" id="posting_city" name="posting_city" required>
								<option value="">Select Posting City *</option>
							</select>
							<label for="posting_city">Posting City *</label>
							<div class="form-error" id="error_posting_city"></div>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="posting_branch" name="posting_branch" required placeholder=" " />
							<label for="posting_branch">Posting Branch *</label>
							<div class="form-error" id="error_posting_branch"></div>
						</div>
						<div class="form-group col-md-4">
							<select class="form-control select2" id="designation" name="designation" required>
								<option value="">Select Designation *</option>
							</select>
							<label for="designation">Designation *</label>
							<div class="form-error" id="error_designation"></div>
						</div>
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="company" name="company" required placeholder=" " />
							<label for="company">Company *</label>
							<div class="form-error" id="error_company"></div>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="first_name" name="first_name" required placeholder=" " />
							<label for="first_name">First Name *</label>
							<div class="form-error" id="error_first_name"></div>
						</div>
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="middle_name" name="middle_name" placeholder=" " />
							<label for="middle_name">Middle Name</label>
							<div class="form-error" id="error_middle_name"></div>
						</div>
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="last_name" name="last_name" required placeholder=" " />
							<label for="last_name">Last Name *</label>
							<div class="form-error" id="error_last_name"></div>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="salary_branch" name="salary_branch" required placeholder=" " />
							<label for="salary_branch">Salary Branch *</label>
							<div class="form-error" id="error_salary_branch"></div>
						</div>
						<div class="form-group col-md-4">
							<input type="text" class="form-control" id="attendance_type" name="attendance_type" required placeholder=" " />
							<label for="attendance_type">Attendance Type *</label>
							<div class="form-error" id="error_attendance_type"></div>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-md-4">
							<label for="photo">Photo</label>
							<div class="photo-upload-container" id="photo-upload-container">
								<input type="file" id="photo" name="photo" accept="image/*" style="display:none;">
								<div class="photo-preview-frame" style="display:none; position:relative;">
									<img src="" alt="Preview" style="width:100px;height:100px;border-radius:50%;">
									<button type="button" class="remove-photo-btn" style="position:absolute;top:2px;right:2px;background:#fff;border:none;font-size:18px;">&times;</button>
								</div>
								<div class="photo-upload-icon" style="font-size:2rem;cursor:pointer;">+</div>
								<div class="photo-upload-text">Drag & Drop or Click to Upload</div>
							</div>
							<div class="form-error" id="error_photo"></div>
						</div>
					</div>
					<button type="submit" class="btn btn-success mt-3">Save & Accept</button>
				</form>
			</div>
			<div class="tab-pane" id="personal" role="tabpanel" aria-labelledby="personal-tab">
				<form id="personalForm" class="otherForm" action="<?= base_url('employee/save_personal'); ?>">
					<input type="hidden" name="staff_id" id="personal_staff_id" value="">
					<!-- Personal tab fields here -->
					<button type="submit" class="btn btn-success mt-3 other-form-submit" disabled>Save Personal</button>
				</form>
			</div>
			<div class="tab-pane" id="payment" role="tabpanel" aria-labelledby="payment-tab">
				<form id="paymentForm" class="otherForm" action="<?= base_url('employee/save_payment'); ?>">
					<input type="hidden" name="staff_id" id="payment_staff_id" value="">
					<!-- Payment tab fields here -->
					<button type="submit" class="btn btn-success mt-3 other-form-submit" disabled>Save Payment</button>
				</form>
			</div>
			<div class="tab-pane" id="admin" role="tabpanel" aria-labelledby="admin-tab">
				<form id="adminForm" class="otherForm" action="<?= base_url('employee/save_admin'); ?>">
					<input type="hidden" name="staff_id" id="admin_staff_id" value="">
					<!-- Admin tab fields here -->
					<button type="submit" class="btn btn-success mt-3 other-form-submit" disabled>Save Admin</button>
				</form>
			</div>
			<div class="tab-pane" id="statutory" role="tabpanel" aria-labelledby="statutory-tab">
				<form id="statutoryForm" class="otherForm" action="<?= base_url('employee/save_statutory'); ?>">
					<input type="hidden" name="staff_id" id="statutory_staff_id" value="">
					<!-- Statutory tab fields here -->
					<button type="submit" class="btn btn-success mt-3 other-form-submit" disabled>Save Statutory</button>
				</form>
			</div>
		</div>
	</div>
	<script>
		let employee_id = null;
		$(document).ready(function() {
			// Disable all other tab submit buttons initially
			$('.other-form-submit').prop('disabled', true);

			// Master tab submit
			$('#masterForm').on('submit', function(e) {
				e.preventDefault();
				let formData = new FormData(this);
				$.ajax({
					url: '<?= base_url("employee/save_master"); ?>',
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(res) {
						let data = typeof res === 'string' ? JSON.parse(res) : res;
						if (data.success) {
							employee_id = data.employee_id;
							// Set employee_id in all hidden fields
							$('#personal_staff_id, #payment_staff_id, #admin_staff_id, #statutory_staff_id').val(employee_id);
							$('.other-form-submit').prop('disabled', false);
							Swal.fire('Success', 'Master tab saved! Now you can fill other tabs.', 'success');
						} else {
							Swal.fire('Error', data.message || 'Something went wrong!', 'error');
						}
					},
					error: function() {
						Swal.fire('Error', 'Server error!', 'error');
					}
				});
			});

			// Personal tab submit
			$('#personalForm').on('submit', function(e) {
				e.preventDefault();
				if (!employee_id) {
					Swal.fire('Error', 'Please save Master tab first!', 'error');
					return;
				}
				let formData = new FormData(this);
				formData.append('employee_id', employee_id);
				$.ajax({
					url: '<?= base_url("employee/save_personal"); ?>',
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(res) {
						let data = typeof res === 'string' ? JSON.parse(res) : res;
						if (data.success) {
							Swal.fire('Success', 'Personal details saved!', 'success');
						} else {
							Swal.fire('Error', data.message || 'Something went wrong!', 'error');
						}
					},
					error: function() {
						Swal.fire('Error', 'Server error!', 'error');
					}
				});
			});

			// Academic tab submit
			$('#academicForm').on('submit', function(e) {
				e.preventDefault();
				if (!employee_id) {
					Swal.fire('Error', 'Please save Master tab first!', 'error');
					return;
				}
				let formData = new FormData(this);
				formData.append('employee_id', employee_id);
				$.ajax({
					url: '<?= base_url("employee/save_academic"); ?>',
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(res) {
						let data = typeof res === 'string' ? JSON.parse(res) : res;
						if (data.success) {
							Swal.fire('Success', 'Academic details saved!', 'success');
						} else {
							Swal.fire('Error', data.message || 'Something went wrong!', 'error');
						}
					},
					error: function() {
						Swal.fire('Error', 'Server error!', 'error');
					}
				});
			});

			// Address tab submit
			$('#addressForm').on('submit', function(e) {
				e.preventDefault();
				if (!employee_id) {
					Swal.fire('Error', 'Please save Master tab first!', 'error');
					return;
				}
				let formData = new FormData(this);
				formData.append('employee_id', employee_id);
				$.ajax({
					url: '<?= base_url("employee/save_address"); ?>',
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(res) {
						let data = typeof res === 'string' ? JSON.parse(res) : res;
						if (data.success) {
							Swal.fire('Success', 'Address details saved!', 'success');
						} else {
							Swal.fire('Error', data.message || 'Something went wrong!', 'error');
						}
					},
					error: function() {
						Swal.fire('Error', 'Server error!', 'error');
					}
				});
			});

			// Family tab submit
			$('#familyForm').on('submit', function(e) {
				e.preventDefault();
				if (!employee_id) {
					Swal.fire('Error', 'Please save Master tab first!', 'error');
					return;
				}
				let formData = new FormData(this);
				formData.append('employee_id', employee_id);
				$.ajax({
					url: '<?= base_url("employee/save_family"); ?>',
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(res) {
						let data = typeof res === 'string' ? JSON.parse(res) : res;
						if (data.success) {
							Swal.fire('Success', 'Family details saved!', 'success');
						} else {
							Swal.fire('Error', data.message || 'Something went wrong!', 'error');
						}
					},
					error: function() {
						Swal.fire('Error', 'Server error!', 'error');
					}
				});
			});

			// Prevent switching to other tabs if master not saved
			$('.nav-tabs a').on('click', function(e) {
				if ($(this).attr('id') !== 'master-tab' && !employee_id) {
					e.preventDefault();
					Swal.fire('Info', 'Please save the Master tab first!', 'info');
				}
			});
		});
	</script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		$(document).ready(function() {
			// Load places in dropdown
			$.ajax({
				url: '<?php echo base_url("employee/get_places"); ?>',
				type: 'GET',
				dataType: 'json',
				success: function(response) {
					var options = '<option value="">Select Posting City *</option>';
					$.each(response, function(index, item) {
						options += '<option value="' + item.place_id + '" data-state="' + item.state_code + '">' + item.place_name + '</option>';
					});
					$('#posting_city').html(options);
				}
			});

			// Generate employee code when city is selected
			$('#posting_city').change(function() {
				var state_code = $(this).find(':selected').data('state');
				if(state_code) {
					$.ajax({
						url: '<?php echo base_url("employee/get_next_employee_code"); ?>',
						type: 'POST',
						data: {state_code: state_code},
						dataType: 'json',
						success: function(response) {
							$('#employee_code').val(response.employee_code);
						}
					});
				} else {
					$('#employee_code').val('');
				}
			});

			// Place Dropdown with state_code
			$.ajax({
				url: '<?= base_url("employee/get_places"); ?>',
				type: 'GET',
				dataType: 'json',
				success: function(response) {
					let options = '<option value="">Select Posting City *</option>';
					response.forEach(function(place) {
						// Yahan state_code sahi se use ho raha hai
						options += `<option value="${place.place_id}" data-state="${place.state_code}">${place.place_name} (${place.state_code})</option>`;
					});
					$('#posting_city').html(options);
					$('#posting_city').select2({ placeholder: "Search for a city...", allowClear: true });
				}
			});


			// Employee Type Dropdown
			$.ajax({
				url: '<?= base_url("employee/get_employment_types"); ?>',
				type: 'GET',
				dataType: 'json',
				success: function(response) {
					let options = '<option value="">Select Employment Type *</option>';
					response.forEach(function(type) {
						options += `<option value="${type.employee_type_id}">${type.type_name}</option>`;
					});
					$('#employment_type').html(options);
					$('#employment_type').select2({ placeholder: "Select Employment Type...", allowClear: true });
				}
			});

			// Designation Dependent Dropdown
			$('#employment_type').on('change', function() {
				let employeeTypeId = $(this).val();
				$('#designation').html('<option value="">Select Designation *</option>');
				if(employeeTypeId) {
					$.ajax({
						url: '<?= base_url("employee/get_designations"); ?>',
						type: 'GET',
						data: { employee_type_id: employeeTypeId },
						dataType: 'json',
						success: function(response) {
							let options = '<option value="">Select Designation *</option>';
							response.forEach(function(designation) {
								options += `<option value="${designation.designation_id}">${designation.designation_name}</option>`;
							});
							$('#designation').html(options);
						}
					});
				}
				$('#designation').select2({ placeholder: "Select Designation...", allowClear: true });
			});

			// Form submit with swal alert
			$('#employeeForm').on('submit', function(e) {
				e.preventDefault();
				let formData = new FormData(this);
				$.ajax({
					url: '<?= base_url("employee/save"); ?>',
					type: 'POST',
					data: formData,
					processData: false,
					contentType: false,
					success: function(res) {
						let data = typeof res === 'string' ? JSON.parse(res) : res;
						if (data.success) {
							Swal.fire('Success', 'Employee saved successfully!', 'success');
						} else {
							Swal.fire('Error', data.message || 'Something went wrong!', 'error');
						}
					},
					error: function() {
						Swal.fire('Error', 'Server error!', 'error');
					}
				});
			});

			// Make master tab active by default
			$('#master-tab').addClass('active');
			$('#master').addClass('show active');

			// Handle tab clicks
			$('.nav-tabs a').on('click', function(e) {
				e.preventDefault();
				let targetTab = $(this).attr('href');

				// Remove active class from all tabs
				$('.nav-tabs a').removeClass('active');
				$('.tab-pane').removeClass('show active');

				// Add active class to clicked tab
				$(this).addClass('active');
				$(targetTab).addClass('show active');

				// Keep master tab active
				$('#master-tab').addClass('active');
			});

			// Initialize with master tab active
			$('#master-tab').trigger('click');



			// When department changes, fetch designations
			$('#department').on('change', function() {
				let departmentId = $(this).val();

				// Clear designation dropdown
				$('#designation').html('<option value="">Select Designation *</option>');

				if(departmentId) {
					$.ajax({
						url: '<?php echo base_url("employee/get_designations"); ?>',
						type: 'GET',
						data: { department_id: departmentId },
						dataType: 'json',
						success: function(response) {
							let options = '<option value="">Select Designation *</option>';
							response.forEach(function(designation) {
								options += `<option value="${designation.designation_id}">${designation.designation_name}</option>`;
							});
							$('#designation').html(options);
						},
						error: function(xhr, status, error) {
							console.error('Error fetching designations:', error);
						}
					});
				}

				// Initialize Select2 for designation
				$('#designation').select2({
					placeholder: "Select Designation...",
					allowClear: true
				});
			});
		});

		$(document).ready(function() {
			// Remember last active main tab and sub-tab
			let lastMainTab = localStorage.getItem('employeeFormActiveMainTab') || '#master';
			let lastSubTab = localStorage.getItem('employeeFormActiveSubTab') || '#main';

			// Activate last main tab
			if (lastMainTab) {
				$('#myTab a[href="' + lastMainTab + '"]').tab('show');
			}
			// Activate last sub-tab (if present)
			if ($(lastMainTab + ' .nav .nav-link[href="' + lastSubTab + '"]').length) {
				$(lastMainTab + ' .nav .nav-link[href="' + lastSubTab + '"]').tab('show');
			}

			// Store main tab change
			$('#myTab a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
				localStorage.setItem('employeeFormActiveMainTab', $(e.target).attr('href'));
			});
			// Store sub-tab change
			$('.tab-pane .nav .nav-link[data-toggle="tab"]').on('shown.bs.tab', function (e) {
				localStorage.setItem('employeeFormActiveSubTab', $(e.target).attr('href'));
			});

			// On form submit, if invalid, stay on the tab/sub-tab with the error
			$('#employeeForm').on('submit', function(e) {
				if (!this.checkValidity()) {
					e.preventDefault();
					e.stopPropagation();
					// Find first invalid field
					var $firstInvalid = $(this).find(':invalid').first();
					var $mainTabPane = $firstInvalid.closest('.tab-pane.tab-pane-main'); // main tab
					var $subTabPane = $firstInvalid.closest('.tab-pane.tab-pane-sub');   // sub-tab
					// Activate main tab if needed
					if ($mainTabPane.length) {
						var mainTabId = '#' + $mainTabPane.attr('id');
						$('#myTab a[href="' + mainTabId + '"]').tab('show');
						localStorage.setItem('employeeFormActiveMainTab', mainTabId);
					}
					// Activate sub-tab if needed
					if ($subTabPane.length) {
						var subTabId = '#' + $subTabPane.attr('id');
						$mainTabPane.find('.nav .nav-link[href="' + subTabId + '"]').tab('show');
						localStorage.setItem('employeeFormActiveSubTab', subTabId);
					}
					$firstInvalid.focus();
					// Optionally, show a message
					showError('Please fill all required fields correctly.');
				} else {
					$('#formAlert').html('');
				}
				this.classList.add('was-validated');
			});

			// Handle photo upload preview
			$('#photo').on('change', function() {
				const file = this.files[0];
				if (file) {
					const reader = new FileReader();
					reader.onload = function(e) {
						$('.photo-preview-frame img').attr('src', e.target.result);
					}
					reader.readAsDataURL(file);
				}
			});

			$('#photo-upload-container').on('click', function(e) {
				if ($(e.target).hasClass('photo-upload-icon') || $(e.target).hasClass('photo-upload-text')) {
					$('#photo').click();
				}
			});

			$('#photo').on('change', function() {
				const file = this.files[0];
				if (file) {
					const reader = new FileReader();
					reader.onload = function(e) {
						$('.photo-preview-frame img').attr('src', e.target.result);
						$('.photo-preview-frame').show();
						$('.photo-upload-icon, .photo-upload-text').hide();
					}
					reader.readAsDataURL(file);
				}
			});

			$('#photo-upload-container').on('dragover', function(e) {
				e.preventDefault();
				$(this).addClass('drag-over');
			});

			$('#photo-upload-container').on('dragleave drop', function(e) {
				e.preventDefault();
				$(this).removeClass('drag-over');
			});

			$('#photo-upload-container').on('drop', function(e) {
				e.preventDefault();
				const file = e.originalEvent.dataTransfer.files[0];
				$('#photo')[0].files = e.originalEvent.dataTransfer.files;
				$('#photo').trigger('change');
			});
		});

		$(function () {
			$('[data-toggle="tooltip"]').tooltip();
		});

		function showError(msg) {
			$('#formAlert').html(
				`<div class="alert alert-danger alert-dismissible fade show" role="alert">
      ${msg}
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>`
			);
			setTimeout(function() {
				$('.alert-danger').alert('close');
			}, 4000);
		}

		function updateProfileProgress() {
			var total = $('.form-control[required]').length;
			var filled = $('.form-control[required]').filter(function(){ return $(this).val().trim() !== ''; }).length;
			var percent = Math.round((filled/total)*100);
			$('#profile-progress-bar').css('width', percent+'%').text(percent+'%');
			// Motivational message
			let msg = '';
			if(percent < 30) msg = 'Let\'s get started!';
			else if(percent < 60) msg = 'Good going!';
			else if(percent < 90) msg = 'Almost there!';
			else if(percent < 100) msg = 'You are awesome! Just a few steps left to achieve milestone.';
			else msg = 'Congratulations! Profile complete!';
			$('#profile-progress-text').text(msg);
		}
		$('.form-control[required]').on('input', updateProfileProgress);
		updateProfileProgress();

		const FORM_KEY = 'employeeFormDraft';
		function saveDraft() {
			let data = {};
			$('#employeeForm').find('input, select, textarea').each(function() {
				if(this.type === 'file') return; // skip file
				data[this.name] = $(this).val();
			});
			localStorage.setItem(FORM_KEY, JSON.stringify(data));
		}
		function loadDraft() {
			let data = localStorage.getItem(FORM_KEY);
			if(data) {
				data = JSON.parse(data);
				for(let k in data) {
					$('[name=\"'+k+'\"]').val(data[k]);
				}
			}
		}
		function clearDraft() {
			localStorage.removeItem(FORM_KEY);
		}
		$('#employeeForm').on('input change', 'input, select, textarea', saveDraft);
		$(document).ready(loadDraft);
		$('#resetFormBtn').on('click', function() {
			$('#employeeForm')[0].reset();
			clearDraft();
		});

		$('.remove-photo-btn').on('click', function(e) {
			e.stopPropagation();
			$('#photo').val('');
			$('.photo-preview-frame').hide();
			$('.photo-upload-icon, .photo-upload-text').show();
		});
	</script>
<?php $this->load->view('footer'); ?>
