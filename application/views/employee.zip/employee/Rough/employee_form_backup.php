<?php $this->load->view('header'); ?>
<?php $this->load->view('left_sidebar'); ?>
<?php $this->load->view('topbar'); ?>
<style>
    .emp-profile-container {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.07);
        padding: 18px 10px;
        margin: 24px auto 24px auto;
        max-width: 1200px;
    }
    .emp-profile-container h2 {
        font-weight: 600;
        margin-bottom: 18px;
        letter-spacing: 0.5px;
        font-size: 1.3rem;
    }
    .custom-tabs {
        display: flex;
        border-bottom: none;
        margin-bottom: 12px;
        gap: 4px;
    }
    .custom-tab {
        background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
        color: #fff;
        border-radius: 8px 8px 0 0;
        padding: 7px 16px;
        font-weight: 500;
        font-size: 1rem;
        margin-right: 2px;
        box-shadow: 0 1px 4px rgba(0,0,0,0.04);
        border: none;
        transition: background 0.2s, color 0.2s;
        cursor: pointer;
        opacity: 0.92;
        min-width: 80px;
    }
    .custom-tab.active, .custom-tab:hover {
        background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
        color: #fff;
        opacity: 1;
        box-shadow: 0 2px 8px rgba(25, 118, 210, 0.08);
    }
    .tab-content {
        margin-top: 10px;
    }
    .form-group {
        position: relative;
        margin-bottom: 12px;
    }
    .form-control {
        border-radius: 4px;
        border: 1.2px solid #e0e0e0;
        padding: 8px 8px 4px 8px;
        font-size: 0.98rem;
        background: #fafbfc;
        transition: border 0.2s, box-shadow 0.2s;
        height: 32px;
        min-height: 32px;
    }
    .form-control:focus {
        border-color: #1976d2;
        box-shadow: 0 0 0 1.5px #1976d220;
        background: #fff;
    }
    .form-group label {
        position: absolute;
        top: 7px;
        left: 12px;
        font-size: 0.97rem;
        color: #888;
        background: transparent;
        pointer-events: none;
        transition: 0.2s;
        padding: 0 2px;
    }
    .form-control:focus + label,
    .form-control:not(:placeholder-shown) + label {
        top: -10px;
        left: 8px;
        font-size: 0.89rem;
        color: #1976d2;
        background: #fff;
        padding: 0 4px;
    }
    .form-error {
        color: #d32f2f;
        font-size: 0.89rem;
        margin-top: 1px;
        margin-left: 1px;
        font-weight: 400;
    }
    .section-heading {
        font-weight: 600;
        font-size: 1.01rem;
        margin: 18px 0 8px 0;
        color: #1976d2;
    }
    .btn-success, .btn-info {
        border-radius: 6px;
        padding: 7px 18px;
        font-weight: 500;
        font-size: 1rem;
        box-shadow: 0 1px 4px rgba(0,150,136,0.07);
        border: none;
        transition: background 0.2s, box-shadow 0.2s;
    }
    .btn-success {
        background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
        color: #fff;
    }
    .btn-success:hover {
        background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
        color: #fff;
        box-shadow: 0 2px 8px rgba(0,150,136,0.10);
    }
    .btn-info {
        background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
        color: #fff;
    }
    .btn-info:hover {
        background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
        color: #fff;
        box-shadow: 0 2px 8px rgba(25, 118, 210, 0.10);
    }
    .alert {
        border-radius: 6px;
        font-size: 0.98rem;
        margin-bottom: 12px;
        box-shadow: 0 1px 4px rgba(25, 118, 210, 0.04);
    }
    .form-row {
        margin-bottom: 6px;
    }
    @media (max-width: 768px) {
        .emp-profile-container {
            padding: 6px 1px;
        }
        .custom-tab {
            padding: 5px 5px;
            font-size: 0.93rem;
        }
    }
</style>
<div class="emp-profile-container">
    <h2>Employee Profile</h2>
    <div id="formAlert"></div>
    <form id="employeeForm" enctype="multipart/form-data" novalidate>
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#master">Master</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#personal">Personal</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#payment">Payment</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#admin">Administration</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#statutory">Statutory</a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="master">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="employee_code" name="employee_code" required placeholder=" " />
                        <label for="employee_code">Employee Code *</label>
                        <div class="form-error" id="error_employee_code"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="employment_type" name="employment_type" required placeholder=" " />
                        <label for="employment_type">Employment Type *</label>
                        <div class="form-error" id="error_employment_type"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="posting_branch" name="posting_branch" required placeholder=" " />
                        <label for="posting_branch">Posting Branch *</label>
                        <div class="form-error" id="error_posting_branch"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="first_name" name="first_name" required placeholder=" " />
                        <label for="first_name">First Name *</label>
                        <div class="form-error" id="error_first_name"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="middle_name" name="middle_name" placeholder=" " />
                        <label for="middle_name">Middle Name</label>
                        <div class="form-error" id="error_middle_name"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="last_name" name="last_name" required placeholder=" " />
                        <label for="last_name">Last Name *</label>
                        <div class="form-error" id="error_last_name"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="company" name="company" required placeholder=" " />
                        <label for="company">Company *</label>
                        <div class="form-error" id="error_company"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="salary_branch" name="salary_branch" required placeholder=" " />
                        <label for="salary_branch">Salary Branch *</label>
                        <div class="form-error" id="error_salary_branch"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="project" name="project" placeholder=" " />
                        <label for="project">Project</label>
                        <div class="form-error" id="error_project"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="department" name="department" required placeholder=" " />
                        <label for="department">Department *</label>
                        <div class="form-error" id="error_department"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="designation" name="designation" required placeholder=" " />
                        <label for="designation">Designation *</label>
                        <div class="form-error" id="error_designation"></div>
                    </div>
                    <div class="form-group col-md-4">
                        <input type="text" class="form-control" id="attendance_type" name="attendance_type" required placeholder=" " />
                        <label for="attendance_type">Attendance Type *</label>
                        <div class="form-error" id="error_attendance_type"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <input type="file" class="form-control" id="photo" name="photo" />
                        <label for="photo">Photo</label>
                        <div class="form-error" id="error_photo"></div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="personal">
                <ul class="nav nav-pills mb-3" id="personalSubTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="personal-main-tab" data-toggle="pill" href="#personal-main" role="tab">Main</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-address-tab" data-toggle="pill" href="#personal-address" role="tab">Address</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-academic-tab" data-toggle="pill" href="#personal-academic" role="tab">Academic</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-family-tab" data-toggle="pill" href="#personal-family" role="tab">Family</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-nomination-tab" data-toggle="pill" href="#personal-nomination" role="tab">Nomination</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-career-tab" data-toggle="pill" href="#personal-career" role="tab">Career</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-medical-tab" data-toggle="pill" href="#personal-medical" role="tab">Medical</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-emergency-tab" data-toggle="pill" href="#personal-emergency" role="tab">Emergency</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="personal-attachments-tab" data-toggle="pill" href="#personal-attachments" role="tab">Attachments</a>
                    </li>
                </ul>
                <div class="tab-content" id="personalSubTabContent">
                    <!-- Main Sub-Tab -->
                    <div class="tab-pane fade show active" id="personal-main" role="tabpanel">
                        <h5>General Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <select class="form-control" id="gender" name="gender" required>
                                    <option value="">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                                <label for="gender">Gender *</label>
                                <div class="form-error" id="error_gender"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <select class="form-control" id="blood_group" name="blood_group">
                                    <option value="">Select</option>
                                    <option value="A+ve">A+ve</option>
                                    <option value="B+ve">B+ve</option>
                                    <option value="O+ve">O+ve</option>
                                    <option value="AB+ve">AB+ve</option>
                                    <option value="A-ve">A-ve</option>
                                    <option value="B-ve">B-ve</option>
                                    <option value="O-ve">O-ve</option>
                                    <option value="AB-ve">AB-ve</option>
                                </select>
                                <label for="blood_group">Blood Group</label>
                                <div class="form-error" id="error_blood_group"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="dob" name="dob" required />
                                <label for="dob">Date of Birth *</label>
                                <div class="form-error" id="error_dob"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="father_name" name="father_name" placeholder=" " />
                                <label for="father_name">Father's Name</label>
                                <div class="form-error" id="error_father_name"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="email" class="form-control" id="email" name="email" required placeholder=" " />
                                <label for="email">Email *</label>
                                <div class="form-error" id="error_email"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="mobile_no" name="mobile_no" maxlength="10" required placeholder=" " />
                                <label for="mobile_no">Mobile No *</label>
                                <div class="form-error" id="error_mobile_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="home_phone_no" name="home_phone_no" placeholder=" " />
                                <label for="home_phone_no">Home Phone No</label>
                                <div class="form-error" id="error_home_phone_no"></div>
                            </div>
                        </div>
                        <h5>Origin Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="caste" name="caste" placeholder=" " />
                                <label for="caste">Caste</label>
                                <div class="form-error" id="error_caste"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="religion" name="religion" placeholder=" " />
                                <label for="religion">Religion</label>
                                <div class="form-error" id="error_religion"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="citizenship" name="citizenship" placeholder=" " />
                                <label for="citizenship">Citizenship</label>
                                <div class="form-error" id="error_citizenship"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="country_of_birth" name="country_of_birth" placeholder=" " />
                                <label for="country_of_birth">Country of Birth</label>
                                <div class="form-error" id="error_country_of_birth"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <select class="form-control" id="disabilities" name="disabilities">
                                    <option value="">Select</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                <label for="disabilities">Disabilities</label>
                                <div class="form-error" id="error_disabilities"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="birth_place" name="birth_place" placeholder=" " />
                                <label for="birth_place">Birth Place</label>
                                <div class="form-error" id="error_birth_place"></div>
                            </div>
                        </div>
                        <h5>Marital Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <select class="form-control" id="marital_status" name="marital_status" required>
                                    <option value="">Select</option>
                                    <option value="Single">Single</option>
                                    <option value="Married">Married</option>
                                    <option value="Divorced">Divorced</option>
                                    <option value="Widowed">Widowed</option>
                                </select>
                                <label for="marital_status">Status *</label>
                                <div class="form-error" id="error_marital_status"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="marriage_date" name="marriage_date" />
                                <label for="marriage_date">Marriage Date</label>
                                <div class="form-error" id="error_marriage_date"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="no_of_children" name="no_of_children" placeholder=" " />
                                <label for="no_of_children">No. of Children</label>
                                <div class="form-error" id="error_no_of_children"></div>
                            </div>
                        </div>
                        <h5>Passport Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="passport_name" name="passport_name" placeholder=" " />
                                <label for="passport_name">Name in Passport</label>
                                <div class="form-error" id="error_passport_name"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="passport_no" name="passport_no" placeholder=" " />
                                <label for="passport_no">Passport No</label>
                                <div class="form-error" id="error_passport_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="passport_valid_from" name="passport_valid_from" />
                                <label for="passport_valid_from">Validity From</label>
                                <div class="form-error" id="error_passport_valid_from"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="passport_valid_to" name="passport_valid_to" />
                                <label for="passport_valid_to">Validity To</label>
                                <div class="form-error" id="error_passport_valid_to"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="passport_issuer" name="passport_issuer" placeholder=" " />
                                <label for="passport_issuer">Passport Issuer</label>
                                <div class="form-error" id="error_passport_issuer"></div>
                            </div>
                        </div>
                        <h5>Social Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="url" class="form-control" id="linkedin" name="linkedin" placeholder=" " />
                                <label for="linkedin">LinkedIn</label>
                                <div class="form-error" id="error_linkedin"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="url" class="form-control" id="facebook" name="facebook" placeholder=" " />
                                <label for="facebook">Facebook</label>
                                <div class="form-error" id="error_facebook"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="url" class="form-control" id="twitter" name="twitter" placeholder=" " />
                                <label for="twitter">Twitter</label>
                                <div class="form-error" id="error_twitter"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="url" class="form-control" id="instagram" name="instagram" placeholder=" " />
                                <label for="instagram">Instagram</label>
                                <div class="form-error" id="error_instagram"></div>
                            </div>
                        </div>
                        <h5>Others Section</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="pan_no" name="pan_no" required placeholder=" " />
                                <label for="pan_no">PAN No. *</label>
                                <div class="form-error" id="error_pan_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="aadhar_no" name="aadhar_no" maxlength="12" placeholder=" " />
                                <label for="aadhar_no">Aadhar No</label>
                                <div class="form-error" id="error_aadhar_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="voter_id" name="voter_id" placeholder=" " />
                                <label for="voter_id">Voter ID</label>
                                <div class="form-error" id="error_voter_id"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="driving_license_no" name="driving_license_no" placeholder=" " />
                                <label for="driving_license_no">Driving License No</label>
                                <div class="form-error" id="error_driving_license_no"></div>
                            </div>
                        </div>
                    </div>
                    <!-- Address Sub-Tab -->
                    <div class="tab-pane fade" id="personal-address" role="tabpanel">
                        <h5>Current Address</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_house_no" name="current_house_no" placeholder=" " />
                                <label for="current_house_no">House No</label>
                                <div class="form-error" id="error_current_house_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_street_no" name="current_street_no" placeholder=" " />
                                <label for="current_street_no">Street No</label>
                                <div class="form-error" id="error_current_street_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_block_no" name="current_block_no" placeholder=" " />
                                <label for="current_block_no">Block No</label>
                                <div class="form-error" id="error_current_block_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="current_period_from" name="current_period_from" />
                                <label for="current_period_from">Period of Stay (From)</label>
                                <div class="form-error" id="error_current_period_from"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="current_period_to" name="current_period_to" />
                                <label for="current_period_to">Period of Stay (To)</label>
                                <div class="form-error" id="error_current_period_to"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_street" name="current_street" placeholder=" " />
                                <label for="current_street">Street</label>
                                <div class="form-error" id="error_current_street"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_landmark" name="current_landmark" placeholder=" " />
                                <label for="current_landmark">Landmark</label>
                                <div class="form-error" id="error_current_landmark"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_post_office" name="current_post_office" placeholder=" " />
                                <label for="current_post_office">Post Office</label>
                                <div class="form-error" id="error_current_post_office"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_police_station" name="current_police_station" placeholder=" " />
                                <label for="current_police_station">Police Station</label>
                                <div class="form-error" id="error_current_police_station"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_zip_code" name="current_zip_code" placeholder=" " />
                                <label for="current_zip_code">Zip Code</label>
                                <div class="form-error" id="error_current_zip_code"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_city" name="current_city" placeholder=" " />
                                <label for="current_city">City</label>
                                <div class="form-error" id="error_current_city"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_country" name="current_country" placeholder=" " />
                                <label for="current_country">Country</label>
                                <div class="form-error" id="error_current_country"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="current_state" name="current_state" placeholder=" " />
                                <label for="current_state">State</label>
                                <div class="form-error" id="error_current_state"></div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" value="1" id="sameAsCurrent">
                            <label class="form-check-label" for="sameAsCurrent">Permanent Address same as Current Address</label>
                        </div>
                        <h5>Permanent Address</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_house_no" name="permanent_house_no" placeholder=" " />
                                <label for="permanent_house_no">House No</label>
                                <div class="form-error" id="error_permanent_house_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_street_no" name="permanent_street_no" placeholder=" " />
                                <label for="permanent_street_no">Street No</label>
                                <div class="form-error" id="error_permanent_street_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_block_no" name="permanent_block_no" placeholder=" " />
                                <label for="permanent_block_no">Block No</label>
                                <div class="form-error" id="error_permanent_block_no"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="permanent_period_from" name="permanent_period_from" />
                                <label for="permanent_period_from">Period of Stay (From)</label>
                                <div class="form-error" id="error_permanent_period_from"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="permanent_period_to" name="permanent_period_to" />
                                <label for="permanent_period_to">Period of Stay (To)</label>
                                <div class="form-error" id="error_permanent_period_to"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_street" name="permanent_street" placeholder=" " />
                                <label for="permanent_street">Street</label>
                                <div class="form-error" id="error_permanent_street"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_landmark" name="permanent_landmark" placeholder=" " />
                                <label for="permanent_landmark">Landmark</label>
                                <div class="form-error" id="error_permanent_landmark"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_post_office" name="permanent_post_office" placeholder=" " />
                                <label for="permanent_post_office">Post Office</label>
                                <div class="form-error" id="error_permanent_post_office"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_police_station" name="permanent_police_station" placeholder=" " />
                                <label for="permanent_police_station">Police Station</label>
                                <div class="form-error" id="error_permanent_police_station"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_zip_code" name="permanent_zip_code" placeholder=" " />
                                <label for="permanent_zip_code">Zip Code</label>
                                <div class="form-error" id="error_permanent_zip_code"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_city" name="permanent_city" placeholder=" " />
                                <label for="permanent_city">City</label>
                                <div class="form-error" id="error_permanent_city"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_country" name="permanent_country" placeholder=" " />
                                <label for="permanent_country">Country *</label>
                                <div class="form-error" id="error_permanent_country"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="permanent_state" name="permanent_state" placeholder=" " />
                                <label for="permanent_state">State *</label>
                                <div class="form-error" id="error_permanent_state"></div>
                            </div>
                        </div>
                    </div>
                    <!-- Academic Sub-Tab -->
                    <div class="tab-pane fade" id="personal-academic" role="tabpanel">
                        <h5>Add Academic Record</h5>
                        <div id="academic-form-row" class="form-row">
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="academic_from_year" name="academic_from_year" min="1900" max="2100" placeholder=" " />
                                <label for="academic_from_year">From Year *</label>
                                <div class="form-error" id="error_academic_from_year"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="academic_to_year" name="academic_to_year" min="1900" max="2100" placeholder=" " />
                                <label for="academic_to_year">To Year *</label>
                                <div class="form-error" id="error_academic_to_year"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_examination" name="academic_examination" placeholder=" " />
                                <label for="academic_examination">Examination *</label>
                                <div class="form-error" id="error_academic_examination"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_certification_type" name="academic_certification_type" placeholder=" " />
                                <label for="academic_certification_type">Type of Certification</label>
                                <div class="form-error" id="error_academic_certification_type"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_certification" name="academic_certification" placeholder=" " />
                                <label for="academic_certification">Certification</label>
                                <div class="form-error" id="error_academic_certification"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_institute" name="academic_institute" placeholder=" " />
                                <label for="academic_institute">Institute *</label>
                                <div class="form-error" id="error_academic_institute"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_college_contact_no" name="academic_college_contact_no" placeholder=" " />
                                <label for="academic_college_contact_no">College Contact No</label>
                                <div class="form-error" id="error_academic_college_contact_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_college_address" name="academic_college_address" placeholder=" " />
                                <label for="academic_college_address">College Address</label>
                                <div class="form-error" id="error_academic_college_address"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_program" name="academic_program" placeholder=" " />
                                <label for="academic_program">Program</label>
                                <div class="form-error" id="error_academic_program"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_subject" name="academic_subject" placeholder=" " />
                                <label for="academic_subject">Subject *</label>
                                <div class="form-error" id="error_academic_subject"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_registration_no" name="academic_registration_no" placeholder=" " />
                                <label for="academic_registration_no">Registration No</label>
                                <div class="form-error" id="error_academic_registration_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_roll_no" name="academic_roll_no" placeholder=" " />
                                <label for="academic_roll_no">Roll No</label>
                                <div class="form-error" id="error_academic_roll_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_grade" name="academic_grade" placeholder=" " />
                                <label for="academic_grade">Grade *</label>
                                <div class="form-error" id="error_academic_grade"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_university" name="academic_university" placeholder=" " />
                                <label for="academic_university">University *</label>
                                <div class="form-error" id="error_academic_university"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_university_country" name="academic_university_country" placeholder=" " />
                                <label for="academic_university_country">University Country</label>
                                <div class="form-error" id="error_academic_university_country"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_university_state" name="academic_university_state" placeholder=" " />
                                <label for="academic_university_state">University State</label>
                                <div class="form-error" id="error_academic_university_state"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_university_city" name="academic_university_city" placeholder=" " />
                                <label for="academic_university_city">University City</label>
                                <div class="form-error" id="error_academic_university_city"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="academic_university_contact_no" name="academic_university_contact_no" placeholder=" " />
                                <label for="academic_university_contact_no">University Contact No</label>
                                <div class="form-error" id="error_academic_university_contact_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <select class="form-control" id="academic_educated_in_overseas" name="academic_educated_in_overseas">
                                    <option value="">Select</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                <label for="academic_educated_in_overseas">Educated In Overseas</label>
                                <div class="form-error" id="error_academic_educated_in_overseas"></div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info mb-2" id="addAcademicRecord">Add Academic Record</button>
                        <h5>Academic Records</h5>
                        <table class="table table-bordered" id="academicRecordsTable">
                            <thead>
                                <tr>
                                    <th>From</th><th>To</th><th>Exam</th><th>Type</th><th>Cert.</th><th>Institute</th><th>Subject</th><th>Grade</th><th>University</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <!-- Family Sub-Tab -->
                    <div class="tab-pane fade" id="personal-family" role="tabpanel">
                        <h5>Add Family Member</h5>
                        <div id="family-form-row" class="form-row">
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_first_name" name="family_first_name" placeholder=" " />
                                <label for="family_first_name">First Name *</label>
                                <div class="form-error" id="error_family_first_name"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_middle_name" name="family_middle_name" placeholder=" " />
                                <label for="family_middle_name">Middle Name</label>
                                <div class="form-error" id="error_family_middle_name"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_last_name" name="family_last_name" placeholder=" " />
                                <label for="family_last_name">Last Name *</label>
                                <div class="form-error" id="error_family_last_name"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_relation" name="family_relation" placeholder=" " />
                                <label for="family_relation">Relation *</label>
                                <div class="form-error" id="error_family_relation"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <select class="form-control" id="family_gender" name="family_gender">
                                    <option value="">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Other">Other</option>
                                </select>
                                <label for="family_gender">Gender *</label>
                                <div class="form-error" id="error_family_gender"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="date" class="form-control" id="family_dob" name="family_dob" placeholder=" " />
                                <label for="family_dob">DOB *</label>
                                <div class="form-error" id="error_family_dob"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_contact_no" name="family_contact_no" placeholder=" " />
                                <label for="family_contact_no">Contact No *</label>
                                <div class="form-error" id="error_family_contact_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="email" class="form-control" id="family_email_id" name="family_email_id" placeholder=" " />
                                <label for="family_email_id">Email Id</label>
                                <div class="form-error" id="error_family_email_id"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <select class="form-control" id="family_dependent" name="family_dependent">
                                    <option value="">Select</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                <label for="family_dependent">Dependent</label>
                                <div class="form-error" id="error_family_dependent"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <select class="form-control" id="family_residing_with_employee" name="family_residing_with_employee">
                                    <option value="">Select</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                <label for="family_residing_with_employee">Residing with employee</label>
                                <div class="form-error" id="error_family_residing_with_employee"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_address" name="family_address" placeholder=" " />
                                <label for="family_address">Address</label>
                                <div class="form-error" id="error_family_address"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="family_aadhar_no" name="family_aadhar_no" placeholder=" " />
                                <label for="family_aadhar_no">Aadhar No</label>
                                <div class="form-error" id="error_family_aadhar_no"></div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info mb-2" id="addFamilyRecord">Add Family Member</button>
                        <h5>Family Records</h5>
                        <table class="table table-bordered" id="familyRecordsTable">
                            <thead>
                                <tr>
                                    <th>Name</th><th>Relation</th><th>Gender</th><th>DOB</th><th>Contact</th><th>Dependent</th><th>Residing</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <!-- Nomination Sub-Tab -->
                    <div class="tab-pane fade" id="personal-nomination" role="tabpanel">
                        <h5>Add Nominee</h5>
                        <div id="nomination-form-row" class="form-row">
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="nominee_name" name="nominee_name" placeholder=" " />
                                <label for="nominee_name">Nominee Name *</label>
                                <div class="form-error" id="error_nominee_name"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="nominee_relation" name="nominee_relation" placeholder=" " />
                                <label for="nominee_relation">Relation *</label>
                                <div class="form-error" id="error_nominee_relation"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="nominee_percentage" name="nominee_percentage" min="0" max="100" placeholder=" " />
                                <label for="nominee_percentage">Percentage *</label>
                                <div class="form-error" id="error_nominee_percentage"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="nominee_address" name="nominee_address" placeholder=" " />
                                <label for="nominee_address">Address</label>
                                <div class="form-error" id="error_nominee_address"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="nominee_contact" name="nominee_contact" placeholder=" " />
                                <label for="nominee_contact">Contact</label>
                                <div class="form-error" id="error_nominee_contact"></div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info mb-2" id="addNomineeRecord">Add Nominee</button>
                        <h5>Nominee Records</h5>
                        <table class="table table-bordered" id="nomineeRecordsTable">
                            <thead>
                                <tr>
                                    <th>Name</th><th>Relation</th><th>Percentage</th><th>Contact</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <!-- Career Sub-Tab -->
                    <div class="tab-pane fade" id="personal-career" role="tabpanel">
                        <h5>Add Employment Record</h5>
                        <div id="career-form-row" class="form-row">
                            <div class="form-group col-md-2">
                                <input type="date" class="form-control" id="career_from_date" name="career_from_date" placeholder=" " />
                                <label for="career_from_date">From Date *</label>
                                <div class="form-error" id="error_career_from_date"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="date" class="form-control" id="career_to_date" name="career_to_date" placeholder=" " />
                                <label for="career_to_date">To Date *</label>
                                <div class="form-error" id="error_career_to_date"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_employer" name="career_employer" placeholder=" " />
                                <label for="career_employer">Employer *</label>
                                <div class="form-error" id="error_career_employer"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_employer_code" name="career_employer_code" placeholder=" " />
                                <label for="career_employer_code">Employer Code</label>
                                <div class="form-error" id="error_career_employer_code"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_employment_status" name="career_employment_status" placeholder=" " />
                                <label for="career_employment_status">Employment Status</label>
                                <div class="form-error" id="error_career_employment_status"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_position" name="career_position" placeholder=" " />
                                <label for="career_position">Position *</label>
                                <div class="form-error" id="error_career_position"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_department" name="career_department" placeholder=" " />
                                <label for="career_department">Department</label>
                                <div class="form-error" id="error_career_department"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_address" name="career_address" placeholder=" " />
                                <label for="career_address">Address *</label>
                                <div class="form-error" id="error_career_address"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="career_starting_salary" name="career_starting_salary" placeholder=" " />
                                <label for="career_starting_salary">Starting Salary</label>
                                <div class="form-error" id="error_career_starting_salary"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="career_starting_other_comp" name="career_starting_other_comp" placeholder=" " />
                                <label for="career_starting_other_comp">Starting Other Compensation</label>
                                <div class="form-error" id="error_career_starting_other_comp"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="career_final_salary" name="career_final_salary" placeholder=" " />
                                <label for="career_final_salary">Final Salary</label>
                                <div class="form-error" id="error_career_final_salary"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="number" class="form-control" id="career_final_other_comp" name="career_final_other_comp" placeholder=" " />
                                <label for="career_final_other_comp">Final Other Compensation</label>
                                <div class="form-error" id="error_career_final_other_comp"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_responsibility" name="career_responsibility" placeholder=" " />
                                <label for="career_responsibility">Responsibility *</label>
                                <div class="form-error" id="error_career_responsibility"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_achievement" name="career_achievement" placeholder=" " />
                                <label for="career_achievement">Achievement</label>
                                <div class="form-error" id="error_career_achievement"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_reason_for_change" name="career_reason_for_change" placeholder=" " />
                                <label for="career_reason_for_change">Reason for Change *</label>
                                <div class="form-error" id="error_career_reason_for_change"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_contact_person" name="career_contact_person" placeholder=" " />
                                <label for="career_contact_person">Contact Person</label>
                                <div class="form-error" id="error_career_contact_person"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_contact_person_job_title" name="career_contact_person_job_title" placeholder=" " />
                                <label for="career_contact_person_job_title">Contact Person Job Title</label>
                                <div class="form-error" id="error_career_contact_person_job_title"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_contact_person_department" name="career_contact_person_department" placeholder=" " />
                                <label for="career_contact_person_department">Contact Person Department</label>
                                <div class="form-error" id="error_career_contact_person_department"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_contact_person_mobile_no" name="career_contact_person_mobile_no" placeholder=" " />
                                <label for="career_contact_person_mobile_no">Contact Person Mobile No</label>
                                <div class="form-error" id="error_career_contact_person_mobile_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="email" class="form-control" id="career_contact_person_email" name="career_contact_person_email" placeholder=" " />
                                <label for="career_contact_person_email">Contact Person Email</label>
                                <div class="form-error" id="error_career_contact_person_email"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="url" class="form-control" id="career_company_website" name="career_company_website" placeholder=" " />
                                <label for="career_company_website">Company Website</label>
                                <div class="form-error" id="error_career_company_website"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_uan_no" name="career_uan_no" placeholder=" " />
                                <label for="career_uan_no">UAN No</label>
                                <div class="form-error" id="error_career_uan_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_epf_ac_no" name="career_epf_ac_no" placeholder=" " />
                                <label for="career_epf_ac_no">EPF A/c No</label>
                                <div class="form-error" id="error_career_epf_ac_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_epf_region" name="career_epf_region" placeholder=" " />
                                <label for="career_epf_region">EPF Region</label>
                                <div class="form-error" id="error_career_epf_region"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_esi_ac_no" name="career_esi_ac_no" placeholder=" " />
                                <label for="career_esi_ac_no">ESI A/c No</label>
                                <div class="form-error" id="error_career_esi_ac_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_scheme_certificate_no" name="career_scheme_certificate_no" placeholder=" " />
                                <label for="career_scheme_certificate_no">Scheme Certificate No</label>
                                <div class="form-error" id="error_career_scheme_certificate_no"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="career_pension_payment_order_no" name="career_pension_payment_order_no" placeholder=" " />
                                <label for="career_pension_payment_order_no">Pension Payment Order No</label>
                                <div class="form-error" id="error_career_pension_payment_order_no"></div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info mb-2" id="addCareerRecord">Add Employment Record</button>
                        <h5>Employment Records</h5>
                        <table class="table table-bordered" id="careerRecordsTable">
                            <thead>
                                <tr>
                                    <th>From</th><th>To</th><th>Employer</th><th>Position</th><th>Department</th><th>Reason</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <!-- Medical Sub-Tab -->
                    <div class="tab-pane fade" id="personal-medical" role="tabpanel">
                        <h5>Medical History</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="medical_chronic_conditions" name="medical_chronic_conditions" placeholder=" " />
                                <label for="medical_chronic_conditions">Chronic Conditions</label>
                                <div class="form-error" id="error_medical_chronic_conditions"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="medical_allergies" name="medical_allergies" placeholder=" " />
                                <label for="medical_allergies">Allergies</label>
                                <div class="form-error" id="error_medical_allergies"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="medical_medications" name="medical_medications" placeholder=" " />
                                <label for="medical_medications">Medications</label>
                                <div class="form-error" id="error_medical_medications"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="medical_past_surgeries" name="medical_past_surgeries" placeholder=" " />
                                <label for="medical_past_surgeries">Past Surgeries</label>
                                <div class="form-error" id="error_medical_past_surgeries"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="medical_emergency_contact_name" name="medical_emergency_contact_name" placeholder=" " />
                                <label for="medical_emergency_contact_name">Emergency Contact Name</label>
                                <div class="form-error" id="error_medical_emergency_contact_name"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="medical_emergency_contact_number" name="medical_emergency_contact_number" placeholder=" " />
                                <label for="medical_emergency_contact_number">Emergency Contact Number</label>
                                <div class="form-error" id="error_medical_emergency_contact_number"></div>
                            </div>
                        </div>
                    </div>
                    <!-- Emergency Sub-Tab -->
                    <div class="tab-pane fade" id="personal-emergency" role="tabpanel">
                        <h5>Add Emergency Contact</h5>
                        <div id="emergency-form-row" class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="emergency_name" name="emergency_name" placeholder=" " />
                                <label for="emergency_name">Name *</label>
                                <div class="form-error" id="error_emergency_name"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="emergency_relation" name="emergency_relation" placeholder=" " />
                                <label for="emergency_relation">Relation *</label>
                                <div class="form-error" id="error_emergency_relation"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="emergency_contact1" name="emergency_contact1" placeholder=" " />
                                <label for="emergency_contact1">Contact No 1 *</label>
                                <div class="form-error" id="error_emergency_contact1"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="emergency_contact2" name="emergency_contact2" placeholder=" " />
                                <label for="emergency_contact2">Contact No 2</label>
                                <div class="form-error" id="error_emergency_contact2"></div>
                            </div>
                            <div class="form-group col-md-2">
                                <input type="text" class="form-control" id="emergency_contact3" name="emergency_contact3" placeholder=" " />
                                <label for="emergency_contact3">Contact No 3</label>
                                <div class="form-error" id="error_emergency_contact3"></div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info mb-2" id="addEmergencyRecord">Add Emergency Contact</button>
                        <h5>Emergency Contact Records</h5>
                        <table class="table table-bordered" id="emergencyRecordsTable">
                            <thead>
                                <tr>
                                    <th>Name</th><th>Relation</th><th>Contact 1</th><th>Contact 2</th><th>Contact 3</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <!-- Attachments Sub-Tab -->
                    <div class="tab-pane fade" id="personal-attachments" role="tabpanel">
                        <h5>Add Attachment</h5>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <input type="text" class="form-control" id="attachment_description" name="attachment_description" placeholder=" " />
                                <label for="attachment_description">Description</label>
                                <div class="form-error" id="error_attachment_description"></div>
                            </div>
                            <div class="form-group col-md-4">
                                <input type="file" class="form-control" id="attachment_file" name="attachment_file" />
                                <label for="attachment_file">File</label>
                                <div class="form-error" id="error_attachment_file"></div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-info mb-2" id="addAttachmentRecord">Add Attachment</button>
                        <h5>Attachments</h5>
                        <table class="table table-bordered" id="attachmentRecordsTable">
                            <thead>
                                <tr>
                                    <th>Date</th><th>Description</th><th>File Name</th><th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Payment Tab -->
            <div class="tab-pane fade" id="payment" role="tabpanel">
                <h5>Payment Details</h5>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_type" name="payment_type" placeholder="e.g., Bank Transfer" />
                        <label for="payment_type">Type</label>
                        <div class="form-error" id="error_payment_type"></div>
                    </div>
                    <div class="form-group col-md-2">
                        <input type="number" class="form-control" id="payment_percent" name="payment_percent" min="0" max="100" placeholder="e.g., 100" />
                        <label for="payment_percent">Percent</label>
                        <div class="form-error" id="error_payment_percent"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_type2" name="payment_type2" placeholder="e.g., Bank Transfer" />
                        <label for="payment_type2">Type2</label>
                        <div class="form-error" id="error_payment_type2"></div>
                    </div>
                    <div class="form-group col-md-2">
                        <input type="number" class="form-control" id="payment_percent2" name="payment_percent2" min="0" max="100" placeholder="e.g., 100" />
                        <label for="payment_percent2">Percent2</label>
                        <div class="form-error" id="error_payment_percent2"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_bank_name" name="payment_bank_name" placeholder=" " />
                        <label for="payment_bank_name">Bank Name</label>
                        <div class="form-error" id="error_payment_bank_name"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_branch" name="payment_branch" placeholder=" " />
                        <label for="payment_branch">Branch</label>
                        <div class="form-error" id="error_payment_branch"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_ifsc_code" name="payment_ifsc_code" placeholder=" " />
                        <label for="payment_ifsc_code">IFSC Code</label>
                        <div class="form-error" id="error_payment_ifsc_code"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_account_no" name="payment_account_no" placeholder=" " />
                        <label for="payment_account_no">A/C No</label>
                        <div class="form-error" id="error_payment_account_no"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_beneficiary_name" name="payment_beneficiary_name" placeholder=" " />
                        <label for="payment_beneficiary_name">Beneficiary Name</label>
                        <div class="form-error" id="error_payment_beneficiary_name"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="payment_name_in_bank" name="payment_name_in_bank" placeholder=" " />
                        <label for="payment_name_in_bank">Name In Bank</label>
                        <div class="form-error" id="error_payment_name_in_bank"></div>
                    </div>
                </div>
            </div>
            <!-- Administration Tab -->
            <div class="tab-pane fade" id="admin" role="tabpanel">
                <ul class="nav nav-pills mb-3" id="adminSubTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="admin-main-tab" data-toggle="pill" href="#admin-main" role="tab">Main</a>
                    </li>
                </ul>
                <div class="tab-content" id="adminSubTabContent">
                    <!-- Main Sub-Tab -->
                    <div class="tab-pane fade show active" id="admin-main" role="tabpanel">
                        <h5>Administration Details</h5>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="admin_start_date" name="admin_start_date" placeholder=" " />
                                <label for="admin_start_date">Start Date</label>
                                <div class="form-error" id="error_admin_start_date"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_status" name="admin_status" placeholder="e.g., Confirmed" />
                                <label for="admin_status">Status</label>
                                <div class="form-error" id="error_admin_status"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="number" class="form-control" id="admin_probation_period" name="admin_probation_period" placeholder=" " />
                                <label for="admin_probation_period">Probation Period (Months)</label>
                                <div class="form-error" id="error_admin_probation_period"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="admin_confirmation_date" name="admin_confirmation_date" placeholder=" " />
                                <label for="admin_confirmation_date">Confirmation Date</label>
                                <div class="form-error" id="error_admin_confirmation_date"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_grade" name="admin_grade" placeholder=" " />
                                <label for="admin_grade">Grade</label>
                                <div class="form-error" id="error_admin_grade"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_division" name="admin_division" placeholder=" " />
                                <label for="admin_division">Division</label>
                                <div class="form-error" id="error_admin_division"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_job_title" name="admin_job_title" placeholder=" " />
                                <label for="admin_job_title">Job Title</label>
                                <div class="form-error" id="error_admin_job_title"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="number" class="form-control" id="admin_notice_period" name="admin_notice_period" placeholder=" " />
                                <label for="admin_notice_period">Notice Period (Days)</label>
                                <div class="form-error" id="error_admin_notice_period"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_attendance_cycle" name="admin_attendance_cycle" placeholder=" " />
                                <label for="admin_attendance_cycle">Attendance Cycle</label>
                                <div class="form-error" id="error_admin_attendance_cycle"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_shift" name="admin_shift" placeholder=" " />
                                <label for="admin_shift">Shift</label>
                                <div class="form-error" id="error_admin_shift"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_manager" name="admin_manager" placeholder=" " />
                                <label for="admin_manager">Manager</label>
                                <div class="form-error" id="error_admin_manager"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_manager_name" name="admin_manager_name" placeholder=" " />
                                <label for="admin_manager_name">Name (Manager Name)</label>
                                <div class="form-error" id="error_admin_manager_name"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="admin_resignation_date" name="admin_resignation_date" placeholder=" " />
                                <label for="admin_resignation_date">Resignation Date</label>
                                <div class="form-error" id="error_admin_resignation_date"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_resp_acceptance" name="admin_resp_acceptance" placeholder=" " />
                                <label for="admin_resp_acceptance">Resp. Acceptance</label>
                                <div class="form-error" id="error_admin_resp_acceptance"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_reason_for_leaving" name="admin_reason_for_leaving" placeholder=" " />
                                <label for="admin_reason_for_leaving">Reason for Leaving</label>
                                <div class="form-error" id="error_admin_reason_for_leaving"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="admin_last_working_date" name="admin_last_working_date" placeholder=" " />
                                <label for="admin_last_working_date">Last Working Date</label>
                                <div class="form-error" id="error_admin_last_working_date"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_old_emp_code" name="admin_old_emp_code" placeholder=" " />
                                <label for="admin_old_emp_code">Old Emp Code</label>
                                <div class="form-error" id="error_admin_old_emp_code"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="text" class="form-control" id="admin_old_emp_code_name" name="admin_old_emp_code_name" placeholder=" " />
                                <label for="admin_old_emp_code_name">Name (Old Emp Code Name)</label>
                                <div class="form-error" id="error_admin_old_emp_code_name"></div>
                            </div>
                            <div class="form-group col-md-3">
                                <input type="date" class="form-control" id="admin_initial_joining_date" name="admin_initial_joining_date" placeholder=" " />
                                <label for="admin_initial_joining_date">Initial Joining Date</label>
                                <div class="form-error" id="error_admin_initial_joining_date"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Statutory Tab -->
            <div class="tab-pane fade" id="statutory" role="tabpanel">
                <h5>Statutory Details</h5>
                <h6>Provident Fund</h6>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_pf_ac_no" name="stat_pf_ac_no" placeholder=" " />
                        <label for="stat_pf_ac_no">A/C No</label>
                        <div class="form-error" id="error_stat_pf_ac_no"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="date" class="form-control" id="stat_pf_joining_date" name="stat_pf_joining_date" placeholder=" " />
                        <label for="stat_pf_joining_date">Joining Date</label>
                        <div class="form-error" id="error_stat_pf_joining_date"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_pf_uan" name="stat_pf_uan" placeholder=" " />
                        <label for="stat_pf_uan">Universal A/C No (UAN)</label>
                        <div class="form-error" id="error_stat_pf_uan"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_pf_settlement" name="stat_pf_settlement" placeholder=" " />
                        <label for="stat_pf_settlement">Settlement</label>
                        <div class="form-error" id="error_stat_pf_settlement"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_eps_ac_no" name="stat_eps_ac_no" placeholder=" " />
                        <label for="stat_eps_ac_no">EPS A/C No</label>
                        <div class="form-error" id="error_stat_eps_ac_no"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="date" class="form-control" id="stat_eps_joining_date" name="stat_eps_joining_date" placeholder=" " />
                        <label for="stat_eps_joining_date">EPS Joining Date</label>
                        <div class="form-error" id="error_stat_eps_joining_date"></div>
                    </div>
                </div>
                <h6>ESI</h6>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_esi_ac_no" name="stat_esi_ac_no" placeholder=" " />
                        <label for="stat_esi_ac_no">A/C No</label>
                        <div class="form-error" id="error_stat_esi_ac_no"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="date" class="form-control" id="stat_esi_joining_date" name="stat_esi_joining_date" placeholder=" " />
                        <label for="stat_esi_joining_date">Joining Date</label>
                        <div class="form-error" id="error_stat_esi_joining_date"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_esi_locality" name="stat_esi_locality" placeholder=" " />
                        <label for="stat_esi_locality">Locality</label>
                        <div class="form-error" id="error_stat_esi_locality"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_esi_dispensary" name="stat_esi_dispensary" placeholder=" " />
                        <label for="stat_esi_dispensary">Dispensary</label>
                        <div class="form-error" id="error_stat_esi_dispensary"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_esi_doctor_code" name="stat_esi_doctor_code" placeholder=" " />
                        <label for="stat_esi_doctor_code">Doctor Code</label>
                        <div class="form-error" id="error_stat_esi_doctor_code"></div>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_esi_doctor_name" name="stat_esi_doctor_name" placeholder=" " />
                        <label for="stat_esi_doctor_name">Doctor Name</label>
                        <div class="form-error" id="error_stat_esi_doctor_name"></div>
                    </div>
                </div>
                <h6>Professional Tax</h6>
                <div class="form-row">
                    <div class="form-group col-md-3">
                        <input type="text" class="form-control" id="stat_ptax_region" name="stat_ptax_region" placeholder=" " />
                        <label for="stat_ptax_region">P. Tax Region</label>
                        <div class="form-error" id="error_stat_ptax_region"></div>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-success mt-3">Save & Accept</button>
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Tabs switching
$('.custom-tab').on('click', function() {
    $('.custom-tab').removeClass('active');
    $(this).addClass('active');
    var tab = $(this).data('tab');
    $('.tab-pane').hide();
    $('#' + tab).show();
});
// Show first tab by default
$(document).ready(function() {
    $('.tab-pane').hide();
    $('#master').show();
});
// Floating label fix for autofill
$('.form-control').each(function() {
    if($(this).val()) {
        $(this).addClass('filled');
    }
});
$('.form-control').on('blur input', function() {
    if($(this).val()) {
        $(this).addClass('filled');
    } else {
        $(this).removeClass('filled');
    }
});
// Validation
function showError(field, message) {
    $('#error_' + field).text(message);
    $('#' + field).addClass('is-invalid');
}
function clearError(field) {
    $('#error_' + field).text('');
    $('#' + field).removeClass('is-invalid');
}
function showAlert(type, message) {
    var alertHtml = '<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">' +
        message +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button></div>';
    $('#formAlert').html(alertHtml);
    setTimeout(function() { $(".alert").alert('close'); }, 4000);
}
$('#employeeForm').on('submit', function(e) {
    e.preventDefault();
    var valid = true;
    // Example validation for required fields (repeat for all required fields)
    if(!$('#employee_code').val()) {
        showError('employee_code', 'Employee Code is required');
        valid = false;
    } else {
        clearError('employee_code');
    }
    // ...repeat for other fields...
    if(valid) {
        showAlert('success', 'Form submitted successfully!');
        // Submit via AJAX or normal submit as per your logic
    } else {
        showAlert('danger', 'Please fix the errors in the form.');
    }
});
</script>
<?php $this->load->view('footer'); ?> 