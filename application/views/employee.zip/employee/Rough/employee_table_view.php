<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 16/08/2017
 * Time: 14:52
 */

$this->load->view('header');
$this->load->view('left_sidebar');
$this->load->view('topbar');
?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Employee Management</h2>
    </div>
    <div class="col-lg-2">
        <button class="btn btn-primary" id="btn_addrecord" type="button">
            <i class="fa fa-plus"></i> Add New Employee
        </button>
    </div>
</div>

<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Employee Records</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <!-- Search and Filter Section -->
                    <div class="row m-b-sm m-t-sm">
                        <div class="col-md-12">
                            <div class="input-group">
                                <input type="text" class="form-control" id="searchInput" placeholder="Search employees...">
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-primary" id="searchBtn">
                                        <i class="fa fa-search"></i> Search
                                    </button>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Employee Table -->
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover dataTables-example" id="employeeTable">
                            <thead>
                                <tr>
                                    <th>Sl. No</th>
                                    <th>Employee ID</th>
                                    <th>Name</th>
                                    <th>Department</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Join Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data will be loaded dynamically -->
                            </tbody>
                        </table>
                    </div>

                    <!-- Add/Edit Employee Modal -->
                    <div class="modal inmodal" id="employeeModal" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content animated bounceInRight">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">
                                        <span aria-hidden="true">&times;</span>
                                        <span class="sr-only">Close</span>
                                    </button>
                                    <h4 class="modal-title">Employee Information</h4>
                                </div>
                                <div class="modal-body" id="modal_content">
                                    <!-- Form will be loaded dynamically -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('footer'); ?>

<!-- Required Scripts -->
<script src="<?php echo base_url() ?>assets/js/plugins/dataTables/datatables.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/plugins/dataTables/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function() {
    // Initialize DataTable
    var employeeTable = $('#employeeTable').DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo site_url('employee/getrecord')?>",
            "type": "POST",
            "data": function(d) {
                d.search = $('#searchInput').val();
            }
        },
        "columns": [
            {"data": "sl_no"},
            {"data": "employee_id"},
            {"data": "employee_name"},
            {"data": "department"},
            {"data": "email"},
            {"data": "contact"},
            {"data": "join_date"},
            {"data": "status"},
            {
                "data": null,
                "render": function(data, type, row) {
                    return '<button class="btn btn-info btn-sm btn_editrecord" refid="' + row.id + '"><i class="fa fa-edit"></i></button> ' +
                           '<button class="btn btn-danger btn-sm btn_deleterecord" refid="' + row.id + '"><i class="fa fa-trash"></i></button>';
                }
            }
        ],
        "order": [[0, "asc"]],
        "pageLength": 10,
        "lengthMenu": [[10, 25, 50, 100], [10, 25, 50, 100]],
        "dom": '<"html5buttons"B>lTfgitp',
        "buttons": [
            {extend: 'copy'},
            {extend: 'csv'},
            {extend: 'excel', title: 'Employee Records'},
            {extend: 'pdf', title: 'Employee Records'},
            {
                extend: 'print',
                customize: function(win) {
                    $(win.document.body).addClass('white-bg');
                    $(win.document.body).css('font-size', '12px');
                    $(win.document.body).find('table').addClass('compact').css('font-size', 'inherit');
                }
            }
        ]
    });

    // Add New Employee
    $("#btn_addrecord").click(function() {
        $.ajax({
            type: 'POST',
            url: '<?php echo site_url('employee/addpopup')?>',
            cache: false,
            data: {popup: 'popup'},
            success: function(data) {
                $("#modal_content").html(data);
                $("#employeeModal").modal('show');
            },
            error: function() {
                swal("Error", "Please check your internet connection.", "error");
            }
        });
    });

    // Edit Employee
    $(document).on("click", ".btn_editrecord", function() {
        var refid = $(this).attr('refid');
        $.ajax({
            type: 'GET',
            url: '<?php echo site_url('employee/editpopup')?>',
            data: {popup: 'popup', id: refid},
            success: function(data) {
                $("#modal_content").html(data);
                $("#employeeModal").modal('show');
            },
            error: function() {
                swal("Error", "Please check your internet connection.", "error");
            }
        });
    });

    // Delete Employee
    $(document).on("click", ".btn_deleterecord", function(e) {
        e.preventDefault();
        var ref = $(this);
        var refid = $(this).attr('refid');
        
        swal({
            title: "Are you sure?",
            text: "You want to delete this employee record!",
            type: "warning",
            showCancelButton: true,
            confirmButtonClass: 'btn-danger',
            confirmButtonText: 'Yes, delete it!',
            closeOnConfirm: false
        }, function() {
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('employee/deleterecord')?>',
                data: {delete: refid},
                success: function(data) {
                    if(data == "true") {
                        employeeTable.ajax.reload();
                        swal("Deleted!", "Employee record has been deleted.", "success");
                    }
                },
                error: function() {
                    swal("Error", "Please check your internet connection.", "error");
                }
            });
        });
    });

    // Search functionality
    $("#searchBtn").click(function() {
        employeeTable.ajax.reload();
    });

    // Search on Enter key
    $("#searchInput").keypress(function(e) {
        if(e.which == 13) {
            employeeTable.ajax.reload();
        }
    });

    // Refresh table when modal is closed
    $("#employeeModal").on("hidden.bs.modal", function() {
        employeeTable.ajax.reload();
    });
});
</script> 