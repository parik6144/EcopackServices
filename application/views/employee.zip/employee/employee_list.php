<?php $this->load->view('header'); ?>
<?php $this->load->view('left_sidebar'); ?>
<?php $this->load->view('topbar'); ?>

<style>
    .employee-list-container {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 12px rgba(0,0,0,0.07);
        padding: 24px;
        margin: 24px auto;
        max-width: 1400px;
    }
    .employee-list-container h2 {
        font-weight: 600;
        margin-bottom: 20px;
        color: #1976d2;
    }
    .table {
        width: 100%;
        margin-bottom: 1rem;
        background-color: transparent;
        border-collapse: collapse;
    }
    .table th {
        background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
        color: white;
        font-weight: 500;
        padding: 12px;
        border: none;
    }
    .table td {
        padding: 12px;
        vertical-align: middle;
        border-bottom: 1px solid #e0e0e0;
    }
    .table tbody tr:hover {
        background-color: #f5f5f5;
    }
    .btn-add-employee {
        background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
        color: white;
        border: none;
        padding: 8px 20px;
        border-radius: 6px;
        margin-bottom: 20px;
        transition: all 0.3s ease;
    }
    .btn-add-employee:hover {
        background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
        color: white;
        box-shadow: 0 2px 8px rgba(0,150,136,0.15);
    }
    .action-buttons {
        display: flex;
        gap: 8px;
    }
    .btn-edit, .btn-delete {
        padding: 6px 12px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    .btn-edit {
        background: #1976d2;
        color: white;
    }
    .btn-delete {
        background: #dc3545;
        color: white;
    }
    .btn-edit:hover, .btn-delete:hover {
        opacity: 0.9;
        transform: translateY(-1px);
    }
    .employee-photo {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #e0e0e0;
    }
</style>

<div class="employee-list-container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Employee List</h2>
        <a href="<?= site_url('employee/add') ?>" class="btn btn-add-employee">
            <i class="fa fa-plus"></i> Add New Employee
        </a>
    </div>
    
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Employee Code</th>
                    <th>Photo</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Designation</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($employees as $emp): ?>
                <tr>
                    <td><?= $emp['employee_code'] ?></td>
                    <td>
                        <?php if (!empty($emp['photo'])): ?>
                            <img src="<?= base_url('uploads/employee_photos/'.$emp['photo']) ?>" class="employee-photo" alt="Employee Photo">
                        <?php else: ?>
                            <img src="<?= base_url('assets/images/default-avatar.png') ?>" class="employee-photo" alt="Default Photo">
                        <?php endif; ?>
                    </td>
                    <td><?= $emp['first_name'] . ' ' . $emp['last_name'] ?></td>
                    <td><?= $emp['department'] ?></td>
                    <td><?= $emp['designation'] ?></td>
                    <td><?= $emp['email'] ?></td>
                    <td><?= $emp['phone'] ?></td>
                    <td>
                        <span class="badge <?= $emp['status'] == 'active' ? 'badge-success' : 'badge-danger' ?>">
                            <?= ucfirst($emp['status']) ?>
                        </span>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <a href="<?= site_url('employee/edit/'.$emp['employee_id']) ?>" class="btn-edit">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <button onclick="deleteEmployee(<?= $emp['employee_id'] ?>)" class="btn-delete">
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function deleteEmployee(id) {
    if(confirm('Are you sure you want to delete this employee?')) {
        fetch('<?= site_url('employee/delete/') ?>' + id, {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(res => res.json())
        .then(data => {
            if(data.status === 'success') {
                alert(data.msg);
                location.reload();
            } else {
                alert('Error deleting employee');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error deleting employee');
        });
    }
}
</script>

<?php $this->load->view('footer'); ?> 