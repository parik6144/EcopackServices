<?php
// Start: employee_form_statutory.php - Description: This file contains the Statutory tab content for the Employee Profile form.
?>
	<form id="statutoryForm" class="employee-form" enctype="multipart/form-data" novalidate>
		<input type="hidden" id="statutory_employee_id_hidden_field" name="employee_id_hidden_field" value="<?php echo isset($employee_id_encoded) ? $employee_id_encoded : ''; ?>">

		<h5>Statutory Details</h5>
		<h6>Provident Fund</h6>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_pf_ac_no" name="stat_pf_ac_no" placeholder=" " />
				<label for="stat_pf_ac_no">A/C No</label>
				<div class="form-error" id="error_stat_pf_ac_no"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="date" class="form-control" id="stat_pf_joining_date" name="stat_pf_joining_date"
					   placeholder=" " />
				<label for="stat_pf_joining_date">Joining Date</label>
				<div class="form-error" id="error_stat_pf_joining_date"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_pf_uan" name="stat_pf_uan" placeholder=" " />
				<label for="stat_pf_uan">Universal A/C No (UAN)</label>
				<div class="form-error" id="error_stat_pf_uan"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_pf_settlement" name="stat_pf_settlement"
					   placeholder=" " />
				<label for="stat_pf_settlement">Settlement</label>
				<div class="form-error" id="error_stat_pf_settlement"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_eps_ac_no" name="stat_eps_ac_no" placeholder=" " />
				<label for="stat_eps_ac_no">EPS A/C No</label>
				<div class="form-error" id="error_stat_eps_ac_no"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="date" class="form-control" id="stat_eps_joining_date" name="stat_eps_joining_date"
					   placeholder=" " />
				<label for="stat_eps_joining_date">EPS Joining Date</label>
				<div class="form-error" id="error_stat_eps_joining_date"></div>
			</div>
		</div>
		<h6>ESI</h6>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_esi_ac_no" name="stat_esi_ac_no" placeholder=" " />
				<label for="stat_esi_ac_no">A/C No</label>
				<div class="form-error" id="error_stat_esi_ac_no"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="date" class="form-control" id="stat_esi_joining_date" name="stat_esi_joining_date"
					   placeholder=" " />
				<label for="stat_esi_joining_date">Joining Date</label>
				<div class="form-error" id="error_stat_esi_joining_date"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_esi_locality" name="stat_esi_locality"
					   placeholder=" " />
				<label for="stat_esi_locality">Locality</label>
				<div class="form-error" id="error_stat_esi_locality"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_esi_dispensary" name="stat_esi_dispensary"
					   placeholder=" " />
				<label for="stat_esi_dispensary">Dispensary</label>
				<div class="form-error" id="error_stat_esi_dispensary"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_esi_doctor_code" name="stat_esi_doctor_code"
					   placeholder=" " />
				<label for="stat_esi_doctor_code">Doctor Code</label>
				<div class="form-error" id="error_stat_esi_doctor_code"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_esi_doctor_name" name="stat_esi_doctor_name"
					   placeholder=" " />
				<label for="stat_esi_doctor_name">Doctor Name</label>
				<div class="form-error" id="error_stat_esi_doctor_name"></div>
			</div>
		</div>
		<h6>Professional Tax</h6>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="stat_ptax_region" name="stat_ptax_region"
					   placeholder=" " />
				<label for="stat_ptax_region">P. Tax Region</label>
				<div class="form-error" id="error_stat_ptax_region"></div>
			</div>
		</div>
		<div class="d-flex justify-content-start gap-2 mt-3">
			<button type="submit" class="btn btn-success">Save & Accept Statutory</button>
			<button type="button" class="btn btn-warning reset-form-btn" data-form-id="statutoryForm">Reset Statutory</button>
		</div>
	</form>

