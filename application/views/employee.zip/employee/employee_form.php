<?php $this->load->view('header'); ?>
<?php $this->load->view('left_sidebar'); ?>
<?php $this->load->view('topbar'); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />

<style>
	.emp-profile-container {
		background: #fff;
		border-radius: 8px;
		box-shadow: 0 2px 12px rgba(0,0,0,0.07);
		padding: 18px 10px;
		margin: 24px auto 24px auto;
		max-width: 1200px;
	}
	.emp-profile-container h2 {
		font-weight: 600;
		margin-bottom: 18px;
		letter-spacing: 0.5px;
		font-size: 1.3rem;
	}
	/* Updated nav-link styling */
	.nav-tabs .nav-item .nav-link {
		background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
		color: #fff;
		border-radius: 8px 8px 0 0;
		padding: 7px 16px;
		font-weight: 500;
		font-size: 1rem;
		margin-right: 2px;
		box-shadow: 0 1px 4px rgba(0,0,0,0.04);
		border: none;
		transition: background 0.2s, color 0.2s;
		cursor: pointer;
		opacity: 0.92;
		min-width: 80px;
	}
	.nav-tabs .nav-item .nav-link.active,
	.nav-tabs .nav-item .nav-link:hover {
		background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
		color: #fff;
		opacity: 1;
		box-shadow: 0 2px 8px rgba(25, 118, 210, 0.08);
	}

	.tab-content {
		margin-top: 10px;
	}
	.form-group {
		position: relative;
		margin-bottom: 12px;
	}
	.form-control {
		border-radius: 6px;
		border: 1px solid #e0e0e0;
		padding: 8px 8px 4px 8px; /* Adjusted padding to ensure text doesn't hide behind label */
		font-size: 1rem;
		background: #fafbfc;
		transition: border 0.2s, box-shadow 0.2s;
		height: 38px;
		min-height: 38px;
	}
	.form-control:focus {
		border-color: #1976d2;
		box-shadow: 0 0 0 1.5px #1976d220;
		background: #fff;
	}
	/* Style for invalid input */
	.form-control.is-invalid {
		border-color: #dc3545;
		padding-right: calc(1.5em + 0.75rem); /* Ensure space for feedback icon */
		background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='none' stroke='%23dc3545' viewBox='0 0 12 12'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
		background-repeat: no-repeat;
		background-position: right calc(0.375em + 0.1875rem) center;
		background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
	}
	.form-group label {
		position: absolute;
		top: 7px; /* Adjusted to initial position for label */
		left: 12px;
		font-size: 0.97rem;
		color: #888;
		background: transparent;
		pointer-events: none;
		transition: 0.2s;
		padding: 0 2px;
		z-index: 1; /* Ensure label is above input when not focused/filled */
		font-weight: 500;
		margin-bottom: 2px;
	}
	/* Floating label effect */
	.form-control:focus + label,
	.form-control:not(:placeholder-shown) + label,
	.form-control.filled + label { /* Added filled for autofill */
		top: -10px; /* Moves label up */
		left: 8px; /* Moves label slightly left */
		font-size: 0.89rem;
		color: #1976d2;
		background: #fff; /* Background to prevent text bleeding through */
		padding: 0 4px;
		z-index: 2; /* Keep label above input text */
	}

	/* Important: Hide placeholders when label is floated to prevent overlap */
	.form-control::-webkit-input-placeholder {
		color: transparent;
	}
	.form-control:-moz-placeholder { /* Firefox 18- */
		color: transparent;
	}
	.form-control::-moz-placeholder {  /* Firefox 19+ */
		color: transparent;
	}
	.form-control:-ms-input-placeholder {
		color: transparent;
	}
	.form-control.is-invalid + label { /* Ensure label stays correctly styled for invalid floating labels */
		color: #dc3545 !important; /* Keep error color */
	}


	.form-error {
		color: #d32f2f;
		font-size: 0.89rem;
		margin-top: 1px;
		margin-left: 1px;
		font-weight: 400;
	}
	.section-heading {
		font-weight: 600;
		font-size: 1.01rem;
		margin: 18px 0 8px 0;
		color: #1976d2;
	}
	.btn-success, .btn-info, .btn-warning { /* Added .btn-warning */
		border-radius: 6px;
		padding: 7px 18px;
		font-weight: 500;
		font-size: 1rem;
		box-shadow: 0 1px 4px rgba(0,150,136,0.07);
		border: none;
		transition: background 0.2s, box-shadow 0.2s;
	}
	.btn-success {
		background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
		color: #fff;
	}
	.btn-success:hover {
		background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
		color: #fff;
		box-shadow: 0 2px 8px rgba(0,150,136,0.10);
	}
	.btn-info {
		background: linear-gradient(90deg, #1976d2 60%, #009688 100%);
		color: #fff;
	}
	.btn-info:hover {
		background: linear-gradient(90deg, #009688 60%, #1976d2 100%);
		color: #fff;
		box-shadow: 0 2px 8px rgba(25, 118, 210, 0.10);
	}
	.btn-warning { /* Styling for Reset button */
		background: linear-gradient(90deg, #ffc107 60%, #ff8c00 100%);
		color: #333;
	}
	.btn-warning:hover {
		background: linear-gradient(90deg, #ff8c00 60%, #ffc107 100%);
		color: #333;
		box-shadow: 0 2px 8px rgba(255, 193, 7, 0.10);
	}

	.alert {
		border-radius: 6px;
		font-size: 0.98rem;
		margin-bottom: 12px;
		box-shadow: 0 1px 4px rgba(25, 118, 210, 0.04);
	}
	.form-row {
		margin-bottom: 6px;
	}
	@media (max-width: 768px) {
		.emp-profile-container {
			padding: 6px 1px;
		}
		.nav-tabs .nav-item .nav-link { /* Adjusted for Bootstrap nav-link */
			padding: 5px 5px;
			font-size: 0.93rem;
		}
	}
	.nav-pills .nav-link {
		background-color: #e9ecef;
		color: #495057;
		margin-right: 5px;
		border-radius: 5px;
	}
	.nav-pills .nav-link.active {
		background-color: #007bff;
		color: #fff;
	}

	/* Photo Upload Styling */
	.photo-upload-container {
		border: 2px dashed #ccc;
		border-radius: 8px;
		padding: 18px;
		text-align: center;
		background: #fafafa;
		margin-bottom: 10px;
		min-height: 140px;
		position: relative;
		display: flex; /* Use flexbox for centering content */
		flex-direction: column;
		align-items: center;
		justify-content: center;
		cursor: pointer; /* Indicate clickable area */
	}
	.photo-upload-container.drag-over {
		border-color: #1976d2;
		background-color: #e6f7ff;
	}
	/* Hide native file input */
	.photo-upload-container input[type="file"] {
		display: none;
	}
	.photo-upload-container .photo-upload-icon {
		color: #888;
		font-size: 2.5rem;
		margin-bottom: 10px;
	}
	.photo-upload-container .photo-upload-text {
		color: #888;
		font-size: 0.95rem;
	}

	/* Photo Preview Frame */
	.photo-preview-frame {
		width: 150px; /* Fixed size for the frame */
		height: 150px;
		border: 2px solid #eee;
		border-radius: 50%; /* Circular frame */
		overflow: hidden; /* Hide overflow outside the circle */
		margin: 10px auto;
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: #eee;
		box-shadow: 0 0 5px rgba(0,0,0,0.1);
		position: relative; /* For positioning buttons */
	}
	.photo-preview-frame img {
		width: 100%;
		height: 100%;
		object-fit: cover; /* Crop image to fit circle */
	}

	/* Photo action buttons */
	.photo-actions {
		margin-top: 10px;
		display: flex;
		gap: 10px;
		justify-content: center;
	}

	/* Individual remove button for preview frame */
	.remove-photo-btn-overlay {
		position: absolute;
		top: 0px;
		right: 0px;
		background: rgba(255, 255, 255, 0.8);
		border: 1px solid #ddd;
		border-radius: 50%;
		width: 28px;
		height: 28px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 18px;
		color: #d32f2f;
		cursor: pointer;
		z-index: 10;
		transition: background 0.2s ease;
	}
	.remove-photo-btn-overlay:hover {
		background: #d32f2f;
		color: #fff;
	}

	/* General styling adjustments from image */
	.emp-profile-heading {
		font-size: 2rem;
		font-weight: 700;
		letter-spacing: 1px;
		color: #222;
	}
	.form-group label {
		font-weight: 500;
		margin-bottom: 2px;
	}
	.form-control {
		height: 38px;
		font-size: 1rem;
		border-radius: 6px;
	}

	/* Make Select2 match .form-control look */
	.select2-container--default .select2-selection--single {
		height: 38px !important;
		border-radius: 6px !important;
		border: 1px solid #e0e0e0 !important;
		font-size: 1rem !important;
		background: #fafbfc !important;
		display: flex;
		align-items: center;
		min-height: 38px;
		transition: border 0.2s, box-shadow 0.2s;
	}
	.select2-container--default .select2-selection--single .select2-selection__rendered {
		line-height: 38px !important;
		padding-left: 8px !important;
	}
	.select2-container--default .select2-selection--single .select2-selection__arrow {
		height: 38px !important;
		right: 8px;
	}
	.select2-container--default .select2-selection--single:focus,
	.select2-container--default .select2-selection--single.select2-selection--focus {
		border-color: #1976d2 !important;
		box-shadow: 0 0 0 1.5px #1976d220;
		background: #fff !important;
	}
	.select2-container--default .select2-selection--single.is-invalid {
		border-color: #dc3545 !important;
	}
</style>
<div class="emp-profile-container">
	<div class="d-flex justify-content-between align-items-center mb-3">
		<h2 class="emp-profile-heading flex-grow-1 text-center m-0">Employee Profile</h2>
		<div class="profile-progress-container ml-3" style="min-width:220px;">
			<div id="profile-progress-text" style="font-weight:600; color:gold;"></div>
			<div class="progress" style="background:black; border-radius:8px;">
				<div id="profile-progress-bar" class="progress-bar" role="progressbar" style="width:0%; background:linear-gradient(90deg, gold, orange); color:black; font-weight:bold;">0%</div>
			</div>
		</div>
	</div>

	<div id="formAlert"></div>
	<form id="employeeForm" enctype="multipart/form-data" novalidate>
		<ul class="nav nav-tabs" id="myTab" role="tablist">
			<li class="nav-item" role="presentation">
				<a class="nav-link active" id="master-tab" data-toggle="tab" href="#master" role="tab" aria-controls="master" aria-selected="true">Master</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-tab" data-toggle="tab" href="#personal" role="tab" aria-controls="personal" aria-selected="false">Personal</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="payment-tab" data-toggle="tab" href="#payment" role="tab" aria-controls="payment" aria-selected="false">Payment</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="admin-tab" data-toggle="tab" href="#admin" role="tab" aria-controls="admin" aria-selected="false">Administration</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="statutory-tab" data-toggle="tab" href="#statutory" role="tab" aria-controls="statutory" aria-selected="false">Statutory</a>
			</li>
		</ul>

		<div class="tab-content" id="myTabContent">
			<div class="tab-pane fade show active" id="master" role="tabpanel" aria-labelledby="master-tab">
				<div class="form-row">
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="employee_code" name="employee_code" required placeholder=" " />
						<label for="employee_code">Employee Code *</label>
						<div class="form-error" id="error_employee_code"></div>
					</div>
					<div class="form-group col-md-4">
						<select class="form-control" id="posting_city" name="posting_city" required>
							<option value="">Select Posting City *</option>
							<?php foreach($places as $place): ?>
								<option value="<?php echo $place['place_id']; ?>"><?php echo $place['place_name']; ?></option>
							<?php endforeach; ?>
						</select>
						<!--						<label for="posting_city">Posting City *</label>-->
						<div class="form-error" id="error_posting_city"></div>
					</div>
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="posting_branch" name="posting_branch" required placeholder=" " />
						<label for="posting_branch">Posting Branch *</label>
						<div class="form-error" id="error_posting_branch"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-6">
						<select class="form-control" id="employment_type" name="employment_type" required>
							<option value="">Select Employment Type *</option>
						</select>
						<div class="form-error" id="error_employment_type"></div>
					</div>
					<div class="form-group col-md-6">
						<select class="form-control" id="designation" name="designation" required>
							<option value="">Select Designation *</option>
						</select>
						<div class="form-error" id="error_designation"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="first_name" name="first_name" required placeholder=" " />
						<label for="first_name">First Name *</label>
						<div class="form-error" id="error_first_name"></div>
					</div>
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="middle_name" name="middle_name" placeholder=" " />
						<label for="middle_name">Middle Name</label>
						<div class="form-error" id="error_middle_name"></div>
					</div>
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="last_name" name="last_name" required placeholder=" " />
						<label for="last_name">Last Name *</label>
						<div class="form-error" id="error_last_name"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="company" name="company" required placeholder=" " />
						<label for="company">Company *</label>
						<div class="form-error" id="error_company"></div>
					</div>
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="salary_branch" name="salary_branch" required placeholder=" " />
						<label for="salary_branch">Salary Branch *</label>
						<div class="form-error" id="error_salary_branch"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="attendance_type" name="attendance_type" required placeholder=" " />
						<label for="attendance_type">Attendance Type *</label>
						<div class="form-error" id="error_attendance_type"></div>
					</div>
					<div class="form-group col-md-4">
						<label for="photo">Photo</label>
						<div class="photo-upload-container" id="photoDropArea">
							<input type="file" id="photo" name="photo" accept="image/*" />
							<div class="photo-upload-inner">
								<div class="photo-upload-icon">&#x2B;</div>
								<div class="photo-upload-text">Drag & Drop or Click to Upload</div>
							</div>
						</div>
						<div id="photoPreviewContainer" style="display: none; text-align: center;">
							<div class="photo-preview-frame">
								<img id="photoPreview" src="#" alt="Photo Preview" />
								<span class="remove-photo-btn-overlay">&times;</span>
							</div>
							<div class="photo-actions">
								<button type="button" class="btn btn-sm btn-info" id="changePhotoBtn">Change Photo</button>
							</div>
						</div>
						<div class="form-error" id="error_photo"></div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="personal" role="tabpanel" aria-labelledby="personal-tab">
				<ul class="nav nav-pills mb-3" id="personalSubTab" role="tablist">
					<li class="nav-item" role="presentation">
						<a class="nav-link active" id="personal-main-tab" data-toggle="pill" href="#personal-main" role="tab" aria-controls="personal-main" aria-selected="true">Main</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-address-tab" data-toggle="pill" href="#personal-address" role="tab" aria-controls="personal-address" aria-selected="false">Address</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-academic-tab" data-toggle="pill" href="#personal-academic" role="tab" aria-controls="personal-academic" aria-selected="false">Academic</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-family-tab" data-toggle="pill" href="#personal-family" role="tab" aria-controls="personal-family" aria-selected="false">Family</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-nomination-tab" data-toggle="pill" href="#personal-nomination" role="tab" aria-controls="personal-nomination" aria-selected="false">Nomination</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-career-tab" data-toggle="pill" href="#personal-career" role="tab" aria-controls="personal-career" aria-selected="false">Career</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-medical-tab" data-toggle="pill" href="#personal-medical" role="tab" aria-controls="personal-medical" aria-selected="false">Medical</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-emergency-tab" data-toggle="pill" href="#personal-emergency" role="tab" aria-controls="personal-emergency" aria-selected="false">Emergency</a>
					</li>
					<li class="nav-item" role="presentation">
						<a class="nav-link" id="personal-attachments-tab" data-toggle="pill" href="#personal-attachments" role="tab" aria-controls="personal-attachments" aria-selected="false">Attachments</a>
					</li>
				</ul>
				<div class="tab-content" id="personalSubTabContent">
					<div class="tab-pane fade show active" id="personal-main" role="tabpanel" aria-labelledby="personal-main-tab">
						<h5>General Section</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<select class="form-control" id="gender" name="gender" required>
									<option value="">Select</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
									<option value="Other">Other</option>
								</select>
								<label for="gender">Gender *</label>
								<div class="form-error" id="error_gender"></div>
							</div>
							<div class="form-group col-md-3">
								<select class="form-control" id="blood_group" name="blood_group">
									<option value="">Select</option>
									<option value="A+ve">A+ve</option>
									<option value="B+ve">B+ve</option>
									<option value="O+ve">O+ve</option>
									<option value="AB+ve">AB+ve</option>
									<option value="A-ve">A-ve</option>
									<option value="B-ve">B-ve</option>
									<option value="O-ve">O-ve</option>
									<option value="AB-ve">AB-ve</option>
								</select>
								<label for="blood_group">Blood Group</label>
								<div class="form-error" id="error_blood_group"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="dob" name="dob" required />
								<label for="dob">Date of Birth *</label>
								<div class="form-error" id="error_dob"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="father_name" name="father_name" placeholder=" " />
								<label for="father_name">Father's Name</label>
								<div class="form-error" id="error_father_name"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="email" class="form-control" id="email" name="email" required maxlength="100" placeholder=" "
									   data-toggle="tooltip" data-placement="right" title="Enter a valid email address (e.g., example@domain.com)">
								<label for="email">Email *</label>
								<div class="form-error" id="error_email"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="mobile" name="mobile" required maxlength="10" minlength="10" placeholder=" "
									   data-toggle="tooltip" data-placement="right" title="Enter a valid 10-digit mobile number (starts with 6-9)">
								<label for="mobile">Mobile No *</label>
								<div class="form-error" id="error_mobile"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="home_phone_no" name="home_phone_no" placeholder="e.g., 0123-456789" />
								<label for="home_phone_no">Home Phone No</label>
								<div class="form-error" id="error_home_phone_no"></div>
							</div>
						</div>
						<h5>Origin Section</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="caste" name="caste" placeholder=" " />
								<label for="caste">Caste</label>
								<div class="form-error" id="error_caste"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="religion" name="religion" placeholder=" " />
								<label for="religion">Religion</label>
								<div class="form-error" id="error_religion"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="citizenship" name="citizenship" placeholder=" " />
								<label for="citizenship">Citizenship</label>
								<div class="form-error" id="error_citizenship"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="country_of_birth" name="country_of_birth" placeholder=" " />
								<label for="country_of_birth">Country of Birth</label>
								<div class="form-error" id="error_country_of_birth"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<select class="form-control" id="disabilities" name="disabilities">
									<option value="">Select</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<label for="disabilities">Disabilities</label>
								<div class="form-error" id="error_disabilities"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="birth_place" name="birth_place" placeholder=" " />
								<label for="birth_place">Birth Place</label>
								<div class="form-error" id="error_birth_place"></div>
							</div>
						</div>
						<h5>Marital Section</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<select class="form-control" id="marital_status" name="marital_status" required>
									<option value="">Select</option>
									<option value="Single">Single</option>
									<option value="Married">Married</option>
									<option value="Divorced">Divorced</option>
									<option value="Widowed">Widowed</option>
								</select>
								<label for="marital_status">Status *</label>
								<div class="form-error" id="error_marital_status"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="marriage_date" name="marriage_date" />
								<label for="marriage_date">Marriage Date</label>
								<div class="form-error" id="error_marriage_date"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="no_of_children" name="no_of_children" placeholder="e.g., 2" />
								<label for="no_of_children">No. of Children</label>
								<div class="form-error" id="error_no_of_children"></div>
							</div>
						</div>
						<h5>Passport Section</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="passport_name" name="passport_name" placeholder=" " />
								<label for="passport_name">Name in Passport</label>
								<div class="form-error" id="error_passport_name"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="passport_no" name="passport_no" placeholder=" " />
								<label for="passport_no">Passport No</label>
								<div class="form-error" id="error_passport_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="passport_valid_from" name="passport_valid_from" />
								<label for="passport_valid_from">Validity From</label>
								<div class="form-error" id="error_passport_valid_from"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="passport_valid_to" name="passport_valid_to" />
								<label for="passport_valid_to">Validity To</label>
								<div class="form-error" id="error_passport_valid_to"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="passport_issuer" name="passport_issuer" placeholder=" " />
								<label for="passport_issuer">Passport Issuer</label>
								<div class="form-error" id="error_passport_issuer"></div>
							</div>
						</div>
						<h5>Social Section</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="url" class="form-control" id="linkedin" name="linkedin" placeholder="e.g., https://linkedin.com/in/username" />
								<label for="linkedin">LinkedIn</label>
								<div class="form-error" id="error_linkedin"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="url" class="form-control" id="facebook" name="facebook" placeholder="e.g., https://facebook.com/username" />
								<label for="facebook">Facebook</label>
								<div class="form-error" id="error_facebook"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="url" class="form-control" id="twitter" name="twitter" placeholder="e.g., https://twitter.com/username" />
								<label for="twitter">Twitter</label>
								<div class="form-error" id="error_twitter"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="url" class="form-control" id="instagram" name="instagram" placeholder="e.g., https://instagram.com/username" />
								<label for="instagram">Instagram</label>
								<div class="form-error" id="error_instagram"></div>
							</div>
						</div>
						<h5>Others Section</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="pan_no" name="pan_no" required placeholder="e.g., ABCDE1234F" />
								<label for="pan_no">PAN No. *</label>
								<div class="form-error" id="error_pan_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="aadhar_no" name="aadhar_no" maxlength="12" placeholder="e.g., 123456789012" />
								<label for="aadhar_no">Aadhar No</label>
								<div class="form-error" id="error_aadhar_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="voter_id" name="voter_id" placeholder=" " />
								<label for="voter_id">Voter ID</label>
								<div class="form-error" id="error_voter_id"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="driving_license_no" name="driving_license_no" placeholder=" " />
								<label for="driving_license_no">Driving License No</label>
								<div class="form-error" id="error_driving_license_no"></div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="personal-address" role="tabpanel" aria-labelledby="personal-address-tab">
						<h5>Current Address</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_house_no" name="current_house_no" placeholder="e.g., 101" />
								<label for="current_house_no">House No</label>
								<div class="form-error" id="error_current_house_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_street_no" name="current_street_no" placeholder="e.g., 5" />
								<label for="current_street_no">Street No</label>
								<div class="form-error" id="error_current_street_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_block_no" name="current_block_no" placeholder="e.g., Block A" />
								<label for="current_block_no">Block No</label>
								<div class="form-error" id="error_current_block_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="current_period_from" name="current_period_from" />
								<label for="current_period_from">Period of Stay (From)</label>
								<div class="form-error" id="error_current_period_from"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="current_period_to" name="current_period_to" />
								<label for="current_period_to">Period of Stay (To)</label>
								<div class="form-error" id="error_current_period_to"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_street" name="current_street" placeholder="e.g., Main Street" />
								<label for="current_street">Street</label>
								<div class="form-error" id="error_current_street"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_landmark" name="current_landmark" placeholder="e.g., Near City Mall" />
								<label for="current_landmark">Landmark</label>
								<div class="form-error" id="error_current_landmark"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_post_office" name="current_post_office" placeholder="e.g., GPO" />
								<label for="current_post_office">Post Office</label>
								<div class="form-error" id="error_current_post_office"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_police_station" name="current_police_station" placeholder="e.g., Town Police Station" />
								<label for="current_police_station">Police Station</label>
								<div class="form-error" id="error_current_police_station"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_zip_code" name="current_zip_code" placeholder="e.g., 831001" />
								<label for="current_zip_code">Zip Code</label>
								<div class="form-error" id="error_current_zip_code"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_city" name="current_city" placeholder="e.g., Jamshedpur" />
								<label for="current_city">City</label>
								<div class="form-error" id="error_current_city"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_country" name="current_country" placeholder="e.g., India" />
								<label for="current_country">Country</label>
								<div class="form-error" id="error_current_country"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="current_state" name="current_state" placeholder="e.g., Jharkhand" />
								<label for="current_state">State</label>
								<div class="form-error" id="error_current_state"></div>
							</div>
						</div>
						<hr>
						<div class="form-check mb-2">
							<input class="form-check-input" type="checkbox" value="1" id="sameAsCurrent">
							<label class="form-check-label" for="sameAsCurrent">Permanent Address same as Current Address</label>
						</div>
						<h5>Permanent Address</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_house_no" name="permanent_house_no" placeholder="e.g., 101" />
								<label for="permanent_house_no">House No</label>
								<div class="form-error" id="error_permanent_house_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_street_no" name="permanent_street_no" placeholder="e.g., 5" />
								<label for="permanent_street_no">Street No</label>
								<div class="form-error" id="error_permanent_street_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_block_no" name="permanent_block_no" placeholder="e.g., Block A" />
								<label for="permanent_block_no">Block No</label>
								<div class="form-error" id="error_permanent_block_no"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="permanent_period_from" name="permanent_period_from" />
								<label for="permanent_period_from">Period of Stay (From)</label>
								<div class="form-error" id="error_permanent_period_from"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="permanent_period_to" name="permanent_period_to" />
								<label for="permanent_period_to">Period of Stay (To)</label>
								<div class="form-error" id="error_permanent_period_to"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_street" name="permanent_street" placeholder="e.g., Main Street" />
								<label for="permanent_street">Street</label>
								<div class="form-error" id="error_permanent_street"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_landmark" name="permanent_landmark" placeholder="e.g., Near City Mall" />
								<label for="permanent_landmark">Landmark</label>
								<div class="form-error" id="error_permanent_landmark"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_post_office" name="permanent_post_office" placeholder="e.g., GPO" />
								<label for="permanent_post_office">Post Office</label>
								<div class="form-error" id="error_permanent_post_office"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_police_station" name="permanent_police_station" placeholder="e.g., Town Police Station" />
								<label for="permanent_police_station">Police Station</label>
								<div class="form-error" id="error_permanent_police_station"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_zip_code" name="permanent_zip_code" placeholder="e.g., 831001" />
								<label for="permanent_zip_code">Zip Code</label>
								<div class="form-error" id="error_permanent_zip_code"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_city" name="permanent_city" placeholder="e.g., Jamshedpur" />
								<label for="permanent_city">City</label>
								<div class="form-error" id="error_permanent_city"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_country" name="permanent_country" required placeholder="e.g., India" />
								<label for="permanent_country">Country *</label>
								<div class="form-error" id="error_permanent_country"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="permanent_state" name="permanent_state" required placeholder="e.g., Jharkhand" />
								<label for="permanent_state">State *</label>
								<div class="form-error" id="error_permanent_state"></div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="personal-academic" role="tabpanel" aria-labelledby="personal-academic-tab">
						<h5>Add Academic Record</h5>
						<div id="academic-form-row" class="form-row">
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="academic_from_year" name="academic_from_year" min="1900" max="2100" required placeholder="e.g., 2010" />
								<label for="academic_from_year">From Year *</label>
								<div class="form-error" id="error_academic_from_year"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="academic_to_year" name="academic_to_year" min="1900" max="2100" required placeholder="e.g., 2014" />
								<label for="academic_to_year">To Year *</label>
								<div class="form-error" id="error_academic_to_year"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_examination" name="academic_examination" required placeholder="e.g., B.Tech" />
								<label for="academic_examination">Examination *</label>
								<div class="form-error" id="error_academic_examination"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_certification_type" name="academic_certification_type" placeholder="e.g., Degree" />
								<label for="academic_certification_type">Type of Certification</label>
								<div class="form-error" id="error_academic_certification_type"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_certification" name="academic_certification" placeholder="e.g., Computer Science" />
								<label for="academic_certification">Certification</label>
								<div class="form-error" id="error_academic_certification"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_institute" name="academic_institute" required placeholder="e.g., IIT Delhi" />
								<label for="academic_institute">Institute *</label>
								<div class="form-error" id="error_academic_institute"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_college_contact_no" name="academic_college_contact_no" placeholder="e.g., +91-1234567890" />
								<label for="academic_college_contact_no">College Contact No</label>
								<div class="form-error" id="error_academic_college_contact_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_college_address" name="academic_college_address" placeholder="e.g., Delhi, India" />
								<label for="academic_college_address">College Address</label>
								<div class="form-error" id="error_academic_college_address"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_program" name="academic_program" placeholder="e.g., Engineering" />
								<label for="academic_program">Program</label>
								<div class="form-error" id="error_academic_program"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_subject" name="academic_subject" required placeholder="e.g., Data Structures" />
								<label for="academic_subject">Subject *</label>
								<div class="form-error" id="error_academic_subject"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_registration_no" name="academic_registration_no" placeholder=" " />
								<label for="academic_registration_no">Registration No</label>
								<div class="form-error" id="error_academic_registration_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_roll_no" name="academic_roll_no" placeholder=" " />
								<label for="academic_roll_no">Roll No</label>
								<div class="form-error" id="error_academic_roll_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_grade" name="academic_grade" required placeholder="e.g., A / 8.5 CGPA" />
								<label for="academic_grade">Grade *</label>
								<div class="form-error" id="error_academic_grade"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_university" name="academic_university" required placeholder="e.g., Delhi University" />
								<label for="academic_university">University *</label>
								<div class="form-error" id="error_academic_university"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_university_country" name="academic_university_country" placeholder="e.g., India" />
								<label for="academic_university_country">University Country</label>
								<div class="form-error" id="error_academic_university_country"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_university_state" name="academic_university_state" placeholder="e.g., Delhi" />
								<label for="academic_university_state">University State</label>
								<div class="form-error" id="error_academic_university_state"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_university_city" name="academic_university_city" placeholder="e.g., New Delhi" />
								<label for="academic_university_city">University City</label>
								<div class="form-error" id="error_academic_university_city"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="academic_university_contact_no" name="academic_university_contact_no" placeholder="e.g., +91-9876543210" />
								<label for="academic_university_contact_no">University Contact No</label>
								<div class="form-error" id="error_academic_university_contact_no"></div>
							</div>
							<div class="form-group col-md-2">
								<select class="form-control" id="academic_educated_in_overseas" name="academic_educated_in_overseas">
									<option value="">Select</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<label for="academic_educated_in_overseas">Educated In Overseas</label>
								<div class="form-error" id="error_academic_educated_in_overseas"></div>
							</div>
						</div>
						<button type="button" class="btn btn-info mb-2" id="addAcademicRecord">Add Academic Record</button>
						<h5>Academic Records</h5>
						<table class="table table-bordered" id="academicRecordsTable">
							<thead>
							<tr>
								<th>From</th><th>To</th><th>Exam</th><th>Type</th><th>Cert.</th><th>Institute</th><th>Subject</th><th>Grade</th><th>University</th><th>Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
					<div class="tab-pane fade" id="personal-family" role="tabpanel" aria-labelledby="personal-family-tab">
						<h5>Add Family Member</h5>
						<div id="family-form-row" class="form-row">
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_first_name" name="family_first_name" required placeholder=" " />
								<label for="family_first_name">First Name *</label>
								<div class="form-error" id="error_family_first_name"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_middle_name" name="family_middle_name" placeholder=" " />
								<label for="family_middle_name">Middle Name</label>
								<div class="form-error" id="error_family_middle_name"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_last_name" name="family_last_name" required placeholder=" " />
								<label for="family_last_name">Last Name *</label>
								<div class="form-error" id="error_family_last_name"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_relation" name="family_relation" required placeholder="e.g., Spouse, Child, Parent" />
								<label for="family_relation">Relation *</label>
								<div class="form-error" id="error_family_relation"></div>
							</div>
							<div class="form-group col-md-2">
								<select class="form-control" id="family_gender" name="family_gender" required>
									<option value="">Select</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
									<option value="Other">Other</option>
								</select>
								<label for="family_gender">Gender *</label>
								<div class="form-error" id="error_family_gender"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="date" class="form-control" id="family_dob" name="family_dob" required placeholder=" " />
								<label for="family_dob">DOB *</label>
								<div class="form-error" id="error_family_dob"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_contact_no" name="family_contact_no" required placeholder="e.g., +91-9876543210" />
								<label for="family_contact_no">Contact No *</label>
								<div class="form-error" id="error_family_contact_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="email" class="form-control" id="family_email_id" name="family_email_id" placeholder="e.g., email@example.com" />
								<label for="family_email_id">Email Id</label>
								<div class="form-error" id="error_family_email_id"></div>
							</div>
							<div class="form-group col-md-2">
								<select class="form-control" id="family_dependent" name="family_dependent">
									<option value="">Select</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<label for="family_dependent">Dependent</label>
								<div class="form-error" id="error_family_dependent"></div>
							</div>
							<div class="form-group col-md-2">
								<select class="form-control" id="family_residing_with_employee" name="family_residing_with_employee">
									<option value="">Select</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<label for="family_residing_with_employee">Residing with employee</label>
								<div class="form-error" id="error_family_residing_with_employee"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_address" name="family_address" placeholder=" " />
								<label for="family_address">Address</label>
								<div class="form-error" id="error_family_address"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="family_aadhar_no" name="family_aadhar_no" placeholder=" " />
								<label for="family_aadhar_no">Aadhar No</label>
								<div class="form-error" id="error_family_aadhar_no"></div>
							</div>
						</div>
						<button type="button" class="btn btn-info mb-2" id="addFamilyRecord">Add Family Member</button>
						<h5>Family Records</h5>
						<table class="table table-bordered" id="familyRecordsTable">
							<thead>
							<tr>
								<th>Name</th><th>Relation</th><th>Gender</th><th>DOB</th><th>Contact</th><th>Dependent</th><th>Residing</th><th>Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
					<div class="tab-pane fade" id="personal-nomination" role="tabpanel" aria-labelledby="personal-nomination-tab">
						<h5>Add Nominee</h5>
						<div id="nomination-form-row" class="form-row">
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="nominee_name" name="nominee_name" required placeholder=" " />
								<label for="nominee_name">Nominee Name *</label>
								<div class="form-error" id="error_nominee_name"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="nominee_relation" name="nominee_relation" required placeholder="e.g., Mother, Brother" />
								<label for="nominee_relation">Relation *</label>
								<div class="form-error" id="error_nominee_relation"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="nominee_percentage" name="nominee_percentage" min="0" max="100" required placeholder="e.g., 100" />
								<label for="nominee_percentage">Percentage *</label>
								<div class="form-error" id="error_nominee_percentage"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="nominee_address" name="nominee_address" placeholder=" " />
								<label for="nominee_address">Address</label>
								<div class="form-error" id="error_nominee_address"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="nominee_contact" name="nominee_contact" placeholder="e.g., +91-9876543210" />
								<label for="nominee_contact">Contact</label>
								<div class="form-error" id="error_nominee_contact"></div>
							</div>
						</div>
						<button type="button" class="btn btn-info mb-2" id="addNomineeRecord">Add Nominee</button>
						<h5>Nominee Records</h5>
						<table class="table table-bordered" id="nomineeRecordsTable">
							<thead>
							<tr>
								<th>Name</th><th>Relation</th><th>Percentage</th><th>Contact</th><th>Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
					<div class="tab-pane fade" id="personal-career" role="tabpanel" aria-labelledby="personal-career-tab">
						<h5>Add Employment Record</h5>
						<div id="career-form-row" class="form-row">
							<div class="form-group col-md-2">
								<input type="date" class="form-control" id="career_from_date" name="career_from_date" required placeholder=" " />
								<label for="career_from_date">From Date *</label>
								<div class="form-error" id="error_career_from_date"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="date" class="form-control" id="career_to_date" name="career_to_date" required placeholder=" " />
								<label for="career_to_date">To Date *</label>
								<div class="form-error" id="error_career_to_date"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_employer" name="career_employer" required placeholder="e.g., ABC Corp" />
								<label for="career_employer">Employer *</label>
								<div class="form-error" id="error_career_employer"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_employer_code" name="career_employer_code" placeholder=" " />
								<label for="career_employer_code">Employer Code</label>
								<div class="form-error" id="error_career_employer_code"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_employment_status" name="career_employment_status" placeholder="e.g., Full-time" />
								<label for="career_employment_status">Employment Status</label>
								<div class="form-error" id="error_career_employment_status"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_position" name="career_position" required placeholder="e.g., Software Engineer" />
								<label for="career_position">Position *</label>
								<div class="form-error" id="error_career_position"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_address" name="career_address" required placeholder="e.g., 123 Tech Lane, City" />
								<label for="career_address">Address *</label>
								<div class="form-error" id="error_career_address"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="career_starting_salary" name="career_starting_salary" placeholder="e.g., 50000" />
								<label for="career_starting_salary">Starting Salary</label>
								<div class="form-error" id="error_career_starting_salary"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="career_starting_other_comp" name="career_starting_other_comp" placeholder="e.g., 5000" />
								<label for="career_starting_other_comp">Starting Other Compensation</label>
								<div class="form-error" id="error_career_starting_other_comp"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="career_final_salary" name="career_final_salary" placeholder="e.g., 70000" />
								<label for="career_final_salary">Final Salary</label>
								<div class="form-error" id="error_career_final_salary"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="number" class="form-control" id="career_final_other_comp" name="career_final_other_comp" placeholder="e.g., 7000" />
								<label for="career_final_other_comp">Final Other Compensation</label>
								<div class="form-error" id="error_career_final_other_comp"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_responsibility" name="career_responsibility" required placeholder="e.g., Led development team" />
								<label for="career_responsibility">Responsibility *</label>
								<div class="form-error" id="error_career_responsibility"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_achievement" name="career_achievement" placeholder="e.g., Increased efficiency by 15%" />
								<label for="career_achievement">Achievement</label>
								<div class="form-error" id="error_career_achievement"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_reason_for_change" name="career_reason_for_change" required placeholder="e.g., Career growth" />
								<label for="career_reason_for_change">Reason for Change *</label>
								<div class="form-error" id="error_career_reason_for_change"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_contact_person" name="career_contact_person" placeholder="e.g., Jane Doe" />
								<label for="career_contact_person">Contact Person</label>
								<div class="form-error" id="error_career_contact_person"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_contact_person_job_title" name="career_contact_person_job_title" placeholder="e.g., HR Manager" />
								<label for="career_contact_person_job_title">Contact Person Job Title</label>
								<div class="form-error" id="error_career_contact_person_job_title"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_contact_person_department" name="career_contact_person_department" placeholder="e.g., HR" />
								<label for="career_contact_person_department">Contact Person Department</label>
								<div class="form-error" id="error_career_contact_person_department"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_contact_person_mobile_no" name="career_contact_person_mobile_no" placeholder="e.g., +91-1234567890" />
								<label for="career_contact_person_mobile_no">Contact Person Mobile No</label>
								<div class="form-error" id="error_career_contact_person_mobile_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="email" class="form-control" id="career_contact_person_email" name="career_contact_person_email" placeholder="e.g., contact@example.com" />
								<label for="career_contact_person_email">Contact Person Email</label>
								<div class="form-error" id="error_career_contact_person_email"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="url" class="form-control" id="career_company_website" name="career_company_website" placeholder="e.g., https://company.com" />
								<label for="career_company_website">Company Website</label>
								<div class="form-error" id="error_career_company_website"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_uan_no" name="career_uan_no" placeholder=" " />
								<label for="career_uan_no">UAN No</label>
								<div class="form-error" id="error_career_uan_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_epf_ac_no" name="career_epf_ac_no" placeholder=" " />
								<label for="career_epf_ac_no">EPF A/c No</label>
								<div class="form-error" id="error_career_epf_ac_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_epf_region" name="career_epf_region" placeholder=" " />
								<label for="career_epf_region">EPF Region</label>
								<div class="form-error" id="error_career_epf_region"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_esi_ac_no" name="career_esi_ac_no" placeholder=" " />
								<label for="career_esi_ac_no">ESI A/c No</label>
								<div class="form-error" id="error_career_esi_ac_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_scheme_certificate_no" name="career_scheme_certificate_no" placeholder=" " />
								<label for="career_scheme_certificate_no">Scheme Certificate No</label>
								<div class="form-error" id="error_career_scheme_certificate_no"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="career_pension_payment_order_no" name="career_pension_payment_order_no" placeholder=" " />
								<label for="career_pension_payment_order_no">Pension Payment Order No</label>
								<div class="form-error" id="error_career_pension_payment_order_no"></div>
							</div>
						</div>
						<button type="button" class="btn btn-info mb-2" id="addCareerRecord">Add Employment Record</button>
						<h5>Employment Records</h5>
						<table class="table table-bordered" id="careerRecordsTable">
							<thead>
							<tr>
								<th>From</th><th>To</th><th>Employer</th><th>Position</th><th>Department</th><th>Reason</th><th>Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
					<div class="tab-pane fade" id="personal-medical" role="tabpanel" aria-labelledby="personal-medical-tab">
						<h5>Medical History</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="medical_chronic_conditions" name="medical_chronic_conditions" placeholder="e.g., Diabetes, Asthma" />
								<label for="medical_chronic_conditions">Chronic Conditions</label>
								<div class="form-error" id="error_medical_chronic_conditions"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="medical_allergies" name="medical_allergies" placeholder="e.g., Penicillin, Peanuts" />
								<label for="medical_allergies">Allergies</label>
								<div class="form-error" id="error_medical_allergies"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="medical_medications" name="medical_medications" placeholder="e.g., Insulin, Blood Pressure Meds" />
								<label for="medical_medications">Medications</label>
								<div class="form-error" id="error_medical_medications"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="medical_past_surgeries" name="medical_past_surgeries" placeholder="e.g., Appendectomy (2018)" />
								<label for="medical_past_surgeries">Past Surgeries</label>
								<div class="form-error" id="error_medical_past_surgeries"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="medical_emergency_contact_name" name="medical_emergency_contact_name" placeholder="e.g., John Doe" />
								<label for="medical_emergency_contact_name">Emergency Contact Name</label>
								<div class="form-error" id="error_medical_emergency_contact_name"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="medical_emergency_contact_number" name="medical_emergency_contact_number" placeholder="e.g., +91-9876543210" />
								<label for="medical_emergency_contact_number">Emergency Contact Number</label>
								<div class="form-error" id="error_medical_emergency_contact_number"></div>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="personal-emergency" role="tabpanel" aria-labelledby="personal-emergency-tab">
						<h5>Add Emergency Contact</h5>
						<div id="emergency-form-row" class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="emergency_name" name="emergency_name" required placeholder="e.g., Jane Doe" />
								<label for="emergency_name">Name *</label>
								<div class="form-error" id="error_emergency_name"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="emergency_relation" name="emergency_relation" required placeholder="e.g., Mother, Friend" />
								<label for="emergency_relation">Relation *</label>
								<div class="form-error" id="error_emergency_relation"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="emergency_contact1" name="emergency_contact1" required placeholder="e.g., +91-9876543210" />
								<label for="emergency_contact1">Contact No 1 *</label>
								<div class="form-error" id="error_emergency_contact1"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="emergency_contact2" name="emergency_contact2" placeholder="e.g., +91-9876543211" />
								<label for="emergency_contact2">Contact No 2</label>
								<div class="form-error" id="error_emergency_contact2"></div>
							</div>
							<div class="form-group col-md-2">
								<input type="text" class="form-control" id="emergency_contact3" name="emergency_contact3" placeholder="e.g., +91-9876543212" />
								<label for="emergency_contact3">Contact No 3</label>
								<div class="form-error" id="error_emergency_contact3"></div>
							</div>
						</div>
						<button type="button" class="btn btn-info mb-2" id="addEmergencyRecord">Add Emergency Contact</button>
						<h5>Emergency Contact Records</h5>
						<table class="table table-bordered" id="emergencyRecordsTable">
							<thead>
							<tr>
								<th>Name</th><th>Relation</th><th>Contact 1</th><th>Contact 2</th><th>Contact 3</th><th>Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
					<div class="tab-pane fade" id="personal-attachments" role="tabpanel" aria-labelledby="personal-attachments-tab">
						<h5>Add Attachment</h5>
						<div class="form-row">
							<div class="form-group col-md-4">
								<input type="text" class="form-control" id="attachment_description" name="attachment_description" placeholder="e.g., Resume, ID Proof" />
								<label for="attachment_description">Description</label>
								<div class="form-error" id="error_attachment_description"></div>
							</div>
							<div class="form-group col-md-4">
								<input type="file" class="form-control" id="attachment_file" name="attachment_file" />
								<label for="attachment_file">File</label>
								<div class="form-error" id="error_attachment_file"></div>
							</div>
						</div>
						<button type="button" class="btn btn-info mb-2" id="addAttachmentRecord">Add Attachment</button>
						<h5>Attachments</h5>
						<table class="table table-bordered" id="attachmentRecordsTable">
							<thead>
							<tr>
								<th>Date</th><th>Description</th><th>File Name</th><th>Action</th>
							</tr>
							</thead>
							<tbody></tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="payment-tab">
				<h5>Payment Details</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_type" name="payment_type" placeholder="e.g., Bank Transfer" />
						<label for="payment_type">Type</label>
						<div class="form-error" id="error_payment_type"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="payment_percent" name="payment_percent" min="0" max="100" placeholder="e.g., 100" />
						<label for="payment_percent">Percent</label>
						<div class="form-error" id="error_payment_percent"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_type2" name="payment_type2" placeholder="e.g., Cash" />
						<label for="payment_type2">Type2</label>
						<div class="form-error" id="error_payment_type2"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="payment_percent2" name="payment_percent2" min="0" max="100" placeholder="e.g., 0" />
						<label for="payment_percent2">Percent2</label>
						<div class="form-error" id="error_payment_percent2"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_bank_name" name="payment_bank_name" placeholder="e.g., State Bank of India" />
						<label for="payment_bank_name">Bank Name</label>
						<div class="form-error" id="error_payment_bank_name"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_branch" name="payment_branch" placeholder="e.g., Jamshedpur Main" />
						<label for="payment_branch">Branch</label>
						<div class="form-error" id="error_payment_branch"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_ifsc_code" name="payment_ifsc_code" placeholder="e.g., SBIN0000001" />
						<label for="payment_ifsc_code">IFSC Code</label>
						<div class="form-error" id="error_payment_ifsc_code"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_account_no" name="payment_account_no" placeholder="e.g., 123456789012345" />
						<label for="payment_account_no">A/C No</label>
						<div class="form-error" id="error_payment_account_no"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_beneficiary_name" name="payment_beneficiary_name" placeholder="e.g., Employee Name" />
						<label for="payment_beneficiary_name">Beneficiary Name</label>
						<div class="form-error" id="error_payment_beneficiary_name"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="payment_name_in_bank" name="payment_name_in_bank" placeholder="e.g., Employee Name" />
						<label for="payment_name_in_bank">Name In Bank</label>
						<div class="form-error" id="error_payment_name_in_bank"></div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="admin" role="tabpanel" aria-labelledby="admin-tab">
				<ul class="nav nav-pills mb-3" id="adminSubTab" role="tablist">
					<li class="nav-item" role="presentation">
						<a class="nav-link active" id="admin-main-tab" data-toggle="pill" href="#admin-main" role="tab" aria-controls="admin-main" aria-selected="true">Main</a>
					</li>
				</ul>
				<div class="tab-content" id="adminSubTabContent">
					<div class="tab-pane fade show active" id="admin-main" role="tabpanel" aria-labelledby="admin-main-tab">
						<h5>Administration Details</h5>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="admin_start_date" name="admin_start_date" placeholder=" " />
								<label for="admin_start_date">Start Date</label>
								<div class="form-error" id="error_admin_start_date"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_status" name="admin_status" placeholder="e.g., Confirmed, Probation" />
								<label for="admin_status">Status</label>
								<div class="form-error" id="error_admin_status"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="number" class="form-control" id="admin_probation_period" name="admin_probation_period" placeholder="e.g., 6" />
								<label for="admin_probation_period">Probation Period (Months)</label>
								<div class="form-error" id="error_admin_probation_period"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="admin_confirmation_date" name="admin_confirmation_date" placeholder=" " />
								<label for="admin_confirmation_date">Confirmation Date</label>
								<div class="form-error" id="error_admin_confirmation_date"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_grade" name="admin_grade" placeholder="e.g., A1, Manager" />
								<label for="admin_grade">Grade</label>
								<div class="form-error" id="error_admin_grade"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_division" name="admin_division" placeholder="e.g., North, South" />
								<label for="admin_division">Division</label>
								<div class="form-error" id="error_admin_division"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_job_title" name="admin_job_title" placeholder="e.g., Senior Developer" />
								<label for="admin_job_title">Job Title</label>
								<div class="form-error" id="error_admin_job_title"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="number" class="form-control" id="admin_notice_period" name="admin_notice_period" placeholder="e.g., 90" />
								<label for="admin_notice_period">Notice Period (Days)</label>
								<div class="form-error" id="error_admin_notice_period"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_attendance_cycle" name="admin_attendance_cycle" placeholder="e.g., Monthly" />
								<label for="admin_attendance_cycle">Attendance Cycle</label>
								<div class="form-error" id="error_admin_attendance_cycle"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_shift" name="admin_shift" placeholder="e.g., Day, Night" />
								<label for="admin_shift">Shift</label>
								<div class="form-error" id="error_admin_shift"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_manager" name="admin_manager" placeholder="e.g., EMP001" />
								<label for="admin_manager">Manager</label>
								<div class="form-error" id="error_admin_manager"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_manager_name" name="admin_manager_name" placeholder="e.g., Alice Smith" />
								<label for="admin_manager_name">Name (Manager Name)</label>
								<div class="form-error" id="error_admin_manager_name"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="admin_resignation_date" name="admin_resignation_date" placeholder=" " />
								<label for="admin_resignation_date">Resignation Date</label>
								<div class="form-error" id="error_admin_resignation_date"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_resp_acceptance" name="admin_resp_acceptance" placeholder="e.g., Accepted" />
								<label for="admin_resp_acceptance">Resp. Acceptance</label>
								<div class="form-error" id="error_admin_resp_acceptance"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_reason_for_leaving" name="admin_reason_for_leaving" placeholder="e.g., Better opportunity" />
								<label for="admin_reason_for_leaving">Reason for Leaving</label>
								<div class="form-error" id="error_admin_reason_for_leaving"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="admin_last_working_date" name="admin_last_working_date" placeholder=" " />
								<label for="admin_last_working_date">Last Working Date</label>
								<div class="form-error" id="error_admin_last_working_date"></div>
							</div>
						</div>
						<div class="form-row">
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_old_emp_code" name="admin_old_emp_code" placeholder=" " />
								<label for="admin_old_emp_code">Old Emp Code</label>
								<div class="form-error" id="error_admin_old_emp_code"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="text" class="form-control" id="admin_old_emp_code_name" name="admin_old_emp_code_name" placeholder=" " />
								<label for="admin_old_emp_code_name">Name (Old Emp Code Name)</label>
								<div class="form-error" id="error_admin_old_emp_code_name"></div>
							</div>
							<div class="form-group col-md-3">
								<input type="date" class="form-control" id="admin_initial_joining_date" name="admin_initial_joining_date" placeholder=" " />
								<label for="admin_initial_joining_date">Initial Joining Date</label>
								<div class="form-error" id="error_admin_initial_joining_date"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="statutory" role="tabpanel" aria-labelledby="statutory-tab">
				<h5>Statutory Details</h5>
				<h6>Provident Fund</h6>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_pf_ac_no" name="stat_pf_ac_no" placeholder=" " />
						<label for="stat_pf_ac_no">A/C No</label>
						<div class="form-error" id="error_stat_pf_ac_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="stat_pf_joining_date" name="stat_pf_joining_date" placeholder=" " />
						<label for="stat_pf_joining_date">Joining Date</label>
						<div class="form-error" id="error_stat_pf_joining_date"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_pf_uan" name="stat_pf_uan" placeholder=" " />
						<label for="stat_pf_uan">Universal A/C No (UAN)</label>
						<div class="form-error" id="error_stat_pf_uan"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_pf_settlement" name="stat_pf_settlement" placeholder=" " />
						<label for="stat_pf_settlement">Settlement</label>
						<div class="form-error" id="error_stat_pf_settlement"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_eps_ac_no" name="stat_eps_ac_no" placeholder=" " />
						<label for="stat_eps_ac_no">EPS A/C No</label>
						<div class="form-error" id="error_stat_eps_ac_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="stat_eps_joining_date" name="stat_eps_joining_date" placeholder=" " />
						<label for="stat_eps_joining_date">EPS Joining Date</label>
						<div class="form-error" id="error_stat_eps_joining_date"></div>
					</div>
				</div>
				<h6>ESI</h6>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_esi_ac_no" name="stat_esi_ac_no" placeholder=" " />
						<label for="stat_esi_ac_no">A/C No</label>
						<div class="form-error" id="error_stat_esi_ac_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="stat_esi_joining_date" name="stat_esi_joining_date" placeholder=" " />
						<label for="stat_esi_joining_date">Joining Date</label>
						<div class="form-error" id="error_stat_esi_joining_date"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_esi_locality" name="stat_esi_locality" placeholder=" " />
						<label for="stat_esi_locality">Locality</label>
						<div class="form-error" id="error_stat_esi_locality"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_esi_dispensary" name="stat_esi_dispensary" placeholder=" " />
						<label for="stat_esi_dispensary">Dispensary</label>
						<div class="form-error" id="error_stat_esi_dispensary"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_esi_doctor_code" name="stat_esi_doctor_code" placeholder=" " />
						<label for="stat_esi_doctor_code">Doctor Code</label>
						<div class="form-error" id="error_stat_esi_doctor_code"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_esi_doctor_name" name="stat_esi_doctor_name" placeholder=" " />
						<label for="stat_esi_doctor_name">Doctor Name</label>
						<div class="form-error" id="error_stat_esi_doctor_name"></div>
					</div>
				</div>
				<h6>Professional Tax</h6>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="stat_ptax_region" name="stat_ptax_region" placeholder=" " />
						<label for="stat_ptax_region">P. Tax Region</label>
						<div class="form-error" id="error_stat_ptax_region"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="d-flex justify-content-start gap-2 mt-3"> <button type="submit" class="btn btn-success">Save & Accept</button>
			<button type="button" id="resetFormBtn" class="btn btn-warning">Reset</button>
		</div>
	</form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<script>
	$(document).ready(function() {
		// Fetch Employment Types and populate dropdown
		$.ajax({
			url: '<?= base_url("employee/get_employment_types"); ?>',
			type: 'GET',
			dataType: 'json',
			success: function(response) {
				let options = '<option value="">Select Employment Type *</option>';
				response.forEach(function(type) {
					options += `<option value="${type.employee_type_id}">${type.type_name}</option>`;
				});
				$('#employment_type').html(options);
			}
		});

		// On Employment Type change, fetch Designations
		$('#employment_type').on('change', function() {
			let employeeTypeId = $(this).val();
			$('#designation').html('<option value="">Select Designation *</option>');
			if(employeeTypeId) {
				$.ajax({
					url: '<?= base_url("employee/get_designations"); ?>',
					type: 'GET',
					data: { employee_type_id: employeeTypeId },
					dataType: 'json',
					success: function(response) {
						let options = '<option value="">Select Designation *</option>';
						response.forEach(function(designation) {
							options += `<option value="${designation.designation_id}">${designation.designation_name}</option>`;
						});
						$('#designation').html(options);
					}
				});
			}
		});

		// Fetch Posting Cities and populate dropdown
		$.ajax({
			url: '<?= base_url("employee/get_places"); ?>',
			type: 'GET',
			dataType: 'json',
			success: function(response) {
				let options = '<option value="">Select Posting City *</option>';
				response.forEach(function(place) {
					options += `<option value="${place.place_id}">${place.place_name}</option>`;
				});
				$('#posting_city').html(options);
				$('#posting_city').trigger('change'); // For select2 update
			}
		});

		// On Posting City change, generate Employee Code
		$('#posting_city').on('change', function() {
			var state_code = $(this).find(':selected').data('state');
			if(!state_code) {
				// Try to get state_code from option text if not present
				var selectedText = $(this).find(':selected').text();
				var match = selectedText.match(/\(([^)]+)\)$/);
				if(match) state_code = match[1];
			}
			if(state_code) {
				$.ajax({
					url: '<?= base_url("employee/get_next_employee_code"); ?>',
					type: 'POST',
					data: {state_code: state_code},
					dataType: 'json',
					success: function(response) {
						$('#employee_code').val(response.employee_code);
					}
				});
			} else {
				$('#employee_code').val('');
			}
		});

		// --- Select2 Initialization ---
		$('#posting_city').select2({
			placeholder: "Select Posting City *",
			allowClear: true // This allows the clear button
		});

		// Manually trigger filled state for Select2 if it has a value on load
		// The Select2 custom styling is applied to .select2-selection__rendered, not the original select
		if ($('#posting_city').val()) {
			$('#posting_city').next('.select2-container').find('.select2-selection__rendered').addClass('filled');
		}
		// Listen to Select2 change to toggle 'filled' class
		$('#posting_city').on('change', function() {
			if ($(this).val()) {
				$(this).next('.select2-container').find('.select2-selection__rendered').addClass('filled');
			} else {
				$(this).next('.select2-container').find('.select2-selection__rendered').removeClass('filled');
			}
			validateField($(this)); // Validate Select2 field on change
		});


		// --- Tab Management and Local Storage ---
		// Initialize active tab logic
		let lastMainTabHref = localStorage.getItem('employeeFormActiveMainTab') || '#master';
		let lastSubTabHref = localStorage.getItem('employeeFormActiveSubTab') || null;

		// Function to activate a specific tab/sub-tab
		function activateTabAndScroll(mainTabHref, subTabHref = null, fieldToScrollTo = null) {
			// Activate main tab first
			$('#myTab a[href="' + mainTabHref + '"]').tab('show');
			localStorage.setItem('employeeFormActiveMainTab', mainTabHref);

			// If there's a sub-tab to activate
			if (subTabHref) {
				const $subTabsContainer = $(mainTabHref).find('.nav-pills');
				if ($subTabsContainer.length && $subTabsContainer.find('a[href="' + subTabHref + '"]').length) {
					$subTabsContainer.find('a[href="' + subTabHref + '"]').tab('show');
					localStorage.setItem('employeeFormActiveSubTab', subTabHref);
				} else {
					// If stored sub-tab doesn't exist under this main tab, default to first sub-tab
					const firstSubTabLink = $subTabsContainer.find('.nav-link').first();
					if (firstSubTabLink.length) {
						firstSubTabLink.tab('show');
						localStorage.setItem('employeeFormActiveSubTab', firstSubTabLink.attr('href'));
					} else {
						localStorage.removeItem('employeeFormActiveSubTab');
					}
				}
			} else {
				localStorage.removeItem('employeeFormActiveSubTab');
			}

			// Scroll to the specific field after tabs are active, with a slight delay
			if (fieldToScrollTo) {
				setTimeout(() => {
					const $field = $('#' + fieldToScrollTo);
					if ($field.length) {
						// For select2, scroll its rendered container into view
						if ($field.hasClass('select2-hidden-accessible')) {
							$field.next('.select2-container')[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
						} else {
							$field[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
						}
					}
				}, 150); // Small delay to allow tab content to become visible
			}
		}

		// On page load, activate the last remembered tab or default to Master
		activateTabAndScroll(lastMainTabHref, lastSubTabHref);

		// Store main tab changes
		$('#myTab a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
			const newMainTabHref = $(e.target).attr('href');
			localStorage.setItem('employeeFormActiveMainTab', newMainTabHref);

			// When main tab changes, activate its first sub-tab by default if it has sub-tabs
			const $subTabsContainer = $(newMainTabHref).find('.nav-pills');
			if ($subTabsContainer.length) {
				const firstSubTabLink = $subTabsContainer.find('.nav-link').first();
				if (firstSubTabLink.length) {
					firstSubTabLink.tab('show');
					localStorage.setItem('employeeFormActiveSubTab', firstSubTabLink.attr('href'));
				}
			} else {
				// If no sub-tabs, clear sub-tab storage
				localStorage.removeItem('employeeFormActiveSubTab');
			}
		});

		// Store sub-tab changes
		$('.tab-pane.fade .nav-pills a[data-toggle="pill"]').on('shown.bs.tab', function (e) {
			localStorage.setItem('employeeFormActiveSubTab', $(e.target).attr('href'));
		});


		// --- Validation Helper Functions ---
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		const urlRegex = /^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/[a-zA-Z0-9]+\.[^\s]{2,}|[a-zA-Z0-9]+\.[^\s]{2,})$/i;
		const mobileNoRegex = /^[6-9]\d{9}$/; // Assumes 10-digit Indian mobile number starting with 6-9
		const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/; // Standard PAN format (stronger than earlier)

		function showError(fieldId, message) {
			$(`#error_${fieldId}`).text(message);
			$(`#${fieldId}`).addClass('is-invalid');
			// For select2, also add class to its rendered element
			if ($(`#${fieldId}`).hasClass('select2-hidden-accessible')) {
				$(`#${fieldId}`).next('.select2-container').find('.select2-selection__rendered').addClass('is-invalid');
			}
		}

		function clearError(fieldId) {
			$(`#error_${fieldId}`).text('');
			$(`#${fieldId}`).removeClass('is-invalid');
			// For select2, also remove class from its rendered element
			if ($(`#${fieldId}`).hasClass('select2-hidden-accessible')) {
				$(`#${fieldId}`).next('.select2-container').find('.select2-selection__rendered').removeClass('is-invalid');
			}
		}

		function showFormAlert(type, message) {
			var alertHtml = '<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">' +
				message +
				'<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
				'<span aria-hidden="true">&times;</span>' +
				'</button></div>';
			$('#formAlert').html(alertHtml);
			setTimeout(function() { $(".alert").alert('close'); }, 5000); // Increased timeout
		}

		function validateField(inputElement) {
			const fieldId = inputElement.attr('id');
			const value = inputElement.val() ? inputElement.val().trim() : '';
			const isRequired = inputElement.prop('required');
			let isValid = true;
			let errorMessage = '';

			clearError(fieldId); // Always clear before re-validating

			if (inputElement.is('select')) {
				if (isRequired && (value === '')) {
					isValid = false;
					errorMessage = 'This field is required.';
				}
			} else if (isRequired && value === '') {
				isValid = false;
				errorMessage = 'This field is required.';
			} else if (value !== '') { // Only apply specific format validation if value is not empty
				switch (fieldId) {
					case 'email':
						if (!emailRegex.test(value)) {
							isValid = false;
							errorMessage = 'Please enter a valid email address (e.g., example@domain.com).';
						}
						break;
					case 'mobile': // Corrected field ID
						if (!mobileNoRegex.test(value)) {
							isValid = false;
							errorMessage = 'Please enter a valid 10-digit mobile number (starts with 6-9).';
						}
						break;
					case 'linkedin':
					case 'facebook':
					case 'twitter':
					case 'instagram':
					case 'career_company_website':
						if (!urlRegex.test(value)) {
							isValid = false;
							errorMessage = 'Please enter a valid URL (e.g., https://www.example.com).';
						}
						break;
					case 'pan_no':
						if (!panRegex.test(value)) {
							isValid = false;
							errorMessage = 'Please enter a valid PAN (e.g., ABCDE1234F).';
						}
						break;
					case 'aadhar_no':
						if (value.length !== 12 || !/^\d{12}$/.test(value)) { // Enforce exactly 12 digits
							isValid = false;
							errorMessage = 'Aadhar No must be exactly 12 digits.';
						}
						break;
					case 'academic_from_year':
					case 'academic_to_year':
						const year = parseInt(value);
						if (isNaN(year) || year < 1900 || year > new Date().getFullYear() + 5) { // Max 5 years into future
							isValid = false;
							errorMessage = 'Please enter a valid year (1900-Current Year + 5).';
						}
						break;
					case 'nominee_percentage':
					case 'payment_percent':
					case 'payment_percent2':
						const percent = parseFloat(value);
						if (isNaN(percent) || percent < 0 || percent > 100) {
							isValid = false;
							errorMessage = 'Please enter a percentage between 0 and 100.';
						}
						break;
					case 'admin_probation_period':
					case 'admin_notice_period':
					case 'career_starting_salary':
					case 'career_starting_other_comp':
					case 'career_final_salary':
					case 'career_final_other_comp':
					case 'no_of_children':
						const num = parseFloat(value);
						if (isNaN(num) || num < 0) {
							isValid = false;
							errorMessage = 'Please enter a non-negative number.';
						}
						break;
					// Add more specific validations as needed
				}
			}

			if (!isValid) {
				showError(fieldId, errorMessage);
			}
			return isValid;
		}

		// --- Real-time Validation & Floating Labels ---
		// Apply initial 'filled' class if input has value
		$('.form-control').each(function() {
			if($(this).val()) {
				$(this).addClass('filled');
			}
		});

		// Real-time validation and 'filled' class toggling on input/change
		$(document).on('input change', '.form-control:not(.select2-hidden-accessible)', function() { // Exclude select2 original element
			validateField($(this)); // Validate immediately
			if($(this).val()) {
				$(this).addClass('filled');
			} else {
				$(this).removeClass('filled');
			}
			updateProfileProgress(); // Update progress bar
		});


		// --- Form Submission Logic ---
		$('#employeeForm').on('submit', function(e) {
			e.preventDefault(); // Prevent default form submission initially
			let currentSectionHasErrors = false;
			let firstCurrentSectionErrorFieldId = null;

			// Clear all previous errors from ALL fields before starting new validation cycle
			$('.form-error').text('');
			$('.form-control').removeClass('is-invalid');
			// Also clear invalid state for Select2 rendered elements
			$('.select2-container--default .select2-selection--single').removeClass('is-invalid');


			// Determine the currently active tab/sub-tab for focused validation
			const activeMainTabHref = $('#myTab .nav-link.active').attr('href');
			let $currentActiveContentArea = $(activeMainTabHref);

			// If it's a main tab with sub-tabs, get the currently active sub-tab content area
			if (activeMainTabHref === '#personal' || activeMainTabHref === '#admin') {
				const activeSubTabHref = $currentActiveContentArea.find('.nav-pills .nav-link.active').attr('href');
				if (activeSubTabHref) {
					$currentActiveContentArea = $(activeSubTabHref);
				}
			}

			// --- Phase 1: Validate fields only in the CURRENTLY VISIBLE/ACTIVE tab/sub-tab ---
			$currentActiveContentArea.find('input[required], select[required], input[type="email"], input[type="url"], input[type="number"]').each(function() {
				const fieldId = $(this).attr('id');
				const $inputElement = $(this);

				// Handle Select2 specifically for validation display
				if ($inputElement.hasClass('select2-hidden-accessible')) {
					if (!$inputElement.val() || $inputElement.val() === '') {
						showError(fieldId, 'This field is required.');
						currentSectionHasErrors = true;
						if (!firstCurrentSectionErrorFieldId) {
							firstCurrentSectionErrorFieldId = fieldId;
						}
						$inputElement.next('.select2-container').find('.select2-selection__rendered').addClass('is-invalid');
					} else {
						clearError(fieldId);
					}
				} else { // Handle regular inputs
					if (!validateField($inputElement)) {
						if (!firstCurrentSectionErrorFieldId) {
							firstCurrentSectionErrorFieldId = fieldId; // Capture the first error on the current section
						}
						currentSectionHasErrors = true;
					}
				}
			});

			if (currentSectionHasErrors) {
				showFormAlert('danger', 'Please fix the errors in the current section before proceeding.');
				// Scroll to the first error field on the current tab
				if (firstCurrentSectionErrorFieldId) {
					// Use activateTabAndScroll to handle both tab activation and scrolling
					// For current tab, we don't need to re-activate the main/sub-tab, just scroll
					setTimeout(() => {
						const $errorField = $('#' + firstCurrentSectionErrorFieldId);
						if ($errorField.length) {
							if ($errorField.hasClass('select2-hidden-accessible')) {
								// For select2, scroll to its visual container
								$errorField.next('.select2-container')[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
							} else {
								$errorField[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
							}
						}
					}, 100);
				}
				return; // STOP submission if current section has errors
			}

			// --- Phase 2: If the current section is clean, then validate ALL required fields across the ENTIRE form ---
			let overallFormValid = true;
			let firstOverallErrorFieldId = null;

			$('input[required], select[required], input[type="email"], input[type="url"], input[type="number"]').each(function() {
				const fieldId = $(this).attr('id');
				const $inputElement = $(this);

				if ($inputElement.hasClass('select2-hidden-accessible')) { // Handle Select2 specifically
					if (!$inputElement.val() || $inputElement.val() === '') {
						showError(fieldId, 'This field is required.');
						overallFormValid = false;
						if (!firstOverallErrorFieldId) {
							firstOverallErrorFieldId = fieldId;
						}
						$inputElement.next('.select2-container').find('.select2-selection__rendered').addClass('is-invalid');
					} else
					{
						clearError(fieldId);
					}
				}
				else {
					if (!validateField($inputElement)) { // Call specific validation
						if (!firstOverallErrorFieldId) {
							firstOverallErrorFieldId = fieldId; // Capture the very first error across the whole form
						}
						overallFormValid = false;
					}
				}
			});

			if (overallFormValid) {
				showFormAlert('success', 'Form submitted successfully!');
				// At this point, all validations pass. You can now submit the form data via AJAX.
				// Example:
				// const formData = new FormData(this);
				// fetch('your_backend_api_endpoint', {
				//     method: 'POST',
				//     body: formData
				// }).then(response => response.json())
				//   .then(data => console.log(data))
				//   .catch(error => console.error('Error:', error));

			} else {
				showFormAlert('danger', 'Please fix all errors in the form before proceeding.');

				// Activate the tab/sub-tab containing the first overall error
				if (firstOverallErrorFieldId) {
					const $errorField = $('#' + firstOverallErrorFieldId);
					const $errorTabPane = $errorField.closest('.tab-pane');
					const errorTabPaneId = $errorTabPane.attr('id');

					const $parentMainTabPane = $errorTabPane.closest('.tab-pane.fade'); // Find the main tab pane
					const parentMainTabId = $parentMainTabPane.attr('id');

					let targetSubTabHref = null;
					// Determine if the error is in a sub-tab
					if ($errorTabPane.attr('id').includes('-') && $errorTabPane.attr('id') !== parentMainTabId) {
						targetSubTabHref = '#' + errorTabPaneId;
					}

					activateTabAndScroll('#' + parentMainTabId, targetSubTabHref, firstOverallErrorFieldId);
				}
			}
		});


		// --- Logic for "Permanent Address same as Current Address" checkbox ---
		$('#sameAsCurrent').on('change', function() {
			const permanentFields = [
				'permanent_house_no', 'permanent_street_no', 'permanent_block_no',
				'permanent_period_from', 'permanent_period_to', 'permanent_street',
				'permanent_landmark', 'permanent_post_office', 'permanent_police_station',
				'permanent_zip_code', 'permanent_city', 'permanent_country', 'permanent_state'
			];

			if ($(this).is(':checked')) {
				permanentFields.forEach(function(field) {
					const currentFieldId = field.replace('permanent_', 'current_');
					$(`#${field}`).val($(`#${currentFieldId}`).val());
					$(`#${field}`).addClass('filled'); // Add filled class for copied values
					clearError(field); // Clear any error if copied value is valid
				});
			} else {
				permanentFields.forEach(function(field) {
					$(`#${field}`).val('').removeClass('filled');
					clearError(field); // Clear error when clearing field
				});
			}
			updateProfileProgress(); // Update progress bar after copying
		});

		// --- Photo Upload with Drag & Drop and Preview ---
		const photoInput = $('#photo');
		const photoDropArea = $('#photoDropArea');
		const photoPreviewContainer = $('#photoPreviewContainer');
		const photoPreviewImg = $('#photoPreview');
		const changePhotoBtn = $('#changePhotoBtn');
		const removePhotoOverlayBtn = $('.remove-photo-btn-overlay');

		function updatePhotoDisplay(file) {
			if (file && file.type.startsWith('image/')) {
				const reader = new FileReader();
				reader.onload = function(e) {
					photoPreviewImg.attr('src', e.target.result);
					photoDropArea.hide();
					photoPreviewContainer.show();
				};
				reader.readAsDataURL(file);
				clearError('photo');
			} else {
				// If file is not provided or not an image, reset display
				resetPhotoDisplay();
				// Only show error if a file was *attempted* to be selected and was invalid
				if (photoInput[0].files.length > 0 && file && !file.type.startsWith('image/')) {
					showError('photo', 'Please select a valid image file (e.g., JPG, PNG).');
				} else if (photoInput[0].files.length === 0 && file) { // case where a file was explicitly deselected
					// No error needed if it's just deselected
				}
			}
			updateProfileProgress(); // Update progress bar
		}

		function resetPhotoDisplay() {
			photoInput.val(''); // Clear native file input value
			photoInput.prop('files', new DataTransfer().files); // Clear FileList to prevent re-submission of old file
			photoPreviewImg.attr('src', '#'); // Clear preview image src
			photoPreviewContainer.hide(); // Hide preview container
			photoDropArea.show(); // Show drag & drop area
			clearError('photo'); // Clear any error messages for photo
			updateProfileProgress(); // Update progress bar
		}

		// Handle file selection via click on drop area's inner content
		photoDropArea.on('click', '.photo-upload-inner', function(e) {
			photoInput.click();
		});

		// Handle file input change event
		photoInput.on('change', function() {
			updatePhotoDisplay(this.files[0]);
		});

		// Handle drag and drop events
		photoDropArea.on('dragenter', function(e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).addClass('drag-over');
		});

		photoDropArea.on('dragleave', function(e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).removeClass('drag-over');
		});

		photoDropArea.on('dragover', function(e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).addClass('drag-over'); // Add class on drag over
		});

		photoDropArea.on('drop', function(e) {
			e.preventDefault();
			e.stopPropagation();
			$(this).removeClass('drag-over'); // Remove class on drop

			const files = e.originalEvent.dataTransfer.files;
			if (files.length > 0) {
				photoInput.prop('files', files); // Set the file to the input
				updatePhotoDisplay(files[0]);
			}
		});

		// Change photo button functionality
		changePhotoBtn.on('click', function() {
			photoInput.click(); // Trigger file input click again
		});

		// Remove photo button functionality (overlay on preview)
		removePhotoOverlayBtn.on('click', function(e) {
			e.stopPropagation(); // Prevent click from bubbling to other elements
			resetPhotoDisplay();
		});

		// --- Dynamic Table Rows (Academic, Family, etc.) - validation updated ---
		// Function to handle adding generic rows (used by multiple tables)
		function handleAddRecord(buttonId, tableId, requiredFields, getRowHtml) {
			$(`#${buttonId}`).on('click', function() {
				let recordValid = true;
				let firstInvalidRecordField = null;

				// Clear errors for the current form row related to this add button
				const $formRowContainer = $(this).prev('.form-row'); // Assumes form-row is just before the button

				$formRowContainer.find('.form-error').text('');
				$formRowContainer.find('.form-control').removeClass('is-invalid');
				// Clear invalid state for Select2 rendered elements in this section
				$formRowContainer.find('.select2-container--default .select2-selection--single').removeClass('is-invalid');


				$.each(requiredFields, function(index, fieldId) {
					const $input = $('#' + fieldId);
					// For select2, ensure to pass the original select element to validateField
					if ($input.hasClass('select2-hidden-accessible')) {
						if (!$input.val() || $input.val() === '') {
							showError(fieldId, 'This field is required for adding a record.');
							recordValid = false;
							if (!firstInvalidRecordField) {
								firstInvalidRecordField = fieldId;
							}
							$input.next('.select2-container').find('.select2-selection__rendered').addClass('is-invalid');
						} else {
							clearError(fieldId);
						}
					} else {
						if (!validateField($input)) {
							recordValid = false;
							if (!firstInvalidRecordField) {
								firstInvalidRecordField = fieldId;
							}
						}
					}
				});

				if (!recordValid) {
					showFormAlert('danger', 'Please fill all required fields correctly before adding this record.');
					if (firstInvalidRecordField) {
						setTimeout(() => {
							const $errorField = $('#' + firstInvalidRecordField);
							if ($errorField.hasClass('select2-hidden-accessible')) {
								$errorField.next('.select2-container')[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
							} else {
								$errorField[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
							}
						}, 100);
					}
					return;
				}

				// Append new row
				const newRow = getRowHtml();
				$(`#${tableId} tbody`).append(newRow);

				// Clear form fields after adding
				$formRowContainer.find('input:not([type="file"]), select, textarea').val('').removeClass('filled');
				$formRowContainer.find('select.select2').val(null).trigger('change'); // Clear select2 specifically
				$formRowContainer.find('.form-error').text(''); // Clear any validation messages from these fields
				$formRowContainer.find('.form-control').removeClass('is-invalid'); // Remove red borders
				updateProfileProgress(); // Update progress bar
			});
		}

		// Academic Records
		handleAddRecord('addAcademicRecord', 'academicRecordsTable',
			['academic_from_year', 'academic_to_year', 'academic_examination', 'academic_institute', 'academic_subject', 'academic_grade', 'academic_university'],
			function() {
				const fromYear = $('#academic_from_year').val();
				const toYear = $('#academic_to_year').val();
				const examination = $('#academic_examination').val();
				const certificationType = $('#academic_certification_type').val();
				const certification = $('#academic_certification').val();
				const institute = $('#academic_institute').val();
				const subject = $('#academic_subject').val();
				const grade = $('#academic_grade').val();
				const university = $('#academic_university').val();
				return `
                <tr>
                    <td>${fromYear}</td>
                    <td>${toYear}</td>
                    <td>${examination}</td>
                    <td>${certificationType}</td>
                    <td>${certification}</td>
                    <td>${institute}</td>
                    <td>${subject}</td>
                    <td>${grade}</td>
                    <td>${university}</td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                </tr>
            `;
			}
		);

		// Family Records
		handleAddRecord('addFamilyRecord', 'familyRecordsTable',
			['family_first_name', 'family_last_name', 'family_relation', 'family_gender', 'family_dob', 'family_contact_no'],
			function() {
				const firstName = $('#family_first_name').val();
				const middleName = $('#family_middle_name').val();
				const lastName = $('#family_last_name').val();
				const relation = $('#family_relation').val();
				const gender = $('#family_gender').val();
				const dob = $('#family_dob').val();
				const contactNo = $('#family_contact_no').val();
				const dependent = $('#family_dependent').val();
				const residing = $('#family_residing_with_employee').val();
				return `
                <tr>
                    <td>${firstName} ${middleName} ${lastName}</td>
                    <td>${relation}</td>
                    <td>${gender}</td>
                    <td>${dob}</td>
                    <td>${contactNo}</td>
                    <td>${dependent}</td>
                    <td>${residing}</td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                </tr>
            `;
			}
		);

		// Nomination Records
		handleAddRecord('addNomineeRecord', 'nomineeRecordsTable',
			['nominee_name', 'nominee_relation', 'nominee_percentage'],
			function() {
				const name = $('#nominee_name').val();
				const relation = $('#nominee_relation').val();
				const percentage = $('#nominee_percentage').val();
				const contact = $('#nominee_contact').val();
				return `
                <tr>
                    <td>${name}</td>
                    <td>${relation}</td>
                    <td>${percentage}%</td>
                    <td>${contact}</td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                </tr>
            `;
			}
		);

		// Career Records
		handleAddRecord('addCareerRecord', 'careerRecordsTable',
			['career_from_date', 'career_to_date', 'career_employer', 'career_position', 'career_address', 'career_responsibility', 'career_reason_for_change'],
			function() {
				const fromDate = $('#career_from_date').val();
				const toDate = $('#career_to_date').val();
				const employer = $('#career_employer').val();
				const position = $('#career_position').val();
				const department = $('#career_department').val();
				const reasonForChange = $('#career_reason_for_change').val();
				return `
                <tr>
                    <td>${fromDate}</td>
                    <td>${toDate}</td>
                    <td>${employer}</td>
                    <td>${position}</td>
                    <td>${department}</td>
                    <td>${reasonForChange}</td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                </tr>
            `;
			}
		);

		// Emergency Contact Records
		handleAddRecord('addEmergencyRecord', 'emergencyRecordsTable',
			['emergency_name', 'emergency_relation', 'emergency_contact1'],
			function() {
				const name = $('#emergency_name').val();
				const relation = $('#emergency_relation').val();
				const contact1 = $('#emergency_contact1').val();
				const contact2 = $('#emergency_contact2').val();
				const contact3 = $('#emergency_contact3').val();
				return `
                <tr>
                    <td>${name}</td>
                    <td>${relation}</td>
                    <td>${contact1}</td>
                    <td>${contact2}</td>
                    <td>${contact3}</td>
                    <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                </tr>
            `;
			}
		);

		// Attachment Records
		$('#addAttachmentRecord').on('click', function() {
			let attachmentValid = true;
			const description = $('#attachment_description').val();
			const fileInput = $('#attachment_file')[0];
			let fileName = '';

			clearError('attachment_file'); // Clear previous error for file input

			if (fileInput.files.length > 0) {
				fileName = fileInput.files[0].name;
			} else {
				showError('attachment_file', 'Please select a file.');
				attachmentValid = false;
			}

			if (!attachmentValid) {
				showFormAlert('danger', 'Please fix the errors in the attachment section before adding a record.');
				if (fileInput.files.length === 0) { // Scroll to file input if it's the problem
					$('#attachment_file')[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
				}
				return;
			}

			const dateAdded = new Date().toLocaleDateString(); // Simple date for display

			const newRow = `
            <tr>
                <td>${dateAdded}</td>
                <td>${description}</td>
                <td>${fileName}</td>
                <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
            </tr>
        `;
			$('#attachmentRecordsTable tbody').append(newRow);
			$('#attachment_description').val('').removeClass('filled');
			$('#attachment_file').val(''); // Clear the file input
			updateProfileProgress(); // Update progress bar
		});

		// Remove row functionality for all tables
		$(document).on('click', '.remove-row', function() {
			$(this).closest('tr').remove();
			updateProfileProgress(); // Update progress bar
		});

		// --- Profile Progress Bar Logic ---
		function updateProfileProgress() {
			// Define all fields that contribute to overall progress, including those within dynamic tables.
			// This is a simplified representation. In a real app, you might have specific counts per section.
			const allRequiredFieldsInFixedSections = [
				'employee_code', 'employment_type', 'posting_city', 'posting_branch', 'first_name',
				'last_name', 'company', 'salary_branch', 'designation', 'attendance_type',
				'gender', 'dob', 'email', 'mobile', 'pan_no', 'marital_status',
				// Add other "required" fields from non-dynamic sections if they contribute to overall progress
				'permanent_country', 'permanent_state' // from Address tab
			];

			let totalProgressPoints = allRequiredFieldsInFixedSections.length;
			let filledProgressPoints = 0;

			// Check fixed section fields
			$.each(allRequiredFieldsInFixedSections, function(index, fieldId) {
				const $input = $('#' + fieldId);
				if ($input.length) { // Ensure field exists
					if ($input.val() && $input.val().trim() !== '' && ($input.is('select') ? $input.val() !== '' : true)) {
						filledProgressPoints++;
					}
				}
			});

			// Add points for dynamic sections if at least one record exists
			// Each of these represents a section completion for the progress bar
			if ($('#photo').val()) { // Photo counts as a point if uploaded
				filledProgressPoints++;
			}
			totalProgressPoints++; // Add 1 for the photo slot

			if ($('#academicRecordsTable tbody tr').length > 0) filledProgressPoints++;
			if ($('#familyRecordsTable tbody tr').length > 0) filledProgressPoints++;
			if ($('#nomineeRecordsTable tbody tr').length > 0) filledProgressPoints++;
			if ($('#careerRecordsTable tbody tr').length > 0) filledProgressPoints++;
			if ($('#emergencyRecordsTable tbody tr').length > 0) filledProgressPoints++;
			if ($('#attachmentRecordsTable tbody tr').length > 0) filledProgressPoints++;

			totalProgressPoints += 6; // Add 1 point for each of these 6 dynamic sections to the total

			let percent = Math.round((filledProgressPoints / totalProgressPoints) * 100);

			// Ensure percentage is between 0 and 100
			percent = Math.max(0, Math.min(100, percent));

			$('#profile-progress-bar').css('width', percent + '%').text(percent + '%');
			// Motivational message
			let msg = '';
			if(percent < 30) msg = 'Let\'s get started!';
			else if(percent < 60) msg = 'Good going!';
			else if(percent < 90) msg = 'Almost there!';
			else if(percent < 100) msg = 'You are awesome! Just a few steps left to achieve milestone.';
			else msg = 'Congratulations! Profile complete!';
			$('#profile-progress-text').text(msg);
		}
		// Initial update
		updateProfileProgress();

		// --- Local Storage for Draft ---
		const FORM_KEY = 'employeeFormDraft';
		function saveDraft() {
			let data = {};
			$('#employeeForm').find('input, select, textarea').each(function() {
				if(this.type === 'file') return; // Skip file input for simple value storage
				data[this.name] = $(this).val();
			});

			// Save dynamic table data as arrays of objects
			data.academicRecords = [];
			$('#academicRecordsTable tbody tr').each(function() {
				const rowData = {
					fromYear: $(this).find('td:eq(0)').text(),
					toYear: $(this).find('td:eq(1)').text(),
					examination: $(this).find('td:eq(2)').text(),
					certificationType: $(this).find('td:eq(3)').text(),
					certification: $(this).find('td:eq(4)').text(),
					institute: $(this).find('td:eq(5)').text(),
					subject: $(this).find('td:eq(6)').text(),
					grade: $(this).find('td:eq(7)').text(),
					university: $(this).find('td:eq(8)').text(),
				};
				data.academicRecords.push(rowData);
			});

			data.familyRecords = [];
			$('#familyRecordsTable tbody tr').each(function() {
				const rowData = {
					name: $(this).find('td:eq(0)').text(),
					relation: $(this).find('td:eq(1)').text(),
					gender: $(this).find('td:eq(2)').text(),
					dob: $(this).find('td:eq(3)').text(),
					contact: $(this).find('td:eq(4)').text(),
					dependent: $(this).find('td:eq(5)').text(),
					residing: $(this).find('td:eq(6)').text(),
				};
				data.familyRecords.push(rowData);
			});

			data.nomineeRecords = [];
			$('#nomineeRecordsTable tbody tr').each(function() {
				const rowData = {
					name: $(this).find('td:eq(0)').text(),
					relation: $(this).find('td:eq(1)').text(),
					percentage: $(this).find('td:eq(2)').text(),
					contact: $(this).find('td:eq(3)').text(),
				};
				data.nomineeRecords.push(rowData);
			});

			data.careerRecords = [];
			$('#careerRecordsTable tbody tr').each(function() {
				const rowData = {
					fromDate: $(this).find('td:eq(0)').text(),
					toDate: $(this).find('td:eq(1)').text(),
					employer: $(this).find('td:eq(2)').text(),
					position: $(this).find('td:eq(3)').text(),
					department: $(this).find('td:eq(4)').text(),
					reason: $(this).find('td:eq(5)').text(),
				};
				data.careerRecords.push(rowData);
			});

			data.emergencyRecords = [];
			$('#emergencyRecordsTable tbody tr').each(function() {
				const rowData = {
					name: $(this).find('td:eq(0)').text(),
					relation: $(this).find('td:eq(1)').text(),
					contact1: $(this).find('td:eq(2)').text(),
					contact2: $(this).find('td:eq(3)').text(),
					contact3: $(this).find('td:eq(4)').text(),
				};
				data.emergencyRecords.push(rowData);
			});

			data.attachmentRecords = [];
			$('#attachmentRecordsTable tbody tr').each(function() {
				const rowData = {
					date: $(this).find('td:eq(0)').text(),
					description: $(this).find('td:eq(1)').text(),
					fileName: $(this).find('td:eq(2)').text(),
				};
				data.attachmentRecords.push(rowData);
			});

			// For photo, you can only save its URL/path if it's already on the server.
			// If it's a new unsaved photo, you can't store the File object directly in localStorage.
			// For local development, if you want to keep the preview on refresh, you'd convert it to Base64.
			// But for a real app, this should ideally be handled by loading an existing photo from the database.
			// For this example, we'll assume the photo will be re-uploaded or retrieved from backend on load.
			// data.photoBase64 = photoPreviewImg.attr('src') === '#' ? '' : photoPreviewImg.attr('src'); // Example of saving Base64

			localStorage.setItem(FORM_KEY, JSON.stringify(data));
		}

		function loadDraft() {
			let data = localStorage.getItem(FORM_KEY);
			if(data) {
				data = JSON.parse(data);
				for(let k in data) {
					const $el = $('[name="'+k+'"]');
					if ($el.length && !$el.is('input[type="file"]') && typeof data[k] !== 'object') { // Exclude file input and array data
						$el.val(data[k]);
						// For select2, trigger change to ensure it updates visually
						if ($el.hasClass('select2-hidden-accessible')) {
							$el.trigger('change.select2'); // Trigger Select2's change event
						} else {
							$el.trigger('change'); // Trigger regular change for others
						}
					}
				}

				// Load dynamic table data
				if (data.academicRecords) {
					$('#academicRecordsTable tbody').empty(); // Clear existing rows first
					data.academicRecords.forEach(function(record) {
						const newRow = `
                        <tr>
                            <td>${record.fromYear}</td>
                            <td>${record.toYear}</td>
                            <td>${record.examination}</td>
                            <td>${record.certificationType}</td>
                            <td>${record.certification}</td>
                            <td>${record.institute}</td>
                            <td>${record.subject}</td>
                            <td>${record.grade}</td>
                            <td>${record.university}</td>
                            <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                        </tr>
                    `;
						$('#academicRecordsTable tbody').append(newRow);
					});
				}
				if (data.familyRecords) {
					$('#familyRecordsTable tbody').empty();
					data.familyRecords.forEach(function(record) {
						const newRow = `
                        <tr>
                            <td>${record.name}</td>
                            <td>${record.relation}</td>
                            <td>${record.gender}</td>
                            <td>${record.dob}</td>
                            <td>${record.contact}</td>
                            <td>${record.dependent}</td>
                            <td>${record.residing}</td>
                            <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                        </tr>
                    `;
						$('#familyRecordsTable tbody').append(newRow);
					});
				}
				if (data.nomineeRecords) {
					$('#nomineeRecordsTable tbody').empty();
					data.nomineeRecords.forEach(function(record) {
						const newRow = `
                        <tr>
                            <td>${record.name}</td>
                            <td>${record.relation}</td>
                            <td>${record.percentage}</td>
                            <td>${record.contact}</td>
                            <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                        </tr>
                    `;
						$('#nomineeRecordsTable tbody').append(newRow);
					});
				}
				if (data.careerRecords) {
					$('#careerRecordsTable tbody').empty();
					data.careerRecords.forEach(function(record) {
						const newRow = `
                        <tr>
                            <td>${record.fromDate}</td>
                            <td>${record.toDate}</td>
                            <td>${record.employer}</td>
                            <td>${record.position}</td>
                            <td>${record.department}</td>
                            <td>${record.reason}</td>
                            <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                        </tr>
                    `;
						$('#careerRecordsTable tbody').append(newRow);
					});
				}
				if (data.emergencyRecords) {
					$('#emergencyRecordsTable tbody').empty();
					data.emergencyRecords.forEach(function(record) {
						const newRow = `
                        <tr>
                            <td>${record.name}</td>
                            <td>${record.relation}</td>
                            <td>${record.contact1}</td>
                            <td>${record.contact2}</td>
                            <td>${record.contact3}</td>
                            <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                        </tr>
                    `;
						$('#emergencyRecordsTable tbody').append(newRow);
					});
				}
				if (data.attachmentRecords) {
					$('#attachmentRecordsTable tbody').empty();
					data.attachmentRecords.forEach(function(record) {
						const newRow = `
                        <tr>
                            <td>${record.date}</td>
                            <td>${record.description}</td>
                            <td>${record.fileName}</td>
                            <td><button type="button" class="btn btn-danger btn-sm remove-row">Remove</button></td>
                        </tr>
                    `;
						$('#attachmentRecordsTable tbody').append(newRow);
					});
				}

				// Load photo if saved as Base64 (only if you implemented saving Base64 in saveDraft)
				// if (data.photoBase64) {
				//     photoPreviewImg.attr('src', data.photoBase64);
				//     photoDropArea.hide();
				//     photoPreviewContainer.show();
				// }
			}
			updateProfileProgress(); // Update progress bar after loading draft
		}

		function clearDraft() {
			localStorage.removeItem(FORM_KEY);
			$('#employeeForm')[0].reset(); // Reset native form elements
			$('.form-control').removeClass('filled is-invalid');
			$('.form-error').text('');
			// Clear Select2 as well
			$('select.select2').val(null).trigger('change');
			$('.select2-container--default .select2-selection--single').removeClass('is-invalid filled'); // Ensure visual reset

			// Clear dynamic tables
			$('#academicRecordsTable tbody').empty();
			$('#familyRecordsTable tbody').empty();
			$('#nomineeRecordsTable tbody').empty();
			$('#careerRecordsTable tbody').empty();
			$('#emergencyRecordsTable tbody').empty();
			$('#attachmentRecordsTable tbody').empty();
			resetPhotoDisplay(); // Reset photo upload area
			updateProfileProgress(); // Update progress bar
		}

		// Bind saveDraft to input/change events for non-file inputs
		$('#employeeForm').on('input change', 'input:not([type="file"]), select, textarea', saveDraft);
		// Bind change for Select2 specifically
		$('select.select2').on('change', saveDraft);

		// Load draft on document ready
		loadDraft();

		// Reset button functionality
		$('#resetFormBtn').on('click', function() {
			clearDraft();
		});

		// --- Select2 Initialization ---
		$('#employment_type').select2({
			placeholder: "Select Employment Type *",
			allowClear: true
		});

		// Add .filled class for select on change
		$('select.form-control').on('change', function() {
			if ($(this).val()) {
				$(this).addClass('filled');
			} else {
				$(this).removeClass('filled');
			}
		});
	}); // End of $(document).ready
</script>
