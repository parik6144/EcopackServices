<?php
// Start: employee_form_master.php - Description: This file contains the Master tab content for the Employee Profile form.
?>
	<form id="masterForm" class="employee-form" enctype="multipart/form-data" novalidate>
		<input type="hidden" id="master_employee_id_hidden_field" name="employee_id_hidden_field" value="<?php echo isset($employee_id_encoded) ? $employee_id_encoded : ''; ?>">
		<input type="hidden" id="old_photo_field" name="old_photo" value="<?php echo isset($employee_data['photo']) ? $employee_data['photo'] : ''; ?>">

		<div class="form-row">
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="employee_code" name="employee_code" required
					   placeholder=" " value="<?php echo isset($employee_data['employee_code']) ? $employee_data['employee_code'] : ''; ?>" />
				<label for="employee_code">Employee Code *</label>
				<div class="form-error" id="error_employee_code"></div>
			</div>
			<div class="form-group col-md-4">
				<select class="form-control" id="posting_city" name="posting_city" required>
					<option value="">Select Posting City *</option>
					<?php if (isset($places) && is_array($places)): ?>
						<?php foreach($places as $place): ?>
							<option value="<?php echo $place['place_id']; ?>" data-state="<?php echo $place['state_code']; ?>"
								<?php echo (isset($employee_data['posting_city']) && $employee_data['posting_city'] == $place['place_id']) ? 'selected' : ''; ?>>
								<?php echo $place['place_name']; ?>
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
				<div class="form-error" id="error_posting_city"></div>
			</div>
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="posting_branch" name="posting_branch" required
					   placeholder=" " value="<?php echo isset($employee_data['posting_branch']) ? $employee_data['posting_branch'] : ''; ?>" />
				<label for="posting_branch">Posting Branch *</label>
				<div class="form-error" id="error_posting_branch"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-6">
				<select class="form-control" id="employment_type" name="employment_type" required>
					<option value="">Select Employment Type *</option>
					<?php if (isset($employee_types) && is_array($employee_types)): // Assuming employee_types is passed from controller ?>
						<?php foreach($employee_types as $type): ?>
							<option value="<?php echo $type['employee_type_id']; ?>"
								<?php echo (isset($employee_data['employment_type']) && $employee_data['employment_type'] == $type['employee_type_id']) ? 'selected' : ''; ?>>
								<?php echo $type['type_name']; ?>
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
				<div class="form-error" id="error_employment_type"></div>
			</div>
			<div class="form-group col-md-6">
				<select class="form-control" id="designation" name="designation" required>
					<option value="">Select Designation *</option>
					<?php // Designations will be loaded via AJAX based on employment_type ?>
					<?php // If editing, pre-fill if available (designation_id will be passed to JS for load) ?>
					<?php if (isset($employee_data['designation']) && isset($employee_types)): // Only if employee_types is also available ?>
						<option value="<?php echo $employee_data['designation']; ?>" selected>
							<?php // You might need to fetch designation_name here if not in $employee_data['master_data'] ?>
						</option>
					<?php endif; ?>
				</select>
				<div class="form-error" id="error_designation"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="first_name" name="first_name" required placeholder=" "
					   value="<?php echo isset($employee_data['first_name']) ? $employee_data['first_name'] : ''; ?>" />
				<label for="first_name">First Name *</label>
				<div class="form-error" id="error_first_name"></div>
			</div>
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="middle_name" name="middle_name" placeholder=" "
					   value="<?php echo isset($employee_data['middle_name']) ? $employee_data['middle_name'] : ''; ?>" />
				<label for="middle_name">Middle Name</label>
				<div class="form-error" id="error_middle_name"></div>
			</div>
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="last_name" name="last_name" required placeholder=" "
					   value="<?php echo isset($employee_data['last_name']) ? $employee_data['last_name'] : ''; ?>" />
				<label for="last_name">Last Name *</label>
				<div class="form-error" id="error_last_name"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="company" name="company" required placeholder=" "
					   value="<?php echo isset($employee_data['company']) ? $employee_data['company'] : ''; ?>" />
				<label for="company">Company *</label>
				<div class="form-error" id="error_company"></div>
			</div>
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="salary_branch" name="salary_branch" required placeholder=" "
					   value="<?php echo isset($employee_data['salary_branch']) ? $employee_data['salary_branch'] : ''; ?>" />
				<label for="salary_branch">Salary Branch *</label>
				<div class="form-error" id="error_salary_branch"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-4">
				<input type="text" class="form-control" id="attendance_type" name="attendance_type" required
					   placeholder=" " value="<?php echo isset($employee_data['attendance_type']) ? $employee_data['attendance_type'] : ''; ?>" />
				<label for="attendance_type">Attendance Type *</label>
				<div class="form-error" id="error_attendance_type"></div>
			</div>
			<div class="form-group col-md-4">
				<label for="photo">Photo</label>
				<div class="photo-upload-container" id="photoDropArea" style="<?php echo (isset($employee_data['photo']) && !empty($employee_data['photo'])) ? 'display: none;' : ''; ?>">
					<input type="file" id="photo" name="photo" accept="image/*" />
					<div class="photo-upload-inner">
						<div class="photo-upload-icon">&#x2B;</div>
						<div class="photo-upload-text">Drag & Drop or Click to Upload</div>
					</div>
				</div>
				<div id="photoPreviewContainer" style="text-align: center; <?php echo (isset($employee_data['photo']) && !empty($employee_data['photo'])) ? '' : 'display: none;'; ?>">
					<div class="photo-preview-frame">
						<img id="photoPreview" src="<?php echo (isset($employee_data['photo']) && !empty($employee_data['photo'])) ? base_url('uploads/employee_photos/' . $employee_data['photo']) : '#'; ?>" alt="Photo Preview" />
						<span class="remove-photo-btn-overlay">&times;</span>
					</div>
					<div class="photo-actions">
						<button type="button" class="btn btn-sm btn-info" id="changePhotoBtn">Change Photo</button>
					</div>
				</div>
				<div class="form-error" id="error_photo"></div>
			</div>
		</div>
		<div class="d-flex justify-content-start gap-2 mt-3">
			<button type="submit" class="btn btn-success">Save & Accept Master</button>
			<button type="button" class="btn btn-warning reset-form-btn" data-form-id="masterForm">Reset Master</button>
		</div>
	</form>
<?php
// End: employee_form_master.php
?>
