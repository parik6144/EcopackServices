<?php
// Start: employee_form_personal.php - Description: This file contains the Personal tab content for the Employee Profile form.
?>
	<form id="personalForm" class="employee-form" enctype="multipart/form-data" novalidate>
		<input type="hidden" id="personal_employee_id_hidden_field" name="employee_id_hidden_field" value="<?php echo isset($employee_id_encoded) ? $employee_id_encoded : ''; ?>">

		<ul class="nav nav-pills mb-3" id="personalSubTab" role="tablist">
			<li class="nav-item" role="presentation">
				<a class="nav-link active" id="personal-main-tab" data-toggle="pill" href="#personal-main" role="tab"
				   aria-controls="personal-main" aria-selected="true">Main</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-address-tab" data-toggle="pill" href="#personal-address" role="tab"
				   aria-controls="personal-address" aria-selected="false">Address</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-academic-tab" data-toggle="pill" href="#personal-academic" role="tab"
				   aria-controls="personal-academic" aria-selected="false">Academic</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-family-tab" data-toggle="pill" href="#personal-family" role="tab"
				   aria-controls="personal-family" aria-selected="false">Family</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-nomination-tab" data-toggle="pill" href="#personal-nomination" role="tab"
				   aria-controls="personal-nomination" aria-selected="false">Nomination</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-career-tab" data-toggle="pill" href="#personal-career" role="tab"
				   aria-controls="personal-career" aria-selected="false">Career</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-medical-tab" data-toggle="pill" href="#personal-medical" role="tab"
				   aria-controls="personal-medical" aria-selected="false">Medical</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-emergency-tab" data-toggle="pill" href="#personal-emergency" role="tab"
				   aria-controls="personal-emergency" aria-selected="false">Emergency</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-attachments-tab" data-toggle="pill" href="#personal-attachments" role="tab"
				   aria-controls="personal-attachments" aria-selected="false">Attachments</a>
			</li>
		</ul>
		<div class="tab-content" id="personalSubTabContent">
			<div class="tab-pane fade show active" id="personal-main" role="tabpanel" aria-labelledby="personal-main-tab">
				<h5>General Section</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<select class="form-control" id="gender" name="gender" required>
							<option value="">Select</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
							<option value="Other">Other</option>
						</select>
						<label for="gender">Gender *</label>
						<div class="form-error" id="error_gender"></div>
					</div>
					<div class="form-group col-md-3">
						<select class="form-control" id="blood_group" name="blood_group">
							<option value="">Select</option>
							<option value="A+ve">A+ve</option>
							<option value="B+ve">B+ve</option>
							<option value="O+ve">O+ve</option>
							<option value="AB+ve">AB+ve</option>
							<option value="A-ve">A-ve</option>
							<option value="B-ve">B-ve</option>
							<option value="O-ve">O-ve</option>
							<option value="AB-ve">AB-ve</option>
						</select>
						<label for="blood_group">Blood Group</label>
						<div class="form-error" id="error_blood_group"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="dob" name="dob" required />
						<label for="dob">Date of Birth *</label>
						<div class="form-error" id="error_dob"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="father_name" name="father_name" placeholder=" " />
						<label for="father_name">Father's Name</label>
						<div class="form-error" id="error_father_name"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="email" class="form-control" id="email" name="email" required maxlength="100"
							   placeholder=" " data-toggle="tooltip" data-placement="right"
							   title="Enter a valid email address (e.g., example@domain.com)">
						<label for="email">Email *</label>
						<div class="form-error" id="error_email"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="mobile" name="mobile" required maxlength="10"
							   minlength="10" placeholder=" " data-toggle="tooltip" data-placement="right"
							   title="Enter a valid 10-digit mobile number (starts with 6-9)">
						<label for="mobile">Mobile No *</label>
						<div class="form-error" id="error_mobile"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="home_phone_no" name="home_phone_no"
							   placeholder="e.g., 0123-456789" />
						<label for="home_phone_no">Home Phone No</label>
						<div class="form-error" id="error_home_phone_no"></div>
					</div>
				</div>
				<h5>Origin Section</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="caste" name="caste" placeholder=" " />
						<label for="caste">Caste</label>
						<div class="form-error" id="error_caste"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="religion" name="religion" placeholder=" " />
						<label for="religion">Religion</label>
						<div class="form-error" id="error_religion"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="citizenship" name="citizenship" placeholder=" " />
						<label for="citizenship">Citizenship</label>
						<div class="form-error" id="error_citizenship"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="country_of_birth" name="country_of_birth"
							   placeholder=" " />
						<label for="country_of_birth">Country of Birth</label>
						<div class="form-error" id="error_country_of_birth"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<select class="form-control" id="disabilities" name="disabilities">
							<option value="">Select</option>
							<option value="Yes">Yes</option>
							<option value="No">No</option>
						</select>
						<label for="disabilities">Disabilities</label>
						<div class="form-error" id="error_disabilities"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="birth_place" name="birth_place" placeholder=" " />
						<label for="birth_place">Birth Place</label>
						<div class="form-error" id="error_birth_place"></div>
					</div>
				</div>
				<h5>Marital Section</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<select class="form-control" id="marital_status" name="marital_status" required>
							<option value="">Select</option>
							<option value="Single">Single</option>
							<option value="Married">Married</option>
							<option value="Divorced">Divorced</option>
							<option value="Widowed">Widowed</option>
						</select>
						<label for="marital_status">Status *</label>
						<div class="form-error" id="error_marital_status"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="marriage_date" name="marriage_date" />
						<label for="marriage_date">Marriage Date</label>
						<div class="form-error" id="error_marriage_date"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="no_of_children" name="no_of_children"
							   placeholder="e.g., 2" />
						<label for="no_of_children">No. of Children</label>
						<div class="form-error" id="error_no_of_children"></div>
					</div>
				</div>
				<h5>Passport Section</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="passport_name" name="passport_name" placeholder=" " />
						<label for="passport_name">Name in Passport</label>
						<div class="form-error" id="error_passport_name"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="passport_no" name="passport_no" placeholder=" " />
						<label for="passport_no">Passport No</label>
						<div class="form-error" id="error_passport_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="passport_valid_from" name="passport_valid_from" />
						<label for="passport_valid_from">Validity From</label>
						<div class="form-error" id="error_passport_valid_from"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="passport_valid_to" name="passport_valid_to" />
						<label for="passport_valid_to">Validity To</label>
						<div class="form-error" id="error_passport_valid_to"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="passport_issuer" name="passport_issuer"
							   placeholder=" " />
						<label for="passport_issuer">Passport Issuer</label>
						<div class="form-error" id="error_passport_issuer"></div>
					</div>
				</div>
				<h5>Social Section</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="url" class="form-control" id="linkedin" name="linkedin"
							   placeholder="e.g., https://linkedin.com/in/username" />
						<label for="linkedin">LinkedIn</label>
						<div class="form-error" id="error_linkedin"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="url" class="form-control" id="facebook" name="facebook"
							   placeholder="e.g., https://facebook.com/username" />
						<label for="facebook">Facebook</label>
						<div class="form-error" id="error_facebook"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="url" class="form-control" id="twitter" name="twitter"
							   placeholder="e.g., https://twitter.com/username" />
						<label for="twitter">Twitter</label>
						<div class="form-error" id="error_twitter"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="url" class="form-control" id="instagram" name="instagram"
							   placeholder="e.g., https://instagram.com/username" />
						<label for="instagram">Instagram</label>
						<div class="form-error" id="error_instagram"></div>
					</div>
				</div>
				<h5>Others Section</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="pan_no" name="pan_no" required
							   placeholder="e.g., ABCDE1234F" />
						<label for="pan_no">PAN No. *</label>
						<div class="form-error" id="error_pan_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="aadhar_no" name="aadhar_no" maxlength="12"
							   placeholder="e.g., 123456789012" />
						<label for="aadhar_no">Aadhar No</label>
						<div class="form-error" id="error_aadhar_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="voter_id" name="voter_id" placeholder=" " />
						<label for="voter_id">Voter ID</label>
						<div class="form-error" id="error_voter_id"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="driving_license_no" name="driving_license_no"
							   placeholder=" " />
						<label for="driving_license_no">Driving License No</label>
						<div class="form-error" id="error_driving_license_no"></div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="personal-address" role="tabpanel" aria-labelledby="personal-address-tab">
				<h5>Current Address</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_house_no" name="current_house_no"
							   placeholder="e.g., 101" />
						<label for="current_house_no">House No</label>
						<div class="form-error" id="error_current_house_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_street_no" name="current_street_no"
							   placeholder="e.g., 5" />
						<label for="current_street_no">Street No</label>
						<div class="form-error" id="error_current_street_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_block_no" name="current_block_no"
							   placeholder="e.g., Block A" />
						<label for="current_block_no">Block No</label>
						<div class="form-error" id="error_current_block_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="current_period_from" name="current_period_from" />
						<label for="current_period_from">Period of Stay (From)</label>
						<div class="form-error" id="error_current_period_from"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="current_period_to" name="current_period_to" />
						<label for="current_period_to">Period of Stay (To)</label>
						<div class="form-error" id="error_current_period_to"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_street" name="current_street"
							   placeholder="e.g., Main Street" />
						<label for="current_street">Street</label>
						<div class="form-error" id="error_current_street"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_landmark" name="current_landmark"
							   placeholder="e.g., Near City Mall" />
						<label for="current_landmark">Landmark</label>
						<div class="form-error" id="error_current_landmark"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_post_office" name="current_post_office"
							   placeholder="e.g., GPO" />
						<label for="current_post_office">Post Office</label>
						<div class="form-error" id="error_current_post_office"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_police_station" name="current_police_station"
							   placeholder="e.g., Town Police Station" />
						<label for="current_police_station">Police Station</label>
						<div class="form-error" id="error_current_police_station"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_zip_code" name="current_zip_code"
							   placeholder="e.g., 831001" />
						<label for="current_zip_code">Zip Code</label>
						<div class="form-error" id="error_current_zip_code"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_city" name="current_city"
							   placeholder="e.g., Jamshedpur" />
						<label for="current_city">City</label>
						<div class="form-error" id="error_current_city"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_country" name="current_country"
							   placeholder="e.g., India" />
						<label for="current_country">Country</label>
						<div class="form-error" id="error_current_country"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="current_state" name="current_state"
							   placeholder="e.g., Jharkhand" />
						<label for="current_state">State</label>
						<div class="form-error" id="error_current_state"></div>
					</div>
				</div>
				<hr>
				<div class="form-check mb-2">
					<input class="form-check-input" type="checkbox" value="1" id="sameAsCurrent">
					<label class="form-check-label" for="sameAsCurrent">Permanent Address same as Current Address</label>
				</div>
				<h5>Permanent Address</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_house_no" name="permanent_house_no"
							   placeholder="e.g., 101" />
						<label for="permanent_house_no">House No</label>
						<div class="form-error" id="error_permanent_house_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_street_no" name="permanent_street_no"
							   placeholder="e.g., 5" />
						<label for="permanent_street_no">Street No</label>
						<div class="form-error" id="error_permanent_street_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_block_no" name="permanent_block_no"
							   placeholder="e.g., Block A" />
						<label for="permanent_block_no">Block No</label>
						<div class="form-error" id="error_permanent_block_no"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="permanent_period_from" name="permanent_period_from" />
						<label for="permanent_period_from">Period of Stay (From)</label>
						<div class="form-error" id="error_permanent_period_from"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="date" class="form-control" id="permanent_period_to" name="permanent_period_to" />
						<label for="permanent_period_to">Period of Stay (To)</label>
						<div class="form-error" id="error_permanent_period_to"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_street" name="permanent_street"
							   placeholder="e.g., Main Street" />
						<label for="permanent_street">Street</label>
						<div class="form-error" id="error_permanent_street"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_landmark" name="permanent_landmark"
							   placeholder="e.g., Near City Mall" />
						<label for="permanent_landmark">Landmark</label>
						<div class="form-error" id="error_permanent_landmark"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_post_office" name="permanent_post_office"
							   placeholder="e.g., GPO" />
						<label for="permanent_post_office">Post Office</label>
						<div class="form-error" id="error_permanent_post_office"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_police_station" name="permanent_police_station"
							   placeholder="e.g., Town Police Station" />
						<label for="permanent_police_station">Police Station</label>
						<div class="form-error" id="error_permanent_police_station"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_zip_code" name="permanent_zip_code"
							   placeholder="e.g., 831001" />
						<label for="permanent_zip_code">Zip Code</label>
						<div class="form-error" id="error_permanent_zip_code"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_city" name="permanent_city"
							   placeholder="e.g., Jamshedpur" />
						<label for="permanent_city">City</label>
						<div class="form-error" id="error_permanent_city"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_country" name="permanent_country" required
							   placeholder="e.g., India" />
						<label for="permanent_country">Country *</label>
						<div class="form-error" id="error_permanent_country"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="permanent_state" name="permanent_state" required
							   placeholder="e.g., Jharkhand" />
						<label for="permanent_state">State *</label>
						<div class="form-error" id="error_permanent_state"></div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="personal-academic" role="tabpanel" aria-labelledby="personal-academic-tab">
				<h5>Add Academic Record</h5>
				<div id="academic-form-row" class="form-row">
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="academic_from_year" name="academic_from_year"
							   min="1900" max="2100" required placeholder="e.g., 2010" />
						<label for="academic_from_year">From Year *</label>
						<div class="form-error" id="error_academic_from_year"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="academic_to_year" name="academic_to_year"
							   min="1900" max="2100" required placeholder="e.g., 2014" />
						<label for="academic_to_year">To Year *</label>
						<div class="form-error" id="error_academic_to_year"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_examination" name="academic_examination"
							   required placeholder="e.g., B.Tech" />
						<label for="academic_examination">Examination *</label>
						<div class="form-error" id="error_academic_examination"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_certification_type"
							   name="academic_certification_type" placeholder="e.g., Degree" />
						<label for="academic_certification_type">Type of Certification</label>
						<div class="form-error" id="error_academic_certification_type"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_certification" name="academic_certification"
							   placeholder="e.g., Computer Science" />
						<label for="academic_certification">Certification</label>
						<div class="form-error" id="error_academic_certification"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_institute" name="academic_institute" required
							   placeholder="e.g., IIT Delhi" />
						<label for="academic_institute">Institute *</label>
						<div class="form-error" id="error_academic_institute"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_college_contact_no"
							   name="academic_college_contact_no" placeholder="e.g., +91-1234567890" />
						<label for="academic_college_contact_no">College Contact No</label>
						<div class="form-error" id="error_academic_college_contact_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_college_address" name="academic_college_address"
							   placeholder="e.g., Delhi, India" />
						<label for="academic_college_address">College Address</label>
						<div class="form-error" id="error_academic_college_address"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_program" name="academic_program"
							   placeholder="e.g., Engineering" />
						<label for="academic_program">Program</label>
						<div class="form-error" id="error_academic_program"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_subject" name="academic_subject" required
							   placeholder="e.g., Data Structures" />
						<label for="academic_subject">Subject *</label>
						<div class="form-error" id="error_academic_subject"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_registration_no" name="academic_registration_no"
							   placeholder=" " />
						<label for="academic_registration_no">Registration No</label>
						<div class="form-error" id="error_academic_registration_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_roll_no" name="academic_roll_no"
							   placeholder=" " />
						<label for="academic_roll_no">Roll No</label>
						<div class="form-error" id="error_academic_roll_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_grade" name="academic_grade" required
							   placeholder="e.g., A / 8.5 CGPA" />
						<label for="academic_grade">Grade *</label>
						<div class="form-error" id="error_academic_grade"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_university" name="academic_university" required
							   placeholder="e.g., Delhi University" />
						<label for="academic_university">University *</label>
						<div class="form-error" id="error_academic_university"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_university_country"
							   name="academic_university_country" placeholder="e.g., India" />
						<label for="academic_university_country">University Country</label>
						<div class="form-error" id="error_academic_university_country"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_university_state"
							   name="academic_university_state" placeholder="e.g., Delhi" />
						<label for="academic_university_state">University State</label>
						<div class="form-error" id="error_academic_university_state"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_university_city"
							   name="academic_university_city" placeholder="e.g., New Delhi" />
						<label for="academic_university_city">University City</label>
						<div class="form-error" id="error_academic_university_city"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="academic_university_contact_no"
							   name="academic_university_contact_no" placeholder="e.g., +91-9876543210" />
						<label for="academic_university_contact_no">University Contact No</label>
						<div class="form-error" id="error_academic_university_contact_no"></div>
					</div>
					<div class="form-group col-md-2">
						<select class="form-control" id="academic_educated_in_overseas"
								name="academic_educated_in_overseas">
							<option value="">Select</option>
							<option value="Yes">Yes</option>
							<option value="No">No</option>
						</select>
						<label for="academic_educated_in_overseas">Educated In Overseas</label>
						<div class="form-error" id="error_academic_educated_in_overseas"></div>
					</div>
				</div>
				<button type="button" class="btn btn-info mb-2" id="addAcademicRecord">Add Academic Record</button>
				<h5>Academic Records</h5>
				<table class="table table-bordered" id="academicRecordsTable">
					<thead>
					<tr>
						<th>From</th>
						<th>To</th>
						<th>Exam</th>
						<th>Type</th>
						<th>Cert.</th>
						<th>Institute</th>
						<th>Subject</th>
						<th>Grade</th>
						<th>University</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
			<div class="tab-pane fade" id="personal-family" role="tabpanel" aria-labelledby="personal-family-tab">
				<h5>Add Family Member</h5>
				<div id="family-form-row" class="form-row">
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_first_name" name="family_first_name" required
							   placeholder=" " />
						<label for="family_first_name">First Name *</label>
						<div class="form-error" id="error_family_first_name"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_middle_name" name="family_middle_name"
							   placeholder=" " />
						<label for="family_middle_name">Middle Name</label>
						<div class="form-error" id="error_family_middle_name"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_last_name" name="family_last_name" required
							   placeholder=" " />
						<label for="family_last_name">Last Name *</label>
						<div class="form-error" id="error_family_last_name"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_relation" name="family_relation" required
							   placeholder="e.g., Spouse, Child, Parent" />
						<label for="family_relation">Relation *</label>
						<div class="form-error" id="error_family_relation"></div>
					</div>
					<div class="form-group col-md-2">
						<select class="form-control" id="family_gender" name="family_gender" required>
							<option value="">Select</option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
							<option value="Other">Other</option>
						</select>
						<label for="family_gender">Gender *</label>
						<div class="form-error" id="error_family_gender"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="date" class="form-control" id="family_dob" name="family_dob" required
							   placeholder=" " />
						<label for="family_dob">DOB *</label>
						<div class="form-error" id="error_family_dob"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_contact_no" name="family_contact_no" required
							   placeholder="e.g., +91-9876543210" />
						<label for="family_contact_no">Contact No *</label>
						<div class="form-error" id="error_family_contact_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="email" class="form-control" id="family_email_id" name="family_email_id"
							   placeholder="e.g., email@example.com" />
						<label for="family_email_id">Email Id</label>
						<div class="form-error" id="error_family_email_id"></div>
					</div>
					<div class="form-group col-md-2">
						<select class="form-control" id="family_dependent" name="family_dependent">
							<option value="">Select</option>
							<option value="Yes">Yes</option>
							<option value="No">No</option>
						</select>
						<label for="family_dependent">Dependent</label>
						<div class="form-error" id="error_family_dependent"></div>
					</div>
					<div class="form-group col-md-2">
						<select class="form-control" id="family_residing_with_employee"
								name="family_residing_with_employee">
							<option value="">Select</option>
							<option value="Yes">Yes</option>
							<option value="No">No</option>
						</select>
						<label for="family_residing_with_employee">Residing with employee</label>
						<div class="form-error" id="error_family_residing_with_employee"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_address" name="family_address"
							   placeholder=" " />
						<label for="family_address">Address</label>
						<div class="form-error" id="error_family_address"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="family_aadhar_no" name="family_aadhar_no"
							   placeholder=" " />
						<label for="family_aadhar_no">Aadhar No</label>
						<div class="form-error" id="error_family_aadhar_no"></div>
					</div>
				</div>
				<button type="button" class="btn btn-info mb-2" id="addFamilyRecord">Add Family Member</button>
				<h5>Family Records</h5>
				<table class="table table-bordered" id="familyRecordsTable">
					<thead>
					<tr>
						<th>Name</th>
						<th>Relation</th>
						<th>Gender</th>
						<th>DOB</th>
						<th>Contact</th>
						<th>Dependent</th>
						<th>Residing</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
			<div class="tab-pane fade" id="personal-nomination" role="tabpanel" aria-labelledby="personal-nomination-tab">
				<h5>Add Nominee</h5>
				<div id="nomination-form-row" class="form-row">
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="nominee_name" name="nominee_name" required
							   placeholder=" " />
						<label for="nominee_name">Nominee Name *</label>
						<div class="form-error" id="error_nominee_name"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="nominee_relation" name="nominee_relation" required
							   placeholder="e.g., Mother, Brother" />
						<label for="nominee_relation">Relation *</label>
						<div class="form-error" id="error_nominee_relation"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="nominee_percentage" name="nominee_percentage" min="0"
							   max="100" required placeholder="e.g., 100" />
						<label for="nominee_percentage">Percentage *</label>
						<div class="form-error" id="error_nominee_percentage"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="nominee_address" name="nominee_address"
							   placeholder=" " />
						<label for="nominee_address">Address</label>
						<div class="form-error" id="error_nominee_address"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="nominee_contact" name="nominee_contact"
							   placeholder="e.g., +91-9876543210" />
						<label for="nominee_contact">Contact</label>
						<div class="form-error" id="error_nominee_contact"></div>
					</div>
				</div>
				<button type="button" class="btn btn-info mb-2" id="addNomineeRecord">Add Nominee</button>
				<h5>Nominee Records</h5>
				<table class="table table-bordered" id="nomineeRecordsTable">
					<thead>
					<tr>
						<th>Name</th>
						<th>Relation</th>
						<th>Percentage</th>
						<th>Contact</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
			<div class="tab-pane fade" id="personal-career" role="tabpanel" aria-labelledby="personal-career-tab">
				<h5>Add Employment Record</h5>
				<div id="career-form-row" class="form-row">
					<div class="form-group col-md-2">
						<input type="date" class="form-control" id="career_from_date" name="career_from_date" required
							   placeholder=" " />
						<label for="career_from_date">From Date *</label>
						<div class="form-error" id="error_career_from_date"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="date" class="form-control" id="career_to_date" name="career_to_date" required
							   placeholder=" " />
						<label for="career_to_date">To Date *</label>
						<div class="form-error" id="error_career_to_date"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_employer" name="career_employer" required
							   placeholder="e.g., ABC Corp" />
						<label for="career_employer">Employer *</label>
						<div class="form-error" id="error_career_employer"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_employer_code" name="career_employer_code"
							   placeholder=" " />
						<label for="career_employer_code">Employer Code</label>
						<div class="form-error" id="error_career_employer_code"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_employment_status"
							   name="career_employment_status" placeholder="e.g., Full-time" />
						<label for="career_employment_status">Employment Status</label>
						<div class="form-error" id="error_career_employment_status"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_position" name="career_position" required
							   placeholder="e.g., Software Engineer" />
						<label for="career_position">Position *</label>
						<div class="form-error" id="error_career_position"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_address" name="career_address" required
							   placeholder="e.g., 123 Tech Lane, City" />
						<label for="career_address">Address *</label>
						<div class="form-error" id="error_career_address"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="career_starting_salary"
							   name="career_starting_salary" placeholder="e.g., 50000" />
						<label for="career_starting_salary">Starting Salary</label>
						<div class="form-error" id="error_career_starting_salary"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="career_starting_other_comp"
							   name="career_starting_other_comp" placeholder="e.g., 5000" />
						<label for="career_starting_other_comp">Starting Other Compensation</label>
						<div class="form-error" id="error_career_starting_other_comp"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="career_final_salary" name="career_final_salary"
							   placeholder="e.g., 70000" />
						<label for="career_final_salary">Final Salary</label>
						<div class="form-error" id="error_career_final_salary"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="number" class="form-control" id="career_final_other_comp"
							   name="career_final_other_comp" placeholder="e.g., 7000" />
						<label for="career_final_other_comp">Final Other Compensation</label>
						<div class="form-error" id="error_career_final_other_comp"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_responsibility" name="career_responsibility"
							   required placeholder="e.g., Led development team" />
						<label for="career_responsibility">Responsibility *</label>
						<div class="form-error" id="error_career_responsibility"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_achievement" name="career_achievement"
							   placeholder="e.g., Increased efficiency by 15%" />
						<label for="career_achievement">Achievement</label>
						<div class="form-error" id="error_career_achievement"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_reason_for_change"
							   name="career_reason_for_change" required placeholder="e.g., Career growth" />
						<label for="career_reason_for_change">Reason for Change *</label>
						<div class="form-error" id="error_career_reason_for_change"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_contact_person" name="career_contact_person"
							   placeholder="e.g., Jane Doe" />
						<label for="career_contact_person">Contact Person</label>
						<div class="form-error" id="error_career_contact_person"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_contact_person_job_title"
							   name="career_contact_person_job_title" placeholder="e.g., HR Manager" />
						<label for="career_contact_person_job_title">Contact Person Job Title</label>
						<div class="form-error" id="error_career_contact_person_job_title"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_contact_person_department"
							   name="career_contact_person_department" placeholder="e.g., HR" />
						<label for="career_contact_person_department">Contact Person Department</label>
						<div class="form-error" id="error_career_contact_person_department"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_contact_person_mobile_no"
							   name="career_contact_person_mobile_no" placeholder="e.g., +91-1234567890" />
						<label for="career_contact_person_mobile_no">Contact Person Mobile No</label>
						<div class="form-error" id="error_career_contact_person_mobile_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="email" class="form-control" id="career_contact_person_email"
							   name="career_contact_person_email" placeholder="e.g., contact@example.com" />
						<label for="career_contact_person_email">Contact Person Email</label>
						<div class="form-error" id="error_career_contact_person_email"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="url" class="form-control" id="career_company_website" name="career_company_website"
							   placeholder="e.g., https://company.com" />
						<label for="career_company_website">Company Website</label>
						<div class="form-error" id="error_career_company_website"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_uan_no" name="career_uan_no"
							   placeholder=" " />
						<label for="career_uan_no">UAN No</label>
						<div class="form-error" id="error_career_uan_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_epf_ac_no" name="career_epf_ac_no"
							   placeholder=" " />
						<label for="career_epf_ac_no">EPF A/c No</label>
						<div class="form-error" id="error_career_epf_ac_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_epf_region" name="career_epf_region"
							   placeholder=" " />
						<label for="career_epf_region">EPF Region</label>
						<div class="form-error" id="error_career_epf_region"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_esi_ac_no" name="career_esi_ac_no"
							   placeholder=" " />
						<label for="career_esi_ac_no">ESI A/c No</label>
						<div class="form-error" id="error_career_esi_ac_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_scheme_certificate_no"
							   name="career_scheme_certificate_no" placeholder=" " />
						<label for="career_scheme_certificate_no">Scheme Certificate No</label>
						<div class="form-error" id="error_career_scheme_certificate_no"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="career_pension_payment_order_no"
							   name="career_pension_payment_order_no" placeholder=" " />
						<label for="career_pension_payment_order_no">Pension Payment Order No</label>
						<div class="form-error" id="error_career_pension_payment_order_no"></div>
					</div>
				</div>
				<button type="button" class="btn btn-info mb-2" id="addCareerRecord">Add Employment Record</button>
				<h5>Employment Records</h5>
				<table class="table table-bordered" id="careerRecordsTable">
					<thead>
					<tr>
						<th>From</th>
						<th>To</th>
						<th>Employer</th>
						<th>Position</th>
						<th>Department</th>
						<th>Reason</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
			<div class="tab-pane fade" id="personal-medical" role="tabpanel" aria-labelledby="personal-medical-tab">
				<h5>Medical History</h5>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="medical_chronic_conditions"
							   name="medical_chronic_conditions" placeholder="e.g., Diabetes, Asthma" />
						<label for="medical_chronic_conditions">Chronic Conditions</label>
						<div class="form-error" id="error_medical_chronic_conditions"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="medical_allergies" name="medical_allergies"
							   placeholder="e.g., Penicillin, Peanuts" />
						<label for="medical_allergies">Allergies</label>
						<div class="form-error" id="error_medical_allergies"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="medical_medications" name="medical_medications"
							   placeholder="e.g., Insulin, Blood Pressure Meds" />
						<label for="medical_medications">Medications</label>
						<div class="form-error" id="error_medical_medications"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="medical_past_surgeries" name="medical_past_surgeries"
							   placeholder="e.g., Appendectomy (2018)" />
						<label for="medical_past_surgeries">Past Surgeries</label>
						<div class="form-error" id="error_medical_past_surgeries"></div>
					</div>
				</div>
				<div class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="medical_emergency_contact_name"
							   name="medical_emergency_contact_name" placeholder="e.g., John Doe" />
						<label for="medical_emergency_contact_name">Emergency Contact Name</label>
						<div class="form-error" id="error_medical_emergency_contact_name"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="medical_emergency_contact_number"
							   name="medical_emergency_contact_number" placeholder="e.g., +91-9876543210" />
						<label for="medical_emergency_contact_number">Emergency Contact Number</label>
						<div class="form-error" id="error_medical_emergency_contact_number"></div>
					</div>
				</div>
			</div>
			<div class="tab-pane fade" id="personal-emergency" role="tabpanel" aria-labelledby="personal-emergency-tab">
				<h5>Add Emergency Contact</h5>
				<div id="emergency-form-row" class="form-row">
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="emergency_name" name="emergency_name" required
							   placeholder="e.g., Jane Doe" />
						<label for="emergency_name">Name *</label>
						<div class="form-error" id="error_emergency_name"></div>
					</div>
					<div class="form-group col-md-3">
						<input type="text" class="form-control" id="emergency_relation" name="emergency_relation" required
							   placeholder="e.g., Mother, Friend" />
						<label for="emergency_relation">Relation *</label>
						<div class="form-error" id="error_emergency_relation"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="emergency_contact1" name="emergency_contact1" required
							   placeholder="e.g., +91-9876543210" />
						<label for="emergency_contact1">Contact No 1 *</label>
						<div class="form-error" id="error_emergency_contact1"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="emergency_contact2" name="emergency_contact2"
							   placeholder="e.g., +91-9876543211" />
						<label for="emergency_contact2">Contact No 2</label>
						<div class="form-error" id="error_emergency_contact2"></div>
					</div>
					<div class="form-group col-md-2">
						<input type="text" class="form-control" id="emergency_contact3" name="emergency_contact3"
							   placeholder="e.g., +91-9876543212" />
						<label for="emergency_contact3">Contact No 3</label>
						<div class="form-error" id="error_emergency_contact3"></div>
					</div>
				</div>
				<button type="button" class="btn btn-info mb-2" id="addEmergencyRecord">Add Emergency Contact</button>
				<h5>Emergency Contact Records</h5>
				<table class="table table-bordered" id="emergencyRecordsTable">
					<thead>
					<tr>
						<th>Name</th>
						<th>Relation</th>
						<th>Contact 1</th>
						<th>Contact 2</th>
						<th>Contact 3</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
			<div class="tab-pane fade" id="personal-attachments" role="tabpanel" aria-labelledby="personal-attachments-tab">
				<h5>Add Attachment</h5>
				<div class="form-row">
					<div class="form-group col-md-4">
						<input type="text" class="form-control" id="attachment_description" name="attachment_description"
							   placeholder="e.g., Resume, ID Proof" />
						<label for="attachment_description">Description</label>
						<div class="form-error" id="error_attachment_description"></div>
					</div>
					<div class="form-group col-md-4">
						<input type="file" class="form-control" id="attachment_file" name="attachment_file" />
						<label for="attachment_file">File</label>
						<div class="form-error" id="error_attachment_file"></div>
					</div>
				</div>
				<button type="button" class="btn btn-info mb-2" id="addAttachmentRecord">Add Attachment</button>
				<h5>Attachments</h5>
				<table class="table table-bordered" id="attachmentRecordsTable">
					<thead>
					<tr>
						<th>Date</th>
						<th>Description</th>
						<th>File Name</th>
						<th>Action</th>
					</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
		<div class="d-flex justify-content-start gap-2 mt-3">
			<button type="submit" class="btn btn-success">Save & Accept Personal</button>
			<button type="button" class="btn btn-warning reset-form-btn" data-form-id="personalForm">Reset Personal</button>
		</div>
	</form>
<?php
// End: employee_form_personal.php
?>
