<?php
// Start: employee_form.php - Description: Main Employee Profile view file.
// This file loads common headers, footers, and dynamically includes content for each tab.
?>
<?php $this->load->view('header'); ?>
<?php $this->load->view('left_sidebar'); ?>
<?php $this->load->view('topbar'); ?>

	<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="<?php echo base_url('assets/css/employee_form.css'); ?>">
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


	<div class="emp-profile-container">
		<div class="d-flex justify-content-between align-items-center mb-3">
			<h2 class="emp-profile-heading flex-grow-1 text-center m-0">Employee Profile</h2>
			<div class="profile-progress-container ml-3" style="min-width:220px;">
				<div id="profile-progress-text" style="font-weight:600; color:gold;"></div>
				<div class="progress" style="background:black; border-radius:8px;">
					<div id="profile-progress-bar" class="progress-bar" role="progressbar"
						 style="width:0%; background:linear-gradient(90deg, gold, orange); color:black; font-weight:bold;">
						0%</div>
				</div>
			</div>
		</div>

		<div id="formAlert" style="display:none;"></div> <ul class="nav nav-tabs" id="myTab" role="tablist">
			<li class="nav-item" role="presentation">
				<a class="nav-link active" id="master-tab" data-toggle="tab" href="#master" role="tab"
				   aria-controls="master" aria-selected="true">Master</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="personal-tab" data-toggle="tab" href="#personal" role="tab"
				   aria-controls="personal" aria-selected="false">Personal</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="payment-tab" data-toggle="tab" href="#payment" role="tab"
				   aria-controls="payment" aria-selected="false">Payment</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="admin-tab" data-toggle="tab" href="#admin" role="tab"
				   aria-controls="admin" aria-selected="false">Administration</a>
			</li>
			<li class="nav-item" role="presentation">
				<a class="nav-link" id="statutory-tab" data-toggle="tab" href="#statutory" role="tab"
				   aria-controls="statutory" aria-selected="false">Statutory</a>
			</li>
		</ul>

		<div class="tab-content" id="myTabContent">
			<div class="tab-pane fade show active" id="master" role="tabpanel" aria-labelledby="master-tab">
				<?php
				// Pass $places and $employee_data to the master form partial
				$this->load->view(
					'employee/employee_form_master',
					[
						'places' => isset($places) ? $places : [],
						'employee_data' => isset($employee_data['master_data']) ? $employee_data['master_data'] : [],
						'employee_id_encoded' => isset($employee_id_encoded) ? $employee_id_encoded : ''
					]
				);
				?>
			</div>
			<div class="tab-pane fade" id="personal" role="tabpanel" aria-labelledby="personal-tab">
				<?php
				// Pass all relevant employee data to the personal form partial
				$this->load->view(
					'employee/employee_form_personal',
					[
						'employee_data' => isset($employee_data) ? $employee_data : [],
						'employee_id_encoded' => isset($employee_id_encoded) ? $employee_id_encoded : ''
					]
				);
				?>
			</div>
			<div class="tab-pane fade" id="payment" role="tabpanel" aria-labelledby="payment-tab">
				<?php
				// Pass payment details to the payment form partial
				$this->load->view(
					'employee/employee_form_payment',
					[
						'employee_data' => isset($employee_data['payment_details']) ? $employee_data['payment_details'] : [],
						'employee_id_encoded' => isset($employee_id_encoded) ? $employee_id_encoded : ''
					]
				);
				?>
			</div>
			<div class="tab-pane fade" id="admin" role="tabpanel" aria-labelledby="admin-tab">
				<?php
				// Pass admin details to the admin form partial
				$this->load->view(
					'employee/employee_form_admin',
					[
						'employee_data' => isset($employee_data['admin_details']) ? $employee_data['admin_details'] : [],
						'employee_id_encoded' => isset($employee_id_encoded) ? $employee_id_encoded : ''
					]
				);
				?>
			</div>
			<div class="tab-pane fade" id="statutory" role="tabpanel" aria-labelledby="statutory-tab">
				<?php
				// Pass statutory details to the statutory form partial
				$this->load->view(
					'employee/employee_form_statutory',
					[
						'employee_data' => isset($employee_data) ? $employee_data : [], // Send whole array for sub-sections
						'employee_id_encoded' => isset($employee_id_encoded) ? $employee_id_encoded : ''
					]
				);
				?>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

	<script>
		// Set the CodeIgniter base URL for JavaScript. This needs to be done before loading employee_form.js
		let CI_BASE_URL = '<?php echo base_url(); ?>';
		// Get the encoded employee ID from PHP if available (for edit mode)
		let EMPLOYEE_ID_ENCODED_FROM_PHP = '<?php echo isset($employee_id_encoded) ? $employee_id_encoded : ''; ?>';
		// Pass initial employee data (full profile) to JavaScript for edit mode population
		const EMPLOYEE_INITIAL_DATA = <?php echo json_encode(isset($employee_data) ? $employee_data : new stdClass()); ?>;
	</script>

	<script src="<?php echo base_url('assets/js/employee_form.js'); ?>"></script>

<?php $this->load->view('footer'); ?>
<?php
// End: employee_form.php
?>
