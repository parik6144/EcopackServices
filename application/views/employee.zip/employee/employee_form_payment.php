<?php
// Start: employee_form_payment.php - Description: This file contains the Payment tab content for the Employee Profile form.
?>
	<form id="paymentForm" class="employee-form" enctype="multipart/form-data" novalidate>
		<input type="hidden" id="payment_employee_id_hidden_field" name="employee_id_hidden_field" value="<?php echo isset($employee_id_encoded) ? $employee_id_encoded : ''; ?>">
		<h5>Payment Details</h5>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_type" name="payment_type" placeholder="e.g., Bank Transfer" />
				<label for="payment_type">Type</label>
				<div class="form-error" id="error_payment_type"></div>
			</div>
			<div class="form-group col-md-2">
				<input type="number" class="form-control" id="payment_percent" name="payment_percent" min="0" max="100" placeholder="e.g., 100" />
				<label for="payment_percent">Percent</label>
				<div class="form-error" id="error_payment_percent"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_type2" name="payment_type2" placeholder="e.g., Cash" />
				<label for="payment_type2">Type2</label>
				<div class="form-error" id="error_payment_type2"></div>
			</div>
			<div class="form-group col-md-2">
				<input type="number" class="form-control" id="payment_percent2" name="payment_percent2" min="0" max="100" placeholder="e.g., 0" />
				<label for="payment_percent2">Percent2</label>
				<div class="form-error" id="error_payment_percent2"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_bank_name" name="payment_bank_name" placeholder="e.g., State Bank of India" />
				<label for="payment_bank_name">Bank Name</label>
				<div class="form-error" id="error_payment_bank_name"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_branch" name="payment_branch" placeholder="e.g., Jamshedpur Main" />
				<label for="payment_branch">Branch</label>
				<div class="form-error" id="error_payment_branch"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_ifsc_code" name="payment_ifsc_code" placeholder="e.g., SBIN0000001" />
				<label for="payment_ifsc_code">IFSC Code</label>
				<div class="form-error" id="error_payment_ifsc_code"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_account_no" name="payment_account_no" placeholder="e.g., 123456789012345" />
				<label for="payment_account_no">A/C No</label>
				<div class="form-error" id="error_payment_account_no"></div>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_beneficiary_name" name="payment_beneficiary_name" placeholder="e.g., Employee Name" />
				<label for="payment_beneficiary_name">Beneficiary Name</label>
				<div class="form-error" id="error_payment_beneficiary_name"></div>
			</div>
			<div class="form-group col-md-3">
				<input type="text" class="form-control" id="payment_name_in_bank" name="payment_name_in_bank" placeholder="e.g., Employee Name" />
				<label for="payment_name_in_bank">Name In Bank</label>
				<div class="form-error" id="error_payment_name_in_bank"></div>
			</div>
		</div>
		<div class="d-flex justify-content-start gap-2 mt-3">
			<button type="submit" class="btn btn-success">Save & Accept Payment</button>
			<button type="button" class="btn btn-warning reset-form-btn" data-form-id="paymentForm">Reset Payment</button>
		</div>
	</form>
<?php
// End: employee_form_payment.php
?>
